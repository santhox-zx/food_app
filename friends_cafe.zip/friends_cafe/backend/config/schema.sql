-- ── Friends Cafe · MySQL Schema ──────────────────────────────
CREATE DATABASE IF NOT EXISTS friends_cafe CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE friends_cafe;

-- Users (customers)
CREATE TABLE IF NOT EXISTS users (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  name        VARCHAR(120) NOT NULL,
  phone       VARCHAR(20)  NOT NULL UNIQUE,
  password    VARCHAR(255) NOT NULL,
  created_at  DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Admin accounts
CREATE TABLE IF NOT EXISTS admins (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  name        VARCHAR(120) NOT NULL,
  phone       VARCHAR(20)  NOT NULL UNIQUE,
  password    VARCHAR(255) NOT NULL,
  created_at  DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Menu items (added rating, description, stock_qty)
CREATE TABLE IF NOT EXISTS menu_items (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  name        VARCHAR(150) NOT NULL,
  description VARCHAR(500) DEFAULT '',
  price       INT          NOT NULL,
  category    ENUM('seafood','chinese','biryani','curries','veg') NOT NULL DEFAULT 'veg',
  img_url     TEXT,
  rating      DECIMAL(3,1) DEFAULT 4.5,
  stock_qty   INT          DEFAULT 99,
  available   TINYINT(1)   DEFAULT 1,
  created_at  DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Delivery boys (added email for edit support)
CREATE TABLE IF NOT EXISTS delivery_boys (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  name        VARCHAR(120) NOT NULL,
  phone       VARCHAR(20)  NOT NULL,
  photo_url   TEXT,
  rating      DECIMAL(3,1) DEFAULT 4.5,
  deliveries  INT          DEFAULT 0,
  available   TINYINT(1)   DEFAULT 1
);

-- Orders
CREATE TABLE IF NOT EXISTS orders (
  id              VARCHAR(20) PRIMARY KEY,
  customer_name   VARCHAR(120),
  customer_phone  VARCHAR(20),
  address         TEXT,
  payment_method  VARCHAR(30) DEFAULT 'Cash on Delivery',
  items           JSON,
  subtotal        INT  DEFAULT 0,
  delivery_fee    INT  DEFAULT 40,
  total           INT  DEFAULT 0,
  status          ENUM('Received','Preparing','OutForDelivery','Delivered','Cancelled') DEFAULT 'Received',
  cancelled_by    ENUM('customer','admin') DEFAULT NULL,
  cancel_reason   VARCHAR(255) DEFAULT NULL,
  delivery_boy_id INT,
  notes           TEXT,
  created_at      DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (delivery_boy_id) REFERENCES delivery_boys(id) ON DELETE SET NULL
);

-- ── Seed: Menu items ──────────────────────────────────────
INSERT IGNORE INTO menu_items (id,name,description,price,category,img_url,rating,stock_qty,available) VALUES
(1,'Crab Lollipop','Crispy crab meat on a stick, marinated in special spices and deep fried to golden perfection.',220,'seafood','https://images.unsplash.com/photo-1625220194771-7ebdea0b70b9?w=400&q=70',4.8,50,1),
(2,'Crab Rasam','Traditional South Indian crab rasam with tamarind, tomatoes and aromatic spices. Served piping hot.',180,'seafood','https://images.unsplash.com/photo-1603360946369-dc9bb6258143?w=400&q=70',4.6,40,1),
(3,'Malai Chicken Tikka','Tender chicken marinated in malai (cream) and mild spices, grilled in a tandoor. Soft and juicy.',260,'chinese','https://images.unsplash.com/photo-1599487488170-d11ec9c172f0?w=400&q=70',4.7,60,1),
(4,'Chicken Biryani','Fragrant basmati rice cooked with tender chicken, whole spices and saffron. A royal treat.',180,'biryani','https://images.unsplash.com/photo-1563379091339-03b21ab4a4f8?w=400&q=70',4.9,80,1),
(5,'Chicken Curry','Rich and spicy chicken curry cooked in tomato-onion gravy with freshly ground masala.',160,'curries','https://images.unsplash.com/photo-1565557623262-b51c2513a641?w=400&q=70',4.5,70,1),
(6,'Veg Meals','Complete South Indian thali with rice, sambar, rasam, kootu, papad and pickle.',120,'veg','https://images.unsplash.com/photo-1546833999-b9f581a1996d?w=400&q=70',4.4,99,1),
(7,'Fried Rice','Wok-tossed rice with vegetables, egg and soy sauce. A classic Indo-Chinese favourite.',140,'chinese','https://images.unsplash.com/photo-1603133872878-684f208fb84b?w=400&q=70',4.3,90,1),
(8,'Noodles','Hakka-style noodles tossed with vegetables and your choice of sauces.',130,'chinese','https://images.unsplash.com/photo-1569718212165-3a8278d5f624?w=400&q=70',4.2,90,1),
(9,'Fish Fry','Fresh local fish marinated in red chilli paste and pan-fried with curry leaves and mustard.',200,'seafood','https://images.unsplash.com/photo-1519708227418-c8fd9a32b7a2?w=400&q=70',4.7,45,1),
(10,'Mutton Curry','Slow-cooked mutton in a rich onion-tomato gravy with aromatic whole spices.',240,'curries','https://images.unsplash.com/photo-1574653853027-5382a3d23a15?w=400&q=70',4.8,30,1);

-- ── Seed: Delivery boys ───────────────────────────────────
INSERT IGNORE INTO delivery_boys (id,name,phone,photo_url,rating,deliveries,available) VALUES
(1,'Ravi Kumar','9876543210','https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=200&q=80',4.8,312,1),
(2,'Murugan S','9865432109','https://images.unsplash.com/photo-1552058544-f2b08422138a?w=200&q=80',4.6,245,1),
(3,'Karthik R','9843219876','https://images.unsplash.com/photo-1547425260-76bcadfb4f2c?w=200&q=80',4.9,189,0);
