-- ── Friends Cafe · Migration (run if DB already exists) ──
USE friends_cafe;

-- Add new columns to menu_items
ALTER TABLE menu_items
  ADD COLUMN IF NOT EXISTS description VARCHAR(500) DEFAULT '' AFTER name,
  ADD COLUMN IF NOT EXISTS rating      DECIMAL(3,1) DEFAULT 4.5 AFTER img_url,
  ADD COLUMN IF NOT EXISTS stock_qty   INT          DEFAULT 99  AFTER rating;

-- Drop the old tamil column (causes garbage display)
ALTER TABLE menu_items DROP COLUMN IF EXISTS name_tamil;

-- Add admins table
CREATE TABLE IF NOT EXISTS admins (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  phone VARCHAR(20) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Add cancel columns to orders
ALTER TABLE orders
  ADD COLUMN IF NOT EXISTS cancelled_by  ENUM('customer','admin') DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS cancel_reason VARCHAR(255) DEFAULT NULL;

-- Delete any bad admin seed row
DELETE FROM admins WHERE phone = '9000000000';

-- Update existing menu items with descriptions and ratings
UPDATE menu_items SET description='Crispy crab meat on a stick, marinated in special spices and deep fried to golden perfection.', rating=4.8, stock_qty=50 WHERE id=1 AND description='';
UPDATE menu_items SET description='Traditional South Indian crab rasam with tamarind, tomatoes and aromatic spices.', rating=4.6, stock_qty=40 WHERE id=2 AND description='';
UPDATE menu_items SET description='Tender chicken marinated in malai and mild spices, grilled in a tandoor. Soft and juicy.', rating=4.7, stock_qty=60 WHERE id=3 AND description='';
UPDATE menu_items SET description='Fragrant basmati rice cooked with tender chicken, whole spices and saffron.', rating=4.9, stock_qty=80 WHERE id=4 AND description='';
UPDATE menu_items SET description='Rich and spicy chicken curry cooked in tomato-onion gravy with freshly ground masala.', rating=4.5, stock_qty=70 WHERE id=5 AND description='';
UPDATE menu_items SET description='Complete South Indian thali with rice, sambar, rasam, kootu, papad and pickle.', rating=4.4, stock_qty=99 WHERE id=6 AND description='';
UPDATE menu_items SET description='Wok-tossed rice with vegetables, egg and soy sauce. Classic Indo-Chinese style.', rating=4.3, stock_qty=90 WHERE id=7 AND description='';
UPDATE menu_items SET description='Hakka-style noodles tossed with vegetables and your choice of sauces.', rating=4.2, stock_qty=90 WHERE id=8 AND description='';
UPDATE menu_items SET description='Fresh local fish marinated in red chilli paste, pan-fried with curry leaves.', rating=4.7, stock_qty=45 WHERE id=9 AND description='';
UPDATE menu_items SET description='Slow-cooked mutton in a rich onion-tomato gravy with aromatic whole spices.', rating=4.8, stock_qty=30 WHERE id=10 AND description='';

SELECT 'Migration complete.' AS status;
