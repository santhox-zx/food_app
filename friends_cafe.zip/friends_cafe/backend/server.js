// server.js — Friends Cafe Backend
require('dotenv').config();
const express = require('express');
const cors    = require('cors');
const app     = express();
const PORT    = process.env.PORT || 3000;

// ── MIDDLEWARE ────────────────────────────────────────────
app.use(cors({ origin: '*' }));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Request logger
app.use((req, _res, next) => {
  console.log(`[${new Date().toISOString()}] ${req.method} ${req.path}`);
  next();
});

// ── ROUTES ────────────────────────────────────────────────
app.use('/api/auth',      require('./routes/auth'));
app.use('/api/menu',      require('./routes/menu'));
app.use('/api/orders',    require('./routes/orders'));
app.use('/api/delivery',  require('./routes/delivery'));
app.use('/api/customers', require('./routes/customers'));

// Health check
app.get('/health', (_req, res) =>
  res.json({ status: 'ok', app: 'Friends Cafe API', time: new Date() })
);

// 404
app.use((_req, res) => res.status(404).json({ error: 'Route not found' }));

// Global error handler
app.use((err, _req, res, _next) => {
  console.error(err.stack);
  res.status(500).json({ error: 'Internal server error' });
});

app.listen(PORT, () => {
  const ADMIN_PHONE = process.env.ADMIN_PHONE || '9000000000';
  const ADMIN_PASS  = process.env.ADMIN_PASS  || 'admin123';

  console.log('\n╔══════════════════════════════════════════╗');
  console.log('║   🍴  Friends Cafe API is running         ║');
  console.log('╠══════════════════════════════════════════╣');
  console.log(`║  URL    : http://localhost:${PORT}           ║`);
  console.log(`║  Health : http://localhost:${PORT}/health    ║`);
  console.log('╠══════════════════════════════════════════╣');
  console.log('║  ADMIN LOGIN CREDENTIALS                 ║');
  console.log(`║  Phone  : ${ADMIN_PHONE.padEnd(31)}║`);
  console.log(`║  Pass   : ${ADMIN_PASS.padEnd(31)}║`);
  console.log('╚══════════════════════════════════════════╝\n');
});
