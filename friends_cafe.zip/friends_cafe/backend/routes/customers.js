// routes/customers.js
const router = require('express').Router();
const db     = require('../config/db');
const { requireAdmin } = require('../middleware/auth');

// ── GET ALL CUSTOMERS (admin) ─────────────────────────────
router.get('/', requireAdmin, async (req, res) => {
  try {
    const [users] = await db.query(
      `SELECT u.id, u.name, u.phone, u.created_at,
              COUNT(o.id) as order_count,
              IFNULL(SUM(o.total),0) as total_spent
       FROM users u
       LEFT JOIN orders o ON o.customer_phone = u.phone
       GROUP BY u.id
       ORDER BY u.created_at DESC`
    );
    res.json(users);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;
