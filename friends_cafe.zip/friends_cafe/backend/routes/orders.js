// routes/orders.js
const router = require('express').Router();
const db     = require('../config/db');
const { requireAuth, requireAdmin } = require('../middleware/auth');

function generateOrderId() {
  return 'FC-' + Math.floor(100000 + Math.random() * 900000);
}

function parseItems(row) {
  if (row && typeof row.items === 'string') {
    try { row.items = JSON.parse(row.items); } catch (_) {}
  }
  return row;
}

// ── PLACE ORDER (customer) ────────────────────────────────
router.post('/', requireAuth, async (req, res) => {
  try {
    const { address, payment_method, items, subtotal, delivery_fee, total, notes } = req.body;
    if (!items || !Array.isArray(items) || items.length === 0)
      return res.status(400).json({ error: 'Cart is empty' });

    let orderId, attempts = 0;
    do {
      orderId = generateOrderId();
      const [ex] = await db.query('SELECT id FROM orders WHERE id = ?', [orderId]);
      if (ex.length === 0) break;
    } while (++attempts < 5);

    const [boys] = await db.query(
      'SELECT * FROM delivery_boys WHERE available = 1 ORDER BY RAND() LIMIT 1'
    );

    await db.query(
      `INSERT INTO orders
         (id, customer_name, customer_phone, address, payment_method,
          items, subtotal, delivery_fee, total, status, delivery_boy_id, notes)
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?)`,
      [orderId, req.user.name, req.user.phone,
       address || '', payment_method || 'Cash on Delivery',
       JSON.stringify(items), subtotal || 0, delivery_fee || 40, total || 0,
       'Received', boys.length > 0 ? boys[0].id : null, notes || '']
    );

    const [rows] = await db.query(
      `SELECT o.*, db.name AS db_name, db.phone AS db_phone,
              db.photo_url AS db_photo, db.rating AS db_rating
       FROM orders o LEFT JOIN delivery_boys db ON o.delivery_boy_id = db.id
       WHERE o.id = ?`, [orderId]
    );
    res.status(201).json(parseItems(rows[0]));
  } catch (err) {
    console.error('[POST /orders]', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// ── MY ORDERS (customer) ───────────────────────────────────
router.get('/my', requireAuth, async (req, res) => {
  try {
    const [rows] = await db.query(
      `SELECT o.*, db.name AS db_name, db.phone AS db_phone,
              db.photo_url AS db_photo, db.rating AS db_rating
       FROM orders o LEFT JOIN delivery_boys db ON o.delivery_boy_id = db.id
       WHERE o.customer_phone = ?
       ORDER BY o.created_at DESC`,
      [req.user.phone]
    );
    res.json(rows.map(parseItems));
  } catch (err) {
    console.error('[GET /orders/my]', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// ── CUSTOMER CANCEL (only when Received) ──────────────────
router.patch('/my/:id/cancel', requireAuth, async (req, res) => {
  try {
    const { reason } = req.body;
    const [rows] = await db.query(
      'SELECT * FROM orders WHERE id = ? AND customer_phone = ?',
      [req.params.id, req.user.phone]
    );
    if (rows.length === 0)
      return res.status(404).json({ error: 'Order not found' });

    if (rows[0].status !== 'Received')
      return res.status(400).json({
        error: `Cannot cancel. Status is "${rows[0].status}". Only Received orders can be cancelled.`
      });

    await db.query(
      `UPDATE orders SET status = 'Cancelled', cancelled_by = 'customer', cancel_reason = ?
       WHERE id = ?`,
      [reason || 'Cancelled by customer', req.params.id]
    );
    res.json({ message: 'Order cancelled', orderId: req.params.id, status: 'Cancelled' });
  } catch (err) {
    console.error('[PATCH /orders/my/:id/cancel]', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// ── CUSTOMER CONFIRM DELIVERY (OutForDelivery → Delivered) ─
router.patch('/my/:id/delivered', requireAuth, async (req, res) => {
  try {
    const [rows] = await db.query(
      'SELECT * FROM orders WHERE id = ? AND customer_phone = ?',
      [req.params.id, req.user.phone]
    );
    if (rows.length === 0)
      return res.status(404).json({ error: 'Order not found' });

    if (rows[0].status !== 'OutForDelivery')
      return res.status(400).json({
        error: `Cannot confirm delivery. Status is "${rows[0].status}".`
      });

    await db.query(
      "UPDATE orders SET status = 'Delivered' WHERE id = ?",
      [req.params.id]
    );
    res.json({ message: 'Order marked as delivered', orderId: req.params.id, status: 'Delivered' });
  } catch (err) {
    console.error('[PATCH /orders/my/:id/delivered]', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// ── DASHBOARD STATS (admin) — MUST be before /:id routes ──
router.get('/stats/dashboard', requireAdmin, async (req, res) => {
  try {
    const [[{ total_orders }]]  = await db.query('SELECT COUNT(*) AS total_orders FROM orders');
    const [[{ total_revenue }]] = await db.query(
      "SELECT IFNULL(SUM(total),0) AS total_revenue FROM orders WHERE status != 'Cancelled'"
    );
    const [[{ pending }]] = await db.query(
      "SELECT COUNT(*) AS pending FROM orders WHERE status IN ('Received','Preparing')"
    );
    const [[{ customers }]] = await db.query('SELECT COUNT(*) AS customers FROM users');
    res.json({ total_orders, total_revenue, pending, customers });
  } catch (err) {
    console.error('[GET /orders/stats/dashboard]', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// ── REVENUE STATS (admin) ─────────────────────────────────────
router.get('/stats/revenue', requireAdmin, async (req, res) => {
  try {
    const { period, from, to } = req.query;
    let where = "WHERE status != 'Cancelled'";
    const params = [];

    if (period == 'weekly') {
      where += ' AND created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)';
    } else if (period == 'monthly') {
      where += ' AND created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)';
    } else if (period == 'yearly') {
      where += ' AND created_at >= DATE_SUB(NOW(), INTERVAL 365 DAY)';
    } else if (period == 'custom') {
      if (!from || !to) {
        return res.status(400).json({ error: 'from and to required for custom period' });
      }
      where += ' AND DATE(created_at) BETWEEN ? AND ?';
      params.push(from, to);
    }

    const [[{ total_revenue }]] = await db.query(
      `SELECT IFNULL(SUM(total),0) AS total_revenue FROM orders ${where}`,
      params
    );

    const [[{ total_orders }]] = await db.query(
      `SELECT COUNT(*) AS total_orders FROM orders ${where}`,
      params
    );

    res.json({ total_revenue, total_orders, period: period ?? 'all', from: from ?? null, to: to ?? null });
  } catch (err) {
    console.error('[GET /orders/stats/revenue]', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// ── ALL ORDERS (admin) ────────────────────────────────────
router.get('/', requireAdmin, async (req, res) => {
  try {
    const [rows] = await db.query(
      `SELECT o.*, db.name AS db_name, db.phone AS db_phone,
              db.photo_url AS db_photo, db.rating AS db_rating
       FROM orders o LEFT JOIN delivery_boys db ON o.delivery_boy_id = db.id
       ORDER BY o.created_at DESC`
    );
    res.json(rows.map(parseItems));
  } catch (err) {
    console.error('[GET /orders]', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// ── UPDATE STATUS (admin) ─────────────────────────────────
router.patch('/:id/status', requireAdmin, async (req, res) => {
  try {
    const { status } = req.body;
    const valid = ['Received','Preparing','OutForDelivery','Delivered','Cancelled'];
    if (!valid.includes(status))
      return res.status(400).json({ error: `Invalid status. Must be: ${valid.join(', ')}` });

    await db.query(
      `UPDATE orders
       SET status = ?,
           cancelled_by = CASE WHEN ? = 'Cancelled' THEN 'admin' ELSE cancelled_by END
       WHERE id = ?`,
      [status, status, req.params.id]
    );
    res.json({ message: 'Status updated', status });
  } catch (err) {
    console.error('[PATCH /orders/:id/status]', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// ── ASSIGN DELIVERY BOY (admin) ───────────────────────────
router.patch('/:id/assign', requireAdmin, async (req, res) => {
  try {
    const { delivery_boy_id } = req.body;
    if (!delivery_boy_id)
      return res.status(400).json({ error: 'delivery_boy_id required' });

    await db.query('UPDATE orders SET delivery_boy_id = ? WHERE id = ?',
      [delivery_boy_id, req.params.id]);

    const [rows] = await db.query(
      `SELECT o.*, db.name AS db_name, db.phone AS db_phone,
              db.photo_url AS db_photo, db.rating AS db_rating
       FROM orders o LEFT JOIN delivery_boys db ON o.delivery_boy_id = db.id
       WHERE o.id = ?`, [req.params.id]
    );
    if (rows.length === 0) return res.status(404).json({ error: 'Order not found' });
    res.json(parseItems(rows[0]));
  } catch (err) {
    console.error('[PATCH /orders/:id/assign]', err);
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;
