// routes/menu.js
const router = require('express').Router();
const db     = require('../config/db');
const { requireAdmin } = require('../middleware/auth');

// ── GET ALL MENU ITEMS (public) ───────────────────────────
router.get('/', async (req, res) => {
  try {
    const { category } = req.query;
    let sql    = 'SELECT * FROM menu_items';
    const params = [];
    if (category && category !== 'all') {
      sql += ' WHERE category = ?';
      params.push(category);
    }
    sql += ' ORDER BY id ASC';
    const [rows] = await db.query(sql, params);
    res.json(rows);
  } catch (err) {
    console.error('[GET /menu]', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// ── ADD MENU ITEM (admin) ─────────────────────────────────
router.post('/', requireAdmin, async (req, res) => {
  try {
    const { name, description, price, category, img_url, rating, stock_qty } = req.body;
    if (!name || !price || !category)
      return res.status(400).json({ error: 'Name, price and category are required' });

    const [result] = await db.query(
      `INSERT INTO menu_items (name, description, price, category, img_url, rating, stock_qty, available)
       VALUES (?,?,?,?,?,?,?,1)`,
      [name, description || '', price, category, img_url || '',
       parseFloat(rating) || 4.5, parseInt(stock_qty) || 99]
    );
    const [rows] = await db.query('SELECT * FROM menu_items WHERE id = ?', [result.insertId]);
    res.status(201).json(rows[0]);
  } catch (err) {
    console.error('[POST /menu]', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// ── UPDATE MENU ITEM (admin) ──────────────────────────────
router.put('/:id', requireAdmin, async (req, res) => {
  try {
    const { name, description, price, category, img_url, rating, stock_qty, available } = req.body;
    await db.query(
      `UPDATE menu_items
       SET name=?, description=?, price=?, category=?, img_url=?,
           rating=?, stock_qty=?, available=?
       WHERE id=?`,
      [name, description || '', price, category, img_url || '',
       parseFloat(rating) || 4.5, parseInt(stock_qty) || 99,
       available ? 1 : 0, req.params.id]
    );
    const [rows] = await db.query('SELECT * FROM menu_items WHERE id = ?', [req.params.id]);
    res.json(rows[0]);
  } catch (err) {
    console.error('[PUT /menu/:id]', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// ── TOGGLE AVAILABILITY (admin) ───────────────────────────
router.patch('/:id/toggle', requireAdmin, async (req, res) => {
  try {
    await db.query('UPDATE menu_items SET available = NOT available WHERE id = ?', [req.params.id]);
    const [rows] = await db.query('SELECT * FROM menu_items WHERE id = ?', [req.params.id]);
    res.json(rows[0]);
  } catch (err) {
    console.error('[PATCH /menu/:id/toggle]', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// ── DELETE MENU ITEM (admin) ──────────────────────────────
router.delete('/:id', requireAdmin, async (req, res) => {
  try {
    await db.query('DELETE FROM menu_items WHERE id = ?', [req.params.id]);
    res.json({ message: 'Item deleted' });
  } catch (err) {
    console.error('[DELETE /menu/:id]', err);
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;
