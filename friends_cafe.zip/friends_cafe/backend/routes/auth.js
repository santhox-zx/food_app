// routes/auth.js
const router  = require('express').Router();
const bcrypt  = require('bcryptjs');
const db      = require('../config/db');
const { signToken } = require('../middleware/auth');

// ── CUSTOMER REGISTER ──────────────────────────────────────
router.post('/register', async (req, res) => {
  try {
    const { name, phone, password } = req.body;
    if (!name || !phone || !password)
      return res.status(400).json({ error: 'Name, phone and password are required' });

    const [existing] = await db.query('SELECT id FROM users WHERE phone = ?', [phone]);
    if (existing.length > 0)
      return res.status(409).json({ error: 'Phone number already registered' });

    const hash = await bcrypt.hash(password, 10);
    const [result] = await db.query(
      'INSERT INTO users (name, phone, password) VALUES (?, ?, ?)',
      [name.trim(), phone.trim(), hash]
    );
    const token = signToken({ id: result.insertId, name: name.trim(), phone: phone.trim(), role: 'customer' });
    res.status(201).json({ token, user: { id: result.insertId, name: name.trim(), phone: phone.trim() } });
  } catch (err) {
    console.error('[POST /auth/register]', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// ── CUSTOMER + ADMIN LOGIN (single endpoint) ──────────────────
router.post('/login', async (req, res) => {
  try {
    const { phone, password } = req.body;
    if (!phone || !password)
      return res.status(400).json({ error: 'Phone and password are required' });

    const cleanPhone = phone.trim();

    // 1) Customer login
    const [userRows] = await db.query('SELECT * FROM users WHERE phone = ?', [cleanPhone]);
    if (userRows.length > 0) {
      const match = await bcrypt.compare(password, userRows[0].password);
      if (!match) return res.status(401).json({ error: 'Invalid phone or password' });

      const user = userRows[0];
      const token = signToken({ id: user.id, name: user.name, phone: user.phone, role: 'customer' });
      return res.json({ token, user: { id: user.id, name: user.name, phone: user.phone, role: 'customer' }, role: 'customer' });
    }

    // 2) Admin login fallback
    // DB admins table
    const [adminRows] = await db.query('SELECT * FROM admins WHERE phone = ?', [cleanPhone]);
    if (adminRows.length > 0) {
      const match = await bcrypt.compare(password, adminRows[0].password);
      if (!match) return res.status(401).json({ error: 'Invalid phone or password' });

      const token = signToken({ role: 'admin', phone: adminRows[0].phone, name: adminRows[0].name }, '12h');
      return res.json({ token, admin: { name: adminRows[0].name, phone: adminRows[0].phone, role: 'admin' }, role: 'admin' });
    }

    // 3) Env fallback admin
    const ADMIN_PHONE = (process.env.ADMIN_PHONE || '9000000000').trim();
    const ADMIN_PASS  = (process.env.ADMIN_PASS  || 'admin123').trim();
    if (cleanPhone === ADMIN_PHONE && password.trim() === ADMIN_PASS) {
      const token = signToken({ role: 'admin', phone: ADMIN_PHONE, name: 'Admin' }, '12h');
      return res.json({ token, admin: { name: 'Admin', phone: ADMIN_PHONE, role: 'admin' }, role: 'admin' });
    }

    return res.status(401).json({ error: 'Invalid phone or password' });
  } catch (err) {
    console.error('[POST /auth/login]', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// ── ADMIN LOGIN (phone + password) ─────────────────────────
// Priority:
//   1. Look up phone in `admins` table → bcrypt compare
//   2. If not found in DB, fall back to ADMIN_PHONE / ADMIN_PASS env vars
// This means: on a fresh install, env fallback works immediately.
// After running /admin/register, the DB row takes over.
router.post('/admin/login', async (req, res) => {
  try {
    const { phone, password } = req.body;
    if (!phone || !password)
      return res.status(400).json({ error: 'Phone and password are required' });

    const cleanPhone = phone.trim();

    // ── Step 1: Check admins table ────────────────────────
    const [rows] = await db.query(
      'SELECT * FROM admins WHERE phone = ?',
      [cleanPhone]
    );

    if (rows.length > 0) {
      // Row found — do bcrypt comparison
      const match = await bcrypt.compare(password, rows[0].password);
      if (!match)
        return res.status(401).json({ error: 'Invalid phone or password' });

      const token = signToken(
        { role: 'admin', phone: rows[0].phone, name: rows[0].name },
        '12h'
      );
      return res.json({ token, admin: { name: rows[0].name, phone: rows[0].phone } });
    }

    // ── Step 2: Env-based fallback (plain-text comparison) ─
    // Used when no admin row exists in DB yet (fresh install)
    const ADMIN_PHONE = (process.env.ADMIN_PHONE || '9000000000').trim();
    const ADMIN_PASS  = (process.env.ADMIN_PASS  || 'admin123').trim();

    if (cleanPhone === ADMIN_PHONE && password.trim() === ADMIN_PASS) {
      const token = signToken(
        { role: 'admin', phone: ADMIN_PHONE, name: 'Admin' },
        '12h'
      );
      return res.json({ token, admin: { name: 'Admin', phone: ADMIN_PHONE } });
    }

    // Both checks failed
    return res.status(401).json({ error: 'Invalid phone or password' });

  } catch (err) {
    console.error('[POST /auth/admin/login]', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// ── ADMIN REGISTER (create / update admin account) ─────────
// Requires confirm_key = current ADMIN_PASS env var as a gate.
// Also auto-updates if the phone already exists (hash refresh).
router.post('/admin/register', async (req, res) => {
  try {
    const { name, phone, password, confirm_key } = req.body;
    const ADMIN_PASS = (process.env.ADMIN_PASS || 'admin123').trim();

    if (!confirm_key || confirm_key.trim() !== ADMIN_PASS)
      return res.status(403).json({ error: 'Invalid confirmation key' });
    if (!name || !phone || !password)
      return res.status(400).json({ error: 'Name, phone and password are required' });

    const hash = await bcrypt.hash(password.trim(), 10);
    const [existing] = await db.query(
      'SELECT id FROM admins WHERE phone = ?',
      [phone.trim()]
    );

    if (existing.length > 0) {
      // Update existing admin
      await db.query(
        'UPDATE admins SET name = ?, password = ? WHERE phone = ?',
        [name.trim(), hash, phone.trim()]
      );
      return res.json({ message: 'Admin account updated. You can now log in.' });
    }

    // Insert new admin
    await db.query(
      'INSERT INTO admins (name, phone, password) VALUES (?, ?, ?)',
      [name.trim(), phone.trim(), hash]
    );
    res.status(201).json({ message: 'Admin account created. You can now log in.' });
  } catch (err) {
    console.error('[POST /auth/admin/register]', err);
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;
