// routes/delivery.js
const router = require('express').Router();
const db     = require('../config/db');
const { requireAdmin } = require('../middleware/auth');

// ── GET ALL DELIVERY BOYS (admin) ─────────────────────────
router.get('/', requireAdmin, async (req, res) => {
  try {
    const [rows] = await db.query('SELECT * FROM delivery_boys ORDER BY id ASC');
    res.json(rows);
  } catch (err) {
    console.error('[GET /delivery]', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// ── ADD DELIVERY BOY (admin) ──────────────────────────────
router.post('/', requireAdmin, async (req, res) => {
  try {
    const { name, phone, photo_url, rating, deliveries } = req.body;
    if (!name || !phone)
      return res.status(400).json({ error: 'Name and phone are required' });

    const [result] = await db.query(
      'INSERT INTO delivery_boys (name, phone, photo_url, rating, deliveries, available) VALUES (?,?,?,?,?,1)',
      [name.trim(), phone.trim(), photo_url || '', parseFloat(rating) || 4.5, parseInt(deliveries) || 0]
    );
    const [rows] = await db.query('SELECT * FROM delivery_boys WHERE id = ?', [result.insertId]);
    res.status(201).json(rows[0]);
  } catch (err) {
    console.error('[POST /delivery]', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// ── UPDATE DELIVERY BOY (admin) ───────────────────────────
router.put('/:id', requireAdmin, async (req, res) => {
  try {
    const { name, phone, photo_url, rating, deliveries } = req.body;
    if (!name || !phone)
      return res.status(400).json({ error: 'Name and phone are required' });

    await db.query(
      'UPDATE delivery_boys SET name=?, phone=?, photo_url=?, rating=?, deliveries=? WHERE id=?',
      [name.trim(), phone.trim(), photo_url || '', parseFloat(rating) || 4.5,
       parseInt(deliveries) || 0, req.params.id]
    );
    const [rows] = await db.query('SELECT * FROM delivery_boys WHERE id = ?', [req.params.id]);
    if (rows.length === 0) return res.status(404).json({ error: 'Not found' });
    res.json(rows[0]);
  } catch (err) {
    console.error('[PUT /delivery/:id]', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// ── TOGGLE AVAILABILITY (admin) ───────────────────────────
router.patch('/:id/toggle', requireAdmin, async (req, res) => {
  try {
    await db.query('UPDATE delivery_boys SET available = NOT available WHERE id = ?', [req.params.id]);
    const [rows] = await db.query('SELECT * FROM delivery_boys WHERE id = ?', [req.params.id]);
    res.json(rows[0]);
  } catch (err) {
    console.error('[PATCH /delivery/:id/toggle]', err);
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;
