package com.example.friends_cafe

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
