// lib/services/app_provider.dart
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'api_service.dart';
import '../utils/safe_parse.dart';

class CartItem {
  final int id;
  final String name;
  final int price;
  final String img;
  int qty;

  CartItem({
    required this.id,
    required this.name,
    required this.price,
    required this.img,
    this.qty = 1,
  });

  Map<String, dynamic> toJson() =>
      {'id': id, 'name': name, 'price': price, 'img': img, 'qty': qty};
}

class AppProvider extends ChangeNotifier {
  Map<String, dynamic>? _user;
  bool _isAdmin = false;

  Map<String, dynamic>? get user      => _user;
  bool                   get isLoggedIn => _user != null;
  bool                   get isAdmin    => _isAdmin;

  final List<CartItem> _cart = [];
  List<CartItem> get cart => List.unmodifiable(_cart);

  int get cartCount    => _cart.fold(0, (s, i) => s + i.qty);
  int get cartSubtotal => _cart.fold(0, (s, i) => s + i.price * i.qty);
  int get deliveryFee  => cartSubtotal > 0 ? 40 : 0;
  int get cartTotal    => cartSubtotal + deliveryFee;

  List<dynamic> _menuItems  = [];
  bool          _menuLoading = false;

  List<dynamic> get menuItems   => _menuItems;
  bool          get menuLoading => _menuLoading;

  AppProvider() { _loadSession(); }

  Future<void> _loadSession() async {
    try {
      final prefs      = await SharedPreferences.getInstance();
      final userJson   = prefs.getString('fc_user');
      final adminToken = prefs.getString('fc_admin_token');
      if (userJson != null) {
        _user = Map<String, dynamic>.from(json.decode(userJson) as Map);
      }
      if (adminToken != null) _isAdmin = true;
      notifyListeners();
    } catch (_) {}
  }

  Future<Map<String, dynamic>> login(String phone, String password) async {
    final result = await ApiService.login(phone, password);
    if (result['success'] == true) {
      final data = Map<String, dynamic>.from(result['data'] as Map);
      final role = data['role']?.toString() ?? 'customer';
      final prefs = await SharedPreferences.getInstance();

      if (role == 'admin') {
        _isAdmin = true;
        _user = {
          'name': (data['admin'] as Map<String, dynamic>?)?['name'] ?? 'Admin',
          'phone': (data['admin'] as Map<String, dynamic>?)?['phone'] ?? '',
          'role': 'admin',
        };
        await prefs.setString('fc_admin_token', data['token'].toString());
        await prefs.remove('fc_token');
        await prefs.setString('fc_user', json.encode(_user));
      } else {
        _isAdmin = false;
        final customer = Map<String, dynamic>.from(data['user'] as Map);
        customer['role'] = 'customer';
        _user = customer;
        await prefs.setString('fc_token', data['token'].toString());
        await prefs.setString('fc_user', json.encode(_user));
        await prefs.remove('fc_admin_token');
      }
      notifyListeners();
    }
    return result;
  }

  Future<Map<String, dynamic>> register(
      String name, String phone, String password) async {
    final result = await ApiService.register(name, phone, password);
    if (result['success'] == true) {
      final data  = Map<String, dynamic>.from(result['data'] as Map);
      _user       = Map<String, dynamic>.from(data['user'] as Map);
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('fc_token', data['token'].toString());
      await prefs.setString('fc_user',  json.encode(_user));
      notifyListeners();
    }
    return result;
  }

  Future<Map<String, dynamic>> adminLogin(
      String phone, String password) async {
    final result = await ApiService.adminLogin(phone, password);
    if (result['success'] == true) {
      final data  = Map<String, dynamic>.from(result['data'] as Map);
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString('fc_admin_token', data['token'].toString());
      _isAdmin = true;
      notifyListeners();
    }
    return result;
  }

  Future<void> logout() async {
    _user    = null;
    _isAdmin = false;
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove('fc_token');
    await prefs.remove('fc_user');
    await prefs.remove('fc_admin_token');
    notifyListeners();
  }

  void addToCart(Map<String, dynamic> item) {
    // FIX: use safeInt so "220" (String) and 220 (int) both work
    final id  = safeInt(item['id']);
    final idx = _cart.indexWhere((c) => c.id == id);
    if (idx >= 0) {
      _cart[idx].qty++;
    } else {
      _cart.add(CartItem(
        id:    id,
        name:  item['name']?.toString() ?? '',
        price: safeInt(item['price']),
        img:   item['img_url']?.toString() ?? '',
      ));
    }
    notifyListeners();
  }

  void removeFromCart(int id) {
    final idx = _cart.indexWhere((c) => c.id == id);
    if (idx < 0) return;
    if (_cart[idx].qty > 1) {
      _cart[idx].qty--;
    } else {
      _cart.removeAt(idx);
    }
    notifyListeners();
  }

  void clearCart() {
    _cart.clear();
    notifyListeners();
  }

  int cartQty(int id) {
    final idx = _cart.indexWhere((c) => c.id == id);
    return idx >= 0 ? _cart[idx].qty : 0;
  }

  Future<void> loadMenu({String? category}) async {
    _menuLoading = true;
    notifyListeners();
    try {
      _menuItems = await ApiService.getMenu(category: category);
    } catch (_) {
      _menuItems = [];
    }
    _menuLoading = false;
    notifyListeners();
  }
}
