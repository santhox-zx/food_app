// lib/services/api_service.dart
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class ApiService {
  // ── Change to your server IP/domain ──────────────────────
  // Local web browser:
  // static const String baseUrl = 'http://localhost:3000/api';
  // Real Device:
  static const String baseUrl = 'http://10.100.168.141:3000/api';

  // ── HEADERS ───────────────────────────────────────────────
  static Future<Map<String, String>> _headers({
    bool auth  = false,
    bool admin = false,
  }) async {
    final h = <String, String>{'Content-Type': 'application/json'};
    if (auth || admin) {
      final prefs = await SharedPreferences.getInstance();
      final key   = admin ? 'fc_admin_token' : 'fc_token';
      final token = prefs.getString(key);
      if (token != null) h['Authorization'] = 'Bearer $token';
    }
    return h;
  }

  // ── RESPONSE HANDLER ──────────────────────────────────────
  static Map<String, dynamic> _handle(http.Response res) {
    try {
      final body = json.decode(res.body);
      if (res.statusCode >= 200 && res.statusCode < 300) {
        return {'success': true, 'data': body};
      }
      final msg = (body is Map && body['error'] != null)
          ? body['error'].toString()
          : 'Request failed (${res.statusCode})';
      return {'success': false, 'error': msg};
    } catch (_) {
      return {'success': false, 'error': 'Invalid server response'};
    }
  }

  // ── AUTH ──────────────────────────────────────────────────
  static Future<Map<String, dynamic>> register(
      String name, String phone, String password) async {
    try {
      final res = await http.post(
        Uri.parse('$baseUrl/auth/register'),
        headers: await _headers(),
        body: json.encode({'name': name, 'phone': phone, 'password': password}),
      ).timeout(const Duration(seconds: 15));
      return _handle(res);
    } catch (e) {
      return {'success': false, 'error': 'Connection failed: $e'};
    }
  }

  static Future<Map<String, dynamic>> login(
      String phone, String password) async {
    try {
      final res = await http.post(
        Uri.parse('$baseUrl/auth/login'),
        headers: await _headers(),
        body: json.encode({'phone': phone, 'password': password}),
      ).timeout(const Duration(seconds: 15));
      return _handle(res);
    } catch (e) {
      return {'success': false, 'error': 'Connection failed: $e'};
    }
  }

  /// Admin login now uses PHONE + PASSWORD (not username)
  static Future<Map<String, dynamic>> adminLogin(
      String phone, String password) async {
    try {
      final res = await http.post(
        Uri.parse('$baseUrl/auth/admin/login'),
        headers: await _headers(),
        body: json.encode({'phone': phone, 'password': password}),
      ).timeout(const Duration(seconds: 15));
      return _handle(res);
    } catch (e) {
      return {'success': false, 'error': 'Connection failed: $e'};
    }
  }

  // ── MENU ──────────────────────────────────────────────────
  static Future<List<dynamic>> getMenu({String? category}) async {
    try {
      final q   = (category != null && category != 'all') ? '?category=$category' : '';
      final res = await http.get(
        Uri.parse('$baseUrl/menu$q'),
        headers: await _headers(),
      ).timeout(const Duration(seconds: 15));
      if (res.statusCode == 200) return json.decode(res.body) as List;
      return [];
    } catch (_) {
      return [];
    }
  }

  static Future<Map<String, dynamic>> addMenuItem(
      Map<String, dynamic> item) async {
    try {
      final res = await http.post(
        Uri.parse('$baseUrl/menu'),
        headers: await _headers(admin: true),
        body: json.encode(item),
      ).timeout(const Duration(seconds: 15));
      return _handle(res);
    } catch (e) {
      return {'success': false, 'error': '$e'};
    }
  }

  static Future<Map<String, dynamic>> updateMenuItem(
      int id, Map<String, dynamic> item) async {
    try {
      final res = await http.put(
        Uri.parse('$baseUrl/menu/$id'),
        headers: await _headers(admin: true),
        body: json.encode(item),
      ).timeout(const Duration(seconds: 15));
      return _handle(res);
    } catch (e) {
      return {'success': false, 'error': '$e'};
    }
  }

  static Future<Map<String, dynamic>> toggleMenuItem(int id) async {
    try {
      final res = await http.patch(
        Uri.parse('$baseUrl/menu/$id/toggle'),
        headers: await _headers(admin: true),
      ).timeout(const Duration(seconds: 15));
      return _handle(res);
    } catch (e) {
      return {'success': false, 'error': '$e'};
    }
  }

  static Future<Map<String, dynamic>> deleteMenuItem(int id) async {
    try {
      final res = await http.delete(
        Uri.parse('$baseUrl/menu/$id'),
        headers: await _headers(admin: true),
      ).timeout(const Duration(seconds: 15));
      return _handle(res);
    } catch (e) {
      return {'success': false, 'error': '$e'};
    }
  }

  // ── ORDERS ────────────────────────────────────────────────
  static Future<Map<String, dynamic>> placeOrder(
      Map<String, dynamic> order) async {
    try {
      final res = await http.post(
        Uri.parse('$baseUrl/orders'),
        headers: await _headers(auth: true),
        body: json.encode(order),
      ).timeout(const Duration(seconds: 20));
      return _handle(res);
    } catch (e) {
      return {'success': false, 'error': 'Connection failed: $e'};
    }
  }

  static Future<List<dynamic>> getMyOrders() async {
    try {
      final res = await http.get(
        Uri.parse('$baseUrl/orders/my'),
        headers: await _headers(auth: true),
      ).timeout(const Duration(seconds: 15));
      if (res.statusCode == 200) return json.decode(res.body) as List;
      return [];
    } catch (_) {
      return [];
    }
  }

  /// Customer cancels their own order (only allowed when status = 'Received')
  static Future<Map<String, dynamic>> cancelMyOrder(
      String orderId, {String reason = 'Cancelled by customer'}) async {
    try {
      final res = await http.patch(
        Uri.parse('$baseUrl/orders/my/$orderId/cancel'),
        headers: await _headers(auth: true),
        body: json.encode({'reason': reason}),
      ).timeout(const Duration(seconds: 15));
      return _handle(res);
    } catch (e) {
      return {'success': false, 'error': '$e'};
    }
  }

  static Future<List<dynamic>> getAllOrders() async {
    try {
      final res = await http.get(
        Uri.parse('$baseUrl/orders'),
        headers: await _headers(admin: true),
      ).timeout(const Duration(seconds: 15));
      if (res.statusCode == 200) return json.decode(res.body) as List;
      return [];
    } catch (_) {
      return [];
    }
  }

  static Future<Map<String, dynamic>> updateOrderStatus(
      String id, String status) async {
    try {
      final res = await http.patch(
        Uri.parse('$baseUrl/orders/$id/status'),
        headers: await _headers(admin: true),
        body: json.encode({'status': status}),
      ).timeout(const Duration(seconds: 15));
      return _handle(res);
    } catch (e) {
      return {'success': false, 'error': '$e'};
    }
  }

  static Future<Map<String, dynamic>> assignDeliveryBoy(
      String orderId, int boyId) async {
    try {
      final res = await http.patch(
        Uri.parse('$baseUrl/orders/$orderId/assign'),
        headers: await _headers(admin: true),
        body: json.encode({'delivery_boy_id': boyId}),
      ).timeout(const Duration(seconds: 15));
      return _handle(res);
    } catch (e) {
      return {'success': false, 'error': '$e'};
    }
  }

  static Future<Map<String, dynamic>> getDashboardStats() async {
    try {
      final res = await http.get(
        Uri.parse('$baseUrl/orders/stats/dashboard'),
        headers: await _headers(admin: true),
      ).timeout(const Duration(seconds: 15));
      return _handle(res);
    } catch (e) {
      return {'success': false, 'error': '$e'};
    }
  }

  static Future<Map<String, dynamic>> getRevenueStats({
      String period = 'weekly',
      DateTime? from,
      DateTime? to,
  }) async {
    try {
      final Map<String, String> qp = {'period': period};
      if (period == 'custom') {
        if (from == null || to == null) {
          return {'success': false, 'error': 'Both from and to dates are required for custom period'};
        }
        qp['from'] = from.toIso8601String().split('T').first;
        qp['to'] = to.toIso8601String().split('T').first;
      }
      final query = Uri(queryParameters: qp).query;
      final res = await http.get(
        Uri.parse('$baseUrl/orders/stats/revenue?$query'),
        headers: await _headers(admin: true),
      ).timeout(const Duration(seconds: 15));
      return _handle(res);
    } catch (e) {
      return {'success': false, 'error': '$e'};
    }
  }

  // ── DELIVERY BOYS ─────────────────────────────────────────
  static Future<List<dynamic>> getDeliveryBoys() async {
    try {
      final res = await http.get(
        Uri.parse('$baseUrl/delivery'),
        headers: await _headers(admin: true),
      ).timeout(const Duration(seconds: 15));
      if (res.statusCode == 200) return json.decode(res.body) as List;
      return [];
    } catch (_) {
      return [];
    }
  }

  static Future<Map<String, dynamic>> toggleDeliveryBoy(int id) async {
    try {
      final res = await http.patch(
        Uri.parse('$baseUrl/delivery/$id/toggle'),
        headers: await _headers(admin: true),
      ).timeout(const Duration(seconds: 15));
      return _handle(res);
    } catch (e) {
      return {'success': false, 'error': '$e'};
    }
  }

  // ── CUSTOMERS ─────────────────────────────────────────────
  static Future<List<dynamic>> getCustomers() async {
    try {
      final res = await http.get(
        Uri.parse('$baseUrl/customers'),
        headers: await _headers(admin: true),
      ).timeout(const Duration(seconds: 15));
      if (res.statusCode == 200) return json.decode(res.body) as List;
      return [];
    } catch (_) {
      return [];
    }
  }

  // ── DELIVERY BOY ADD/UPDATE (admin) ──────────────────
  static Future<Map<String, dynamic>> addDeliveryBoy(
      Map<String, dynamic> boy) async {
    try {
      final res = await http.post(
        Uri.parse('$baseUrl/delivery'),
        headers: await _headers(admin: true),
        body: json.encode(boy),
      ).timeout(const Duration(seconds: 15));
      return _handle(res);
    } catch (e) {
      return {'success': false, 'error': '$e'};
    }
  }

  static Future<Map<String, dynamic>> updateDeliveryBoy(
      int id, Map<String, dynamic> boy) async {
    try {
      final res = await http.put(
        Uri.parse('$baseUrl/delivery/$id'),
        headers: await _headers(admin: true),
        body: json.encode(boy),
      ).timeout(const Duration(seconds: 15));
      return _handle(res);
    } catch (e) {
      return {'success': false, 'error': '$e'};
    }
  }

  /// Customer confirms they received the order (OutForDelivery → Delivered)
  static Future<Map<String, dynamic>> confirmDelivery(String orderId) async {
    try {
      final res = await http.patch(
        Uri.parse('$baseUrl/orders/my/$orderId/delivered'),
        headers: await _headers(auth: true),
      ).timeout(const Duration(seconds: 15));
      return _handle(res);
    } catch (e) {
      return {'success': false, 'error': '$e'};
    }
  }
}
