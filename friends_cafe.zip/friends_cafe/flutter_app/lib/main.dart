// lib/main.dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:go_router/go_router.dart';
import 'services/app_provider.dart';
import 'utils/theme.dart';

import 'screens/customer/home_screen.dart';
import 'screens/customer/menu_screen.dart';
import 'screens/customer/cart_screen.dart';
import 'screens/customer/checkout_screen.dart';
import 'screens/customer/order_confirm_screen.dart';
import 'screens/customer/my_orders_screen.dart';
import 'screens/customer/login_screen.dart';

import 'screens/admin/admin_shell.dart';
import 'screens/admin/dashboard_screen.dart';
import 'screens/admin/orders_screen.dart';
import 'screens/admin/menu_management_screen.dart';
import 'screens/admin/delivery_screen.dart';
import 'screens/admin/customers_screen.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(
    ChangeNotifierProvider(
      create: (_) => AppProvider(),
      child: const FriendsCafeApp(),
    ),
  );
}

class FriendsCafeApp extends StatelessWidget {
  const FriendsCafeApp({super.key});

  @override
  Widget build(BuildContext context) {
    final router = GoRouter(
      initialLocation: '/',
      routes: [
        GoRoute(path: '/',         builder: (_, __) => const HomeScreen()),
        GoRoute(path: '/menu',     builder: (_, __) => const MenuScreen()),
        GoRoute(path: '/cart',     builder: (_, __) => const CartScreen()),
        GoRoute(path: '/checkout', builder: (_, __) => const CheckoutScreen()),
        GoRoute(
          path: '/order-confirmed',
          builder: (_, state) {
            final raw = state.extra; final order = raw is Map ? Map<String, dynamic>.from(raw) : <String, dynamic>{};
            return OrderConfirmScreen(order: order);
          },
        ),
        GoRoute(path: '/my-orders', builder: (_, __) => const MyOrdersScreen()),
        GoRoute(path: '/login',    builder: (_, __) => const LoginScreen()),
        GoRoute(path: '/admin/login', builder: (_, __) => const LoginScreen()),
        ShellRoute(
          builder: (_, __, child) => AdminShell(child: child),
          routes: [
            GoRoute(path: '/admin',           builder: (_, __) => const DashboardScreen()),
            GoRoute(path: '/admin/orders',    builder: (_, __) => const AdminOrdersScreen()),
            GoRoute(path: '/admin/menu',      builder: (_, __) => const MenuManagementScreen()),
            GoRoute(path: '/admin/delivery',  builder: (_, __) => const DeliveryScreen()),
            GoRoute(path: '/admin/customers', builder: (_, __) => const CustomersScreen()),
          ],
        ),
      ],
    );

    return MaterialApp.router(
      title: 'Friends Cafe',
      theme: AppTheme.light,
      routerConfig: router,
      debugShowCheckedModeBanner: false,
    );
  }
}
