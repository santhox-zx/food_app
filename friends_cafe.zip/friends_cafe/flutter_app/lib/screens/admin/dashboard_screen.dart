// lib/screens/admin/dashboard_screen.dart
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../utils/theme.dart';
import '../../services/api_service.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});
  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  Map<String, dynamic>? _stats;
  List<dynamic> _recentOrders = [];
  bool    _loading = true;
  String? _error;

  String _revenuePeriod = 'weekly';
  DateTime? _customFrom;
  DateTime? _customTo;
  Map<String, dynamic>? _revenueSummary;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() { _loading = true; _error = null; });

    try {
      final sr = await ApiService.getDashboardStats();
      final rs = await ApiService.getRevenueStats(period: _revenuePeriod, from: _customFrom, to: _customTo);
      final orders = await ApiService.getAllOrders();
      if (!mounted) return;
      setState(() {
        _stats = sr['success'] == true
            ? Map<String, dynamic>.from(sr['data'] as Map)
            : null;
        _revenueSummary = rs['success'] == true
            ? Map<String, dynamic>.from(rs['data'] as Map)
            : {'total_revenue': 0, 'total_orders': 0};
        _recentOrders = orders.take(5).toList();
        _loading = false;
      });
    } catch (e) {
      if (mounted) setState(() { _error = '$e'; _loading = false; });
    }
  }

  Future<void> _updateRevenueFilter({required String period, DateTime? from, DateTime? to}) async {
    setState(() {
      _revenuePeriod = period;
      _customFrom = from;
      _customTo = to;
      _loading = true;
      _error = null;
    });

    try {
      final rs = await ApiService.getRevenueStats(period: period, from: from, to: to);
      if (!mounted) return;
      setState(() {
        _revenueSummary = rs['success'] == true
            ? Map<String, dynamic>.from(rs['data'] as Map)
            : {'total_revenue': 0, 'total_orders': 0};
        _loading = false;
      });
    } catch (e) {
      if (mounted) setState(() { _error = '$e'; _loading = false; });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF0ECE7),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: AppColors.terracotta))
          : RefreshIndicator(
              onRefresh: _load,
              color: AppColors.terracotta,
              child: SingleChildScrollView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.all(24),
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 1000),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text('Dashboard',
                              style: TextStyle(
                                  fontSize: 24,
                                  fontWeight: FontWeight.w600,
                                  color: AppColors.charcoal)),
                          Text('Friends Cafe Admin',
                              style: TextStyle(
                                  color: Colors.grey[600], fontSize: 13)),
                        ],
                      ),
                      const Divider(color: AppColors.terracotta, thickness: 2, height: 24),

                      if (_error != null)
                        Container(
                          padding: const EdgeInsets.all(12),
                          margin: const EdgeInsets.only(bottom: 16),
                          decoration: BoxDecoration(
                              color: const Color(0xFFFCE4EC),
                              borderRadius: BorderRadius.circular(8)),
                          child: Text('Error: $_error',
                              style: const TextStyle(color: AppColors.error)),
                        ),

                      if (_stats != null) ...[
                        LayoutBuilder(builder: (_, c) {
                          final cols = c.maxWidth > 600 ? 4 : 2;
                          return GridView.count(
                            crossAxisCount: cols,
                            crossAxisSpacing: 14, mainAxisSpacing: 14,
                            shrinkWrap: true,
                            physics: const NeverScrollableScrollPhysics(),
                            childAspectRatio: 1.7,
                            children: [
                              _StatCard(value: '₹${_stats!['total_revenue'] ?? 0}', label: 'Total Revenue', color: AppColors.terracotta),
                              _StatCard(value: '${_stats!['total_orders'] ?? 0}',   label: 'Total Orders',  color: AppColors.forest),
                              _StatCard(value: '${_stats!['pending'] ?? 0}',         label: 'Pending',       color: const Color(0xFFF39C12)),
                              _StatCard(value: '${_stats!['customers'] ?? 0}',       label: 'Customers',     color: const Color(0xFF1565C0)),
                            ],
                          );
                        }),
                        const SizedBox(height: 24),
                      ],

                      // Revenue period controls
                      Container(
                        padding: const EdgeInsets.all(14),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: AppColors.forest.withOpacity(0.2)),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text('Revenue by period',
                                style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
                            const SizedBox(height: 10),
                            Wrap(
                              spacing: 8,
                              runSpacing: 8,
                              children: ['weekly', 'monthly', 'yearly', 'custom'].map((period) {
                                final label = period[0].toUpperCase() + period.substring(1);
                                final active = _revenuePeriod == period;
                                return ChoiceChip(
                                  label: Text(label),
                                  selected: active,
                                  onSelected: (_) async {
                                    if (period == 'custom') {
                                      final today = DateTime.now();
                                      final from = _customFrom ?? today.subtract(const Duration(days: 30));
                                      final to = _customTo ?? today;
                                      await _updateRevenueFilter(period: 'custom', from: from, to: to);
                                    } else {
                                      await _updateRevenueFilter(period: period);
                                    }
                                  },
                                );
                              }).toList(),
                            ),

                            if (_revenuePeriod == 'custom') ...[
                              const SizedBox(height: 12),
                              Row(
                                children: [
                                  Expanded(
                                    child: ElevatedButton(
                                      onPressed: () async {
                                        final picked = await showDatePicker(
                                          context: context,
                                          initialDate: _customFrom ?? DateTime.now().subtract(const Duration(days: 30)),
                                          firstDate: DateTime(2000),
                                          lastDate: DateTime.now(),
                                        );
                                        if (picked != null) {
                                          setState(() {
                                            _customFrom = picked;
                                          });
                                          if (_customTo != null && _customFrom != null) {
                                            await _updateRevenueFilter(period: 'custom', from: _customFrom, to: _customTo);
                                          }
                                        }
                                      },
                                      child: Text(_customFrom != null
                                          ? 'From: ${_customFrom!.toIso8601String().split('T').first}'
                                          : 'Select start date'),
                                    ),
                                  ),
                                  const SizedBox(width: 10),
                                  Expanded(
                                    child: ElevatedButton(
                                      onPressed: () async {
                                        final picked = await showDatePicker(
                                          context: context,
                                          initialDate: _customTo ?? DateTime.now(),
                                          firstDate: DateTime(2000),
                                          lastDate: DateTime.now(),
                                        );
                                        if (picked != null) {
                                          setState(() {
                                            _customTo = picked;
                                          });
                                          if (_customFrom != null && _customTo != null) {
                                            await _updateRevenueFilter(period: 'custom', from: _customFrom, to: _customTo);
                                          }
                                        }
                                      },
                                      child: Text(_customTo != null
                                          ? 'To: ${_customTo!.toIso8601String().split('T').first}'
                                          : 'Select end date'),
                                    ),
                                  ),
                                ],
                              ),
                            ],

                            const SizedBox(height: 12),
                            Text('Filtered revenue: ₹${_revenueSummary?['total_revenue'] ?? 0}',
                                style: const TextStyle(fontWeight: FontWeight.w600)),
                            Text('Orders in range: ${_revenueSummary?['total_orders'] ?? 0}'),
                            Text('Total income revenue: ₹${_stats?['total_revenue'] ?? 0}'),
                          ],
                        ),
                      ),

                      const SizedBox(height: 24),

                      const Text('Recent Orders',
                          style: TextStyle(
                              fontSize: 18, fontWeight: FontWeight.w600,
                              color: AppColors.charcoal)),
                      const Divider(color: AppColors.terracotta, thickness: 2, height: 16),

                      if (_recentOrders.isEmpty)
                        Padding(
                          padding: const EdgeInsets.all(24),
                          child: Center(
                              child: Text('No orders yet',
                                  style: TextStyle(color: Colors.grey[500]))),
                        )
                      else
                        ..._recentOrders.map((o) => _RecentTile(order: o)),

                      const SizedBox(height: 8),
                      TextButton(
                        onPressed: () => context.go('/admin/orders'),
                        child: Text('View All Orders →',
                            style: TextStyle(
                                color: AppColors.terracotta,
                                fontWeight: FontWeight.w600)),
                      ),
                    ],
                  ),
                ),
              ),
            ),
    );
  }
}

class _StatCard extends StatelessWidget {
  final String value, label;
  final Color color;
  const _StatCard({required this.value, required this.label, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
        border: Border(left: BorderSide(color: color, width: 3)),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.06), blurRadius: 8, offset: const Offset(0,2))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(value, style: TextStyle(fontSize: 22, fontWeight: FontWeight.w700, color: color, height: 1)),
          const SizedBox(height: 4),
          Text(label, style: const TextStyle(fontSize: 11, color: Colors.grey, letterSpacing: 0.4)),
        ],
      ),
    );
  }
}

class _RecentTile extends StatelessWidget {
  final Map<String, dynamic> order;
  const _RecentTile({required this.order});

  @override
  Widget build(BuildContext context) {
    final status = order['status']?.toString() ?? 'Received';
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 6, offset: const Offset(0,2))],
      ),
      child: Row(children: [
        Expanded(child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(order['id']?.toString() ?? '',
                style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
            Text(order['customer_name']?.toString() ?? '',
                style: const TextStyle(color: Colors.grey, fontSize: 12)),
          ],
        )),
        _StatusBadge(status: status),
        const SizedBox(width: 12),
        Text('₹${order['total']}',
            style: TextStyle(fontWeight: FontWeight.w700, color: AppColors.terracotta)),
      ]),
    );
  }
}

class _StatusBadge extends StatelessWidget {
  final String status;
  const _StatusBadge({required this.status});
  @override
  Widget build(BuildContext context) {
    Color bg, fg;
    switch (status) {
      case 'Received':       bg = const Color(0xFFFFF3E0); fg = const Color(0xFFE67E22); break;
      case 'Preparing':      bg = const Color(0xFFFFF8E1); fg = const Color(0xFFF39C12); break;
      case 'OutForDelivery': bg = const Color(0xFFE8F5E9); fg = const Color(0xFF27AE60); break;
      case 'Delivered':      bg = const Color(0xFFE3F2FD); fg = const Color(0xFF1565C0); break;
      case 'Cancelled':      bg = const Color(0xFFFCE4EC); fg = const Color(0xFFC0392B); break;
      default:               bg = const Color(0xFFF5F5F5); fg = Colors.grey;
    }
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(50)),
      child: Text(status == 'OutForDelivery' ? 'Out For Delivery' : status,
          style: TextStyle(color: fg, fontSize: 11, fontWeight: FontWeight.w600, letterSpacing: 0.5)),
    );
  }
}
