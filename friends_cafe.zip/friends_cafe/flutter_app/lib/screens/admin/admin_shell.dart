// lib/screens/admin/admin_shell.dart
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../../utils/theme.dart';
import '../../services/app_provider.dart';

// Navigation items defined at TOP LEVEL so all classes can access them
const List<Map<String, dynamic>> kAdminNavItems = [
  {'icon': Icons.dashboard_outlined,       'label': 'Dashboard', 'path': '/admin'},
  {'icon': Icons.receipt_long_outlined,    'label': 'Orders',    'path': '/admin/orders'},
  {'icon': Icons.restaurant_menu_outlined, 'label': 'Menu',      'path': '/admin/menu'},
  {'icon': Icons.delivery_dining_outlined, 'label': 'Delivery',  'path': '/admin/delivery'},
  {'icon': Icons.people_outline,           'label': 'Customers', 'path': '/admin/customers'},
];

class AdminShell extends StatefulWidget {
  final Widget child;
  const AdminShell({super.key, required this.child});

  @override
  State<AdminShell> createState() => _AdminShellState();
}

class _AdminShellState extends State<AdminShell> {
  @override
  void initState() {
    super.initState();
    // Guard: redirect to admin login if not authenticated
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!context.read<AppProvider>().isAdmin) {
        context.go('/login');
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final isWide = MediaQuery.of(context).size.width > 768;
    if (isWide) {
      return Scaffold(
        body: Row(
          children: [
            const _Sidebar(),
            Expanded(child: widget.child),
          ],
        ),
      );
    }
    return Scaffold(
      appBar: AppBar(
        backgroundColor: AppColors.charcoal,
        foregroundColor: AppColors.cream,
        automaticallyImplyLeading: false,
        title: const Text(
          'Friends Cafe — Admin',
          style: TextStyle(fontSize: 15, fontWeight: FontWeight.w600),
        ),
        actions: [
          Builder(
            builder: (ctx) => IconButton(
              icon: const Icon(Icons.logout, size: 20),
              onPressed: () async {
                await ctx.read<AppProvider>().logout();
                ctx.go('/');
              },
            ),
          ),
        ],
      ),
      body: widget.child,
      bottomNavigationBar: const _BottomNav(),
    );
  }
}

// ── Sidebar (wide screens) ────────────────────────────────
class _Sidebar extends StatelessWidget {
  const _Sidebar();

  @override
  Widget build(BuildContext context) {
    final location = GoRouterState.of(context).uri.path;

    return Container(
      width: 220,
      color: AppColors.charcoal,
      child: Column(
        children: [
          // Logo area
          Container(
            width: double.infinity,
            padding: const EdgeInsets.fromLTRB(20, 48, 20, 16),
            decoration: const BoxDecoration(
              border: Border(bottom: BorderSide(color: Colors.white10)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Friends Cafe',
                  style: TextStyle(
                    fontSize: 16,
                    color: AppColors.cream,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                Text(
                  'ADMIN PANEL',
                  style: TextStyle(
                    fontSize: 9,
                    color: AppColors.muted.withOpacity(0.5),
                    letterSpacing: 2,
                  ),
                ),
              ],
            ),
          ),

          // Nav items
          Expanded(
            child: ListView(
              padding: const EdgeInsets.symmetric(vertical: 8),
              children: kAdminNavItems.map((item) {
                final path   = item['path'] as String;
                final active = _isActive(location, path);
                return GestureDetector(
                  onTap: () => context.go(path),
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 20, vertical: 13),
                    decoration: BoxDecoration(
                      color: active
                          ? AppColors.terracotta.withOpacity(0.2)
                          : Colors.transparent,
                      border: Border(
                        right: BorderSide(
                          color: active
                              ? AppColors.terracotta
                              : Colors.transparent,
                          width: 3,
                        ),
                      ),
                    ),
                    child: Row(
                      children: [
                        Icon(
                          item['icon'] as IconData,
                          size: 18,
                          color: active
                              ? AppColors.cream
                              : AppColors.cream.withOpacity(0.5),
                        ),
                        const SizedBox(width: 12),
                        Text(
                          item['label'] as String,
                          style: TextStyle(
                            fontSize: 13,
                            color: active
                                ? AppColors.cream
                                : AppColors.cream.withOpacity(0.5),
                            fontWeight: active
                                ? FontWeight.w500
                                : FontWeight.w400,
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              }).toList(),
            ),
          ),

          // Logout
          Container(
            padding: const EdgeInsets.all(16),
            decoration: const BoxDecoration(
              border: Border(top: BorderSide(color: Colors.white10)),
            ),
            child: GestureDetector(
              onTap: () async {
                await context.read<AppProvider>().logout();
                context.go('/');
              },
              child: Row(
                children: [
                  Icon(Icons.logout,
                      size: 16,
                      color: AppColors.cream.withOpacity(0.4)),
                  const SizedBox(width: 8),
                  Text(
                    'Logout',
                    style: TextStyle(
                      color: AppColors.cream.withOpacity(0.4),
                      fontSize: 13,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  bool _isActive(String location, String path) {
    if (path == '/admin') return location == '/admin';
    return location.startsWith(path);
  }
}

// ── Bottom navigation (narrow screens / phones) ───────────
class _BottomNav extends StatelessWidget {
  const _BottomNav();

  @override
  Widget build(BuildContext context) {
    final location = GoRouterState.of(context).uri.path;

    return Container(
      color: AppColors.charcoal,
      child: SafeArea(
        top: false,
        child: SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(
            children: kAdminNavItems.map((item) {
              final path   = item['path'] as String;
              final active = path == '/admin'
                  ? location == '/admin'
                  : location.startsWith(path);
              return GestureDetector(
                onTap: () => context.go(path),
                child: Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 16, vertical: 10),
                  decoration: BoxDecoration(
                    border: Border(
                      bottom: BorderSide(
                        color: active
                            ? AppColors.terracotta
                            : Colors.transparent,
                        width: 2,
                      ),
                    ),
                  ),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(
                        item['icon'] as IconData,
                        size: 20,
                        color: active
                            ? AppColors.terracotta
                            : AppColors.cream.withOpacity(0.5),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        item['label'] as String,
                        style: TextStyle(
                          fontSize: 10,
                          color: active
                              ? AppColors.terracotta
                              : AppColors.cream.withOpacity(0.5),
                        ),
                      ),
                    ],
                  ),
                ),
              );
            }).toList(),
          ),
        ),
      ),
    );
  }
}
