// lib/screens/admin/customers_screen.dart
import 'package:flutter/material.dart';
import '../../utils/theme.dart';
import '../../services/api_service.dart';

class CustomersScreen extends StatefulWidget {
  const CustomersScreen({super.key});
  @override
  State<CustomersScreen> createState() =>
      _CustomersScreenState();
}

class _CustomersScreenState extends State<CustomersScreen> {
  List<dynamic> _customers = [];
  bool   _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() { _loading = true; _error = null; });
    try {
      final customers = await ApiService.getCustomers();
      if (!mounted) return;
      setState(() { _customers = customers; _loading = false; });
    } catch (e) {
      if (mounted)
        setState(() { _error = '$e'; _loading = false; });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF0ECE7),
      body: _loading
          ? const Center(
              child: CircularProgressIndicator(
                  color: AppColors.terracotta))
          : RefreshIndicator(
              onRefresh: _load,
              color: AppColors.terracotta,
              child: SingleChildScrollView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.all(24),
                child: ConstrainedBox(
                  constraints:
                      const BoxConstraints(maxWidth: 1000),
                  child: Column(
                    crossAxisAlignment:
                        CrossAxisAlignment.start,
                    children: [
                      const Text('Customers',
                          style: TextStyle(
                              fontSize: 24,
                              fontWeight: FontWeight.w600)),
                      const Divider(
                          color: AppColors.terracotta,
                          thickness: 2,
                          height: 24),
                      if (_error != null)
                        Text('Error: $_error',
                            style: const TextStyle(
                                color: AppColors.error)),
                      if (_customers.isEmpty &&
                          _error == null)
                        Center(
                          child: Padding(
                            padding: const EdgeInsets.all(48),
                            child: Column(children: [
                              Icon(Icons.people_outline,
                                  size: 48,
                                  color: Colors.grey[400]),
                              const SizedBox(height: 12),
                              Text(
                                  'No registered customers yet',
                                  style: TextStyle(
                                      color: Colors.grey[500])),
                            ]),
                          ),
                        )
                      else
                        Container(
                          decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius:
                                  BorderRadius.circular(8),
                              boxShadow: [
                                BoxShadow(
                                    color: Colors.black
                                        .withOpacity(0.06),
                                    blurRadius: 8,
                                    offset: const Offset(0, 2))
                              ]),
                          child: LayoutBuilder(
                            builder: (_, c) => c.maxWidth > 600
                                ? _TableView(
                                    customers: _customers)
                                : _CardView(
                                    customers: _customers),
                          ),
                        ),
                    ],
                  ),
                ),
              ),
            ),
    );
  }
}

class _TableView extends StatelessWidget {
  final List<dynamic> customers;
  const _TableView({required this.customers});

  @override
  Widget build(BuildContext context) {
    return Table(
      columnWidths: const {
        0: FlexColumnWidth(2),
        1: FlexColumnWidth(1.5),
        2: FlexColumnWidth(0.8),
        3: FlexColumnWidth(1),
        4: FlexColumnWidth(1.4),
      },
      children: [
        TableRow(
          decoration:
              const BoxDecoration(color: Color(0xFFF9F7F4)),
          children: ['Name', 'Phone', 'Orders', 'Spent', 'Joined']
              .map((h) => Padding(
                    padding: const EdgeInsets.all(12),
                    child: Text(h,
                        style: const TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.w500,
                            color: Colors.grey,
                            letterSpacing: 1)),
                  ))
              .toList(),
        ),
        ...customers.map((c) {
          final dt     = DateTime.tryParse(
              c['created_at']?.toString() ?? '');
          final joined = dt != null
              ? '${dt.day}/${dt.month}/${dt.year}'
              : '—';
          return TableRow(
            decoration: const BoxDecoration(
                border: Border(
                    bottom: BorderSide(
                        color: Color(0xFFF5F5F5)))),
            children: [
              _cell(c['name']?.toString() ?? '',
                  bold: true),
              _cell(c['phone']?.toString() ?? ''),
              _cell('${c['order_count'] ?? 0}'),
              Padding(
                padding: const EdgeInsets.all(12),
                child: Text(
                    '₹${c['total_spent'] ?? 0}',
                    style: TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w700,
                        color: AppColors.terracotta)),
              ),
              _cell(joined,
                  color: Colors.grey),
            ],
          );
        }),
      ],
    );
  }

  Widget _cell(String text,
      {bool bold = false, Color? color}) {
    return Padding(
      padding: const EdgeInsets.all(12),
      child: Text(text,
          style: TextStyle(
              fontSize: 13,
              fontWeight:
                  bold ? FontWeight.w600 : FontWeight.normal,
              color: color)),
    );
  }
}

class _CardView extends StatelessWidget {
  final List<dynamic> customers;
  const _CardView({required this.customers});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: customers.map((c) {
        final name = c['name']?.toString() ?? '?';
        return Padding(
          padding: const EdgeInsets.all(14),
          child: Row(children: [
            CircleAvatar(
              radius: 20,
              backgroundColor:
                  AppColors.terracotta.withOpacity(0.15),
              child: Text(
                  name.isNotEmpty
                      ? name[0].toUpperCase()
                      : '?',
                  style: const TextStyle(
                      color: AppColors.terracotta,
                      fontWeight: FontWeight.w700)),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment:
                    CrossAxisAlignment.start,
                children: [
                  Text(name,
                      style: const TextStyle(
                          fontWeight: FontWeight.w600,
                          fontSize: 14)),
                  Text(c['phone']?.toString() ?? '',
                      style: const TextStyle(
                          color: Colors.grey,
                          fontSize: 12)),
                ],
              ),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text('${c['order_count'] ?? 0} orders',
                    style: const TextStyle(
                        fontSize: 12, color: Colors.grey)),
                Text('₹${c['total_spent'] ?? 0}',
                    style: TextStyle(
                        fontWeight: FontWeight.w700,
                        color: AppColors.terracotta,
                        fontSize: 14)),
              ],
            ),
          ]),
        );
      }).toList(),
    );
  }
}
