// lib/screens/admin/menu_management_screen.dart
import 'package:flutter/material.dart';
import '../../utils/theme.dart';
import '../../services/api_service.dart';
import '../../utils/safe_parse.dart';

class MenuManagementScreen extends StatefulWidget {
  const MenuManagementScreen({super.key});
  @override
  State<MenuManagementScreen> createState() => _MenuManagementScreenState();
}

class _MenuManagementScreenState extends State<MenuManagementScreen> {
  List<dynamic> _menu   = [];
  bool    _loading = true;
  String? _error;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() { _loading = true; _error = null; });
    try {
      final menu = await ApiService.getMenu();
      if (!mounted) return;
      setState(() { _menu = menu; _loading = false; });
    } catch (e) {
      if (mounted) setState(() { _error = '$e'; _loading = false; });
    }
  }

  void _toast(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(msg),
        backgroundColor: AppColors.charcoal,
        behavior: SnackBarBehavior.floating,
        duration: const Duration(seconds: 2)));
  }

  void _openForm({Map<String, dynamic>? item}) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(16))),
      builder: (_) => _MenuItemForm(
        item: item,
        onSaved: (data) async {
          if (item == null) {
            final r = await ApiService.addMenuItem(data);
            _toast(r['success'] == true ? 'Item added!' : r['error']?.toString() ?? 'Error');
          } else {
            final id = safeInt(item['id']);
            final r  = await ApiService.updateMenuItem(id, data);
            _toast(r['success'] == true ? 'Item updated!' : r['error']?.toString() ?? 'Error');
          }
          _load();
        },
      ),
    );
  }

  Future<void> _toggle(Map<String, dynamic> item) async {
    final wasAvail = item['available'] == 1 || item['available'] == true;
    final r = await ApiService.toggleMenuItem(safeInt(item['id']));
    _toast(r['success'] == true
        ? (wasAvail ? 'Item disabled' : 'Item enabled')
        : r['error']?.toString() ?? 'Error');
    _load();
  }

  Future<void> _delete(int id) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        title: const Text('Delete Item?'),
        content: const Text('This cannot be undone.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
          ElevatedButton(
              onPressed: () => Navigator.pop(context, true),
              style: ElevatedButton.styleFrom(backgroundColor: AppColors.error),
              child: const Text('Delete')),
        ],
      ),
    );
    if (ok != true) return;
    final r = await ApiService.deleteMenuItem(id);
    _toast(r['success'] == true ? 'Item deleted' : r['error']?.toString() ?? 'Error');
    _load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF0ECE7),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: AppColors.terracotta))
          : RefreshIndicator(
              onRefresh: _load,
              color: AppColors.terracotta,
              child: SingleChildScrollView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.all(24),
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 1000),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text('Menu Management',
                              style: TextStyle(fontSize: 24, fontWeight: FontWeight.w600)),
                          ElevatedButton.icon(
                            onPressed: () => _openForm(),
                            icon: const Icon(Icons.add, size: 18),
                            label: const Text('ADD ITEM',
                                style: TextStyle(letterSpacing: 1, fontWeight: FontWeight.w600)),
                            style: ElevatedButton.styleFrom(
                                padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12)),
                          ),
                        ],
                      ),
                      const Divider(color: AppColors.terracotta, thickness: 2, height: 24),
                      if (_error != null)
                        Text('Error: $_error', style: const TextStyle(color: AppColors.error)),
                      if (_menu.isEmpty && _error == null)
                        const Center(child: Padding(
                          padding: EdgeInsets.all(48),
                          child: Text('No menu items yet'),
                        ))
                      else
                        ..._menu.map((item) => _MenuItemCard(
                          item: item,
                          onEdit: () => _openForm(item: Map<String, dynamic>.from(item)),
                          onToggle: () => _toggle(Map<String, dynamic>.from(item)),
                          onDelete: () => _delete(safeInt(item['id'])),
                        )),
                    ],
                  ),
                ),
              ),
            ),
    );
  }
}

// ── Menu item card (replaces table on all screen sizes) ────
class _MenuItemCard extends StatelessWidget {
  final Map<String, dynamic> item;
  final VoidCallback onEdit, onToggle, onDelete;
  const _MenuItemCard({required this.item, required this.onEdit, required this.onToggle, required this.onDelete});

  @override
  Widget build(BuildContext context) {
    final available = item['available'] == 1 || item['available'] == true;
    final rating    = safeDouble(item['rating'], fallback: 4.5);
    final stock     = safeInt(item['stock_qty'], fallback: 99);

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.06), blurRadius: 8, offset: const Offset(0,2))],
      ),
      child: Row(
        children: [
          // Image
          ClipRRect(
            borderRadius: const BorderRadius.horizontal(left: Radius.circular(8)),
            child: Image.network(
              item['img_url']?.toString() ?? '',
              width: 90, height: 90, fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Container(
                  width: 90, height: 90, color: Colors.grey[100],
                  child: const Icon(Icons.fastfood, color: Colors.grey)),
            ),
          ),

          // Content
          Expanded(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(12, 10, 8, 10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(children: [
                    Expanded(
                      child: Text(item['name']?.toString() ?? '',
                          style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 15)),
                    ),
                    _AvailBadge(available: available),
                  ]),
                  const SizedBox(height: 4),
                  // Rating + stock + category
                  Wrap(spacing: 10, children: [
                    Row(mainAxisSize: MainAxisSize.min, children: [
                      const Icon(Icons.star, color: Color(0xFFFFC107), size: 13),
                      const SizedBox(width: 3),
                      Text(rating.toStringAsFixed(1),
                          style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
                    ]),
                    Text('₹${item['price']}',
                        style: TextStyle(color: AppColors.terracotta, fontWeight: FontWeight.w700, fontSize: 13)),
                    Text('Stock: $stock',
                        style: TextStyle(
                            fontSize: 11,
                            color: stock <= 10 ? AppColors.error : Colors.grey[600])),
                    Text(item['category']?.toString() ?? '',
                        style: TextStyle(fontSize: 11, color: Colors.grey[500])),
                  ]),
                  if ((item['description']?.toString() ?? '').isNotEmpty)
                    Padding(
                      padding: const EdgeInsets.only(top: 4),
                      child: Text(item['description'].toString(),
                          style: TextStyle(fontSize: 11, color: Colors.grey[500], height: 1.3),
                          maxLines: 2, overflow: TextOverflow.ellipsis),
                    ),
                ],
              ),
            ),
          ),

          // Actions
          Padding(
            padding: const EdgeInsets.only(right: 10),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                _ActionBtn('✏ Edit', const Color(0xFFE3F2FD), const Color(0xFF1565C0), onEdit),
                const SizedBox(height: 6),
                _ActionBtn(available ? 'Disable' : 'Enable',
                    const Color(0xFFE8F5E9), const Color(0xFF2E7D32), onToggle),
                const SizedBox(height: 6),
                _ActionBtn('🗑 Del', const Color(0xFFFCE4EC), const Color(0xFFC0392B), onDelete),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _AvailBadge extends StatelessWidget {
  final bool available;
  const _AvailBadge({required this.available});
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      decoration: BoxDecoration(
          color: available ? const Color(0xFFE3F2FD) : const Color(0xFFFCE4EC),
          borderRadius: BorderRadius.circular(50)),
      child: Text(available ? 'Available' : 'Unavailable',
          style: TextStyle(
              color: available ? const Color(0xFF1565C0) : const Color(0xFFC0392B),
              fontSize: 10, fontWeight: FontWeight.w600)),
    );
  }
}

class _ActionBtn extends StatelessWidget {
  final String label;
  final Color bg, fg;
  final VoidCallback onTap;
  const _ActionBtn(this.label, this.bg, this.fg, this.onTap);
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
        decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(4)),
        child: Text(label, style: TextStyle(color: fg, fontSize: 11, fontWeight: FontWeight.w600)),
      ),
    );
  }
}

// ── Menu item form ─────────────────────────────────────────
class _MenuItemForm extends StatefulWidget {
  final Map<String, dynamic>? item;
  final Function(Map<String, dynamic>) onSaved;
  const _MenuItemForm({this.item, required this.onSaved});
  @override
  State<_MenuItemForm> createState() => _MenuItemFormState();
}

class _MenuItemFormState extends State<_MenuItemForm> {
  final _nameCtrl  = TextEditingController();
  final _descCtrl  = TextEditingController();
  final _priceCtrl = TextEditingController();
  final _imgCtrl   = TextEditingController();
  final _ratingCtrl = TextEditingController();
  final _stockCtrl = TextEditingController();
  String _cat      = 'seafood';
  bool   _saving   = false;

  static const _cats = ['seafood','chinese','biryani','curries','veg'];

  @override
  void initState() {
    super.initState();
    if (widget.item != null) {
      final i = widget.item!;
      _nameCtrl.text   = i['name']?.toString() ?? '';
      _descCtrl.text   = i['description']?.toString() ?? '';
      _priceCtrl.text  = '${i['price'] ?? ''}';
      _imgCtrl.text    = i['img_url']?.toString() ?? '';
      _ratingCtrl.text = '${i['rating'] ?? '4.5'}';
      _stockCtrl.text  = '${i['stock_qty'] ?? '99'}';
      final cat = i['category']?.toString() ?? 'seafood';
      _cat = _cats.contains(cat) ? cat : 'seafood';
    } else {
      _ratingCtrl.text = '4.5';
      _stockCtrl.text  = '99';
    }
  }

  @override
  void dispose() {
    _nameCtrl.dispose(); _descCtrl.dispose(); _priceCtrl.dispose();
    _imgCtrl.dispose(); _ratingCtrl.dispose(); _stockCtrl.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (_nameCtrl.text.trim().isEmpty || _priceCtrl.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Name and price are required'),
          backgroundColor: AppColors.error));
      return;
    }
    final price = int.tryParse(_priceCtrl.text.trim()) ?? 0;
    if (price <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Enter a valid price'), backgroundColor: AppColors.error));
      return;
    }
    final rating = double.tryParse(_ratingCtrl.text.trim()) ?? 4.5;
    final stock  = int.tryParse(_stockCtrl.text.trim()) ?? 99;

    setState(() => _saving = true);
    await widget.onSaved({
      'name':        _nameCtrl.text.trim(),
      'description': _descCtrl.text.trim(),
      'price':       price,
      'category':    _cat,
      'img_url':     _imgCtrl.text.trim(),
      'rating':      rating.clamp(0.0, 5.0),
      'stock_qty':   stock.clamp(0, 9999),
      'available':   widget.item?['available'] ?? 1,
    });
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.fromLTRB(20, 20, 20, MediaQuery.of(context).viewInsets.bottom + 20),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(child: Container(width: 40, height: 4,
                decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(2)))),
            const SizedBox(height: 14),
            Text(widget.item == null ? 'Add New Item' : 'Edit: ${widget.item!['name']}',
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
            const Divider(color: AppColors.terracotta, thickness: 2, height: 20),

            // Name
            TextField(controller: _nameCtrl,
                decoration: const InputDecoration(labelText: 'Item Name *')),
            const SizedBox(height: 10),

            // Description
            TextField(controller: _descCtrl, maxLines: 2,
                decoration: const InputDecoration(
                    labelText: 'Description', hintText: 'Brief description of the dish')),
            const SizedBox(height: 10),

            // Price + Category row
            Row(children: [
              Expanded(child: TextField(controller: _priceCtrl,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(labelText: 'Price (₹) *'))),
              const SizedBox(width: 10),
              Expanded(child: DropdownButtonFormField<String>(
                value: _cat,
                decoration: const InputDecoration(labelText: 'Category'),
                items: _cats.map((c) => DropdownMenuItem(
                    value: c, child: Text(c, style: const TextStyle(fontSize: 14)))).toList(),
                onChanged: (v) => setState(() => _cat = v ?? _cat),
              )),
            ]),
            const SizedBox(height: 10),

            // Rating + Stock row
            Row(children: [
              Expanded(child: TextField(controller: _ratingCtrl,
                  keyboardType: const TextInputType.numberWithOptions(decimal: true),
                  decoration: const InputDecoration(
                      labelText: 'Rating (0-5)',
                      prefixIcon: Icon(Icons.star, color: Color(0xFFFFC107), size: 18)))),
              const SizedBox(width: 10),
              Expanded(child: TextField(controller: _stockCtrl,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                      labelText: 'Stock Qty',
                      prefixIcon: Icon(Icons.inventory_2_outlined, size: 18)))),
            ]),
            const SizedBox(height: 10),

            // Image URL
            TextField(controller: _imgCtrl,
                decoration: const InputDecoration(labelText: 'Image URL (optional)')),
            const SizedBox(height: 20),

            Row(children: [
              Expanded(child: OutlinedButton(
                onPressed: () => Navigator.pop(context),
                style: OutlinedButton.styleFrom(
                    foregroundColor: Colors.grey, side: BorderSide(color: Colors.grey[300]!)),
                child: const Text('CANCEL'))),
              const SizedBox(width: 10),
              Expanded(child: ElevatedButton(
                onPressed: _saving ? null : _save,
                style: ElevatedButton.styleFrom(backgroundColor: AppColors.forest),
                child: _saving
                    ? const SizedBox(width: 18, height: 18,
                        child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                    : const Text('SAVE', style: TextStyle(letterSpacing: 1.5)),
              )),
            ]),
          ],
        ),
      ),
    );
  }
}
