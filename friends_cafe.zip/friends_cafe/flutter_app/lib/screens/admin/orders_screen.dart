// lib/screens/admin/orders_screen.dart
import 'package:flutter/material.dart';
import '../../utils/theme.dart';
import '../../services/api_service.dart';
import '../../utils/safe_parse.dart';

class AdminOrdersScreen extends StatefulWidget {
  const AdminOrdersScreen({super.key});
  @override
  State<AdminOrdersScreen> createState() => _AdminOrdersScreenState();
}

class _AdminOrdersScreenState extends State<AdminOrdersScreen> {
  List<dynamic> _orders = [];
  List<dynamic> _boys   = [];
  bool    _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() { _loading = true; _error = null; });
    try {
      final orders = await ApiService.getAllOrders();
      final boys   = await ApiService.getDeliveryBoys();
      if (!mounted) return;
      setState(() { _orders = orders; _boys = boys; _loading = false; });
    } catch (e) {
      if (mounted) setState(() { _error = '$e'; _loading = false; });
    }
  }

  Future<void> _updateStatus(String orderId, String status) async {
    final r = await ApiService.updateOrderStatus(orderId, status);
    if (!mounted) return;
    _toast(r['success'] == true
        ? 'Status updated: $status'
        : r['error']?.toString() ?? 'Error');
    _load();
  }

  Future<void> _assign(String orderId, int boyId) async {
    final r = await ApiService.assignDeliveryBoy(orderId, boyId);
    if (!mounted) return;
    if (r['success'] == true) {
      final boy = _boys.firstWhere(
          (b) => _safeInt(b['id']) == boyId,
          orElse: () => {'name': 'Delivery boy'});
      _toast('${boy['name']} assigned');
    } else {
      _toast(r['error']?.toString() ?? 'Error');
    }
    _load();
  }

  void _toast(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(msg),
        backgroundColor: AppColors.charcoal,
        behavior: SnackBarBehavior.floating,
        duration: const Duration(seconds: 2)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF0ECE7),
      body: _loading
          ? const Center(
              child: CircularProgressIndicator(color: AppColors.terracotta))
          : RefreshIndicator(
              onRefresh: _load,
              color: AppColors.terracotta,
              child: SingleChildScrollView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.all(24),
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 1000),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('Orders',
                          style: TextStyle(
                              fontSize: 24, fontWeight: FontWeight.w600)),
                      const Divider(
                          color: AppColors.terracotta,
                          thickness: 2,
                          height: 24),
                      if (_error != null)
                        Padding(
                          padding: const EdgeInsets.only(bottom: 12),
                          child: Text('Error: $_error',
                              style: const TextStyle(
                                  color: AppColors.error)),
                        ),
                      if (_orders.isEmpty && _error == null)
                        Center(
                          child: Padding(
                            padding: const EdgeInsets.all(48),
                            child: Text('No orders yet',
                                style: TextStyle(
                                    color: Colors.grey[500])),
                          ),
                        )
                      else
                        ..._orders.map((o) => _OrderCard(
                              order: o,
                              boys: _boys,
                              onStatusChange: (s) =>
                                  _updateStatus(o['id'].toString(), s),
                              onAssign: (id) =>
                                  _assign(o['id'].toString(), id),
                            )),
                    ],
                  ),
                ),
              ),
            ),
    );
  }
}

// ── Safe int helper ───────────────────────────────────────
// MySQL2 may return ints or strings depending on context
int _safeInt(dynamic v) {
  if (v == null) return 0;
  if (v is int) return v;
  if (v is double) return v.toInt();
  return int.tryParse(v.toString()) ?? 0;
}

// ── Order Card ────────────────────────────────────────────
class _OrderCard extends StatelessWidget {
  final Map<String, dynamic> order;
  final List<dynamic> boys;
  final ValueChanged<String> onStatusChange;
  final ValueChanged<int> onAssign;

  const _OrderCard({
    required this.order,
    required this.boys,
    required this.onStatusChange,
    required this.onAssign,
  });

  static const _statuses = [
    'Received', 'Preparing', 'OutForDelivery', 'Delivered', 'Cancelled',
  ];

  @override
  Widget build(BuildContext context) {
    final status   = order['status']?.toString() ?? 'Received';
    final rawItems = order['items'];
    final items    = rawItems is List ? rawItems : <dynamic>[];

    final dt = DateTime.tryParse(order['created_at']?.toString() ?? '') ??
        DateTime.now();
    final dateStr =
        '${dt.day}/${dt.month}/${dt.year}  ${dt.hour}:${dt.minute.toString().padLeft(2, '0')}';

    // FIX: safe int parsing for delivery_boy_id
    final currentBoyId = order['delivery_boy_id'] != null
        ? _safeInt(order['delivery_boy_id'])
        : null;

    // Only show available boys in dropdown, but also include currently assigned
    // even if offline so the dropdown value is always valid
    final availBoys = boys
        .where((b) =>
            b['available'] == 1 ||
            b['available'] == true ||
            _safeInt(b['id']) == currentBoyId)
        .toList();

    // Ensure the currentBoyId is actually in the dropdown items list
    final dropdownValue = (currentBoyId != null &&
            availBoys.any((b) => _safeInt(b['id']) == currentBoyId))
        ? currentBoyId
        : null;

    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withOpacity(0.06),
              blurRadius: 8,
              offset: const Offset(0, 2))
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // ── Header ──────────────────────────────────────
          Padding(
            padding: const EdgeInsets.all(16),
            child: Row(children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(order['id']?.toString() ?? '',
                        style: const TextStyle(
                            fontWeight: FontWeight.w700,
                            fontSize: 16)),
                    Text(
                        '${order['customer_name'] ?? ''}  ·  '
                        '${order['customer_phone'] ?? ''}  ·  $dateStr',
                        style: const TextStyle(
                            fontSize: 12, color: Colors.grey)),
                  ],
                ),
              ),
              _StatusBadge(status: status),
            ]),
          ),
          Divider(height: 1, color: Colors.grey[100]),

          // ── Items ────────────────────────────────────────
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 10, 16, 0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: items.map<Widget>((item) {
                final m     = item as Map;
                final price = _safeInt(m['price']);
                final qty   = _safeInt(m['qty']);
                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 2),
                  child: Text(
                      '${qty}×  ${m['name'] ?? ''}    ₹${price * qty}',
                      style: const TextStyle(
                          fontSize: 13, color: Color(0xFF555555))),
                );
              }).toList(),
            ),
          ),

          // ── Controls ─────────────────────────────────────
          Padding(
            padding: const EdgeInsets.all(16),
            child: Wrap(
              spacing: 10,
              runSpacing: 10,
              crossAxisAlignment: WrapCrossAlignment.center,
              children: [
                // Total
                Text('Total: ₹${order['total']}',
                    style: const TextStyle(
                        fontWeight: FontWeight.w700, fontSize: 15)),

                // Status dropdown
                _Dropdown<String>(
                  value: _statuses.contains(status) ? status : 'Received',
                  items: _statuses
                      .map((s) => DropdownMenuItem(
                            value: s,
                            child: Text(
                                s == 'OutForDelivery'
                                    ? 'Out For Delivery'
                                    : s,
                                style: const TextStyle(fontSize: 13)),
                          ))
                      .toList(),
                  onChanged: (v) => v != null ? onStatusChange(v) : null,
                ),

                // Assign delivery boy dropdown
                _Dropdown<int>(
                  value: dropdownValue,
                  hint: const Text('Assign delivery',
                      style: TextStyle(fontSize: 13, color: Colors.grey)),
                  items: availBoys
                      .map<DropdownMenuItem<int>>((b) => DropdownMenuItem(
                            value: _safeInt(b['id']),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Container(
                                  width: 8,
                                  height: 8,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    color: (b['available'] == 1 ||
                                            b['available'] == true)
                                        ? const Color(0xFF27AE60)
                                        : Colors.grey,
                                  ),
                                ),
                                const SizedBox(width: 6),
                                Text(b['name'].toString(),
                                    style:
                                        const TextStyle(fontSize: 13)),
                              ],
                            ),
                          ))
                      .toList(),
                  onChanged: (v) => v != null ? onAssign(v) : null,
                ),

                // Assigned boy chip
                if (order['db_name'] != null &&
                    order['db_name'].toString().isNotEmpty)
                  Row(mainAxisSize: MainAxisSize.min, children: [
                    CircleAvatar(
                      radius: 14,
                      backgroundImage: (order['db_photo'] != null &&
                              order['db_photo'].toString().isNotEmpty)
                          ? NetworkImage(order['db_photo'].toString())
                          : null,
                      backgroundColor: Colors.grey[200],
                      child: (order['db_photo'] == null ||
                              order['db_photo'].toString().isEmpty)
                          ? const Icon(Icons.person,
                              size: 14, color: Colors.grey)
                          : null,
                    ),
                    const SizedBox(width: 6),
                    Text(order['db_name'].toString(),
                        style: const TextStyle(
                            fontSize: 13, fontWeight: FontWeight.w500)),
                  ]),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ── Reusable Dropdown wrapper ─────────────────────────────
class _Dropdown<T> extends StatelessWidget {
  final T? value;
  final List<DropdownMenuItem<T>> items;
  final ValueChanged<T?> onChanged;
  final Widget? hint;
  const _Dropdown({
    required this.value,
    required this.items,
    required this.onChanged,
    this.hint,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
          border: Border.all(color: Colors.grey[300]!),
          borderRadius: BorderRadius.circular(4)),
      child: DropdownButton<T>(
        value: value,
        hint: hint,
        isDense: true,
        underline: const SizedBox(),
        items: items,
        onChanged: onChanged,
      ),
    );
  }
}

// ── Status badge ──────────────────────────────────────────
class _StatusBadge extends StatelessWidget {
  final String status;
  const _StatusBadge({required this.status});

  @override
  Widget build(BuildContext context) {
    Color bg, fg;
    switch (status) {
      case 'Received':       bg = const Color(0xFFFFF3E0); fg = const Color(0xFFE67E22); break;
      case 'Preparing':      bg = const Color(0xFFFFF8E1); fg = const Color(0xFFF39C12); break;
      case 'OutForDelivery': bg = const Color(0xFFE8F5E9); fg = const Color(0xFF27AE60); break;
      case 'Delivered':      bg = const Color(0xFFE3F2FD); fg = const Color(0xFF1565C0); break;
      case 'Cancelled':      bg = const Color(0xFFFCE4EC); fg = const Color(0xFFC0392B); break;
      default:               bg = const Color(0xFFF5F5F5); fg = Colors.grey;
    }
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(50)),
      child: Text(
          status == 'OutForDelivery' ? 'Out For Delivery' : status,
          style: TextStyle(
              color: fg, fontSize: 11,
              fontWeight: FontWeight.w600, letterSpacing: 0.5)),
    );
  }
}
