// lib/screens/admin/delivery_screen.dart
import 'package:flutter/material.dart';
import '../../utils/theme.dart';
import '../../services/api_service.dart';
import '../../utils/safe_parse.dart';

class DeliveryScreen extends StatefulWidget {
  const DeliveryScreen({super.key});
  @override
  State<DeliveryScreen> createState() => _DeliveryScreenState();
}

class _DeliveryScreenState extends State<DeliveryScreen> {
  List<dynamic> _boys   = [];
  bool    _loading = true;
  String? _error;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() { _loading = true; _error = null; });
    try {
      final boys = await ApiService.getDeliveryBoys();
      if (!mounted) return;
      setState(() { _boys = boys; _loading = false; });
    } catch (e) {
      if (mounted) setState(() { _error = '$e'; _loading = false; });
    }
  }

  void _toast(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(msg),
        backgroundColor: AppColors.charcoal,
        behavior: SnackBarBehavior.floating,
        duration: const Duration(seconds: 2)));
  }

  Future<void> _toggle(int id, String name, bool wasAvail) async {
    final r = await ApiService.toggleDeliveryBoy(id);
    _toast(r['success'] == true
        ? '$name is now ${wasAvail ? 'offline' : 'online'}'
        : r['error']?.toString() ?? 'Error');
    _load();
  }

  void _openForm({Map<String, dynamic>? boy}) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(16))),
      builder: (_) => _DeliveryBoyForm(
        boy: boy,
        onSaved: (data) async {
          Map<String, dynamic> r;
          if (boy == null) {
            r = await ApiService.addDeliveryBoy(data);
            _toast(r['success'] == true ? 'Delivery boy added!' : r['error']?.toString() ?? 'Error');
          } else {
            final id = safeInt(boy['id']);
            r = await ApiService.updateDeliveryBoy(id, data);
            _toast(r['success'] == true ? 'Details updated!' : r['error']?.toString() ?? 'Error');
          }
          _load();
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF0ECE7),
      body: _loading
          ? const Center(child: CircularProgressIndicator(color: AppColors.terracotta))
          : RefreshIndicator(
              onRefresh: _load,
              color: AppColors.terracotta,
              child: SingleChildScrollView(
                physics: const AlwaysScrollableScrollPhysics(),
                padding: const EdgeInsets.all(24),
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 800),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text('Delivery Team',
                              style: TextStyle(fontSize: 24, fontWeight: FontWeight.w600)),
                          ElevatedButton.icon(
                            onPressed: () => _openForm(),
                            icon: const Icon(Icons.person_add_outlined, size: 18),
                            label: const Text('ADD BOY',
                                style: TextStyle(letterSpacing: 1, fontWeight: FontWeight.w600)),
                            style: ElevatedButton.styleFrom(
                                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12)),
                          ),
                        ],
                      ),
                      const Divider(color: AppColors.terracotta, thickness: 2, height: 24),
                      if (_error != null)
                        Text('Error: $_error', style: const TextStyle(color: AppColors.error)),
                      ..._boys.map((b) {
                        final id    = safeInt(b['id']);
                        final name  = b['name']?.toString() ?? '';
                        final avail = b['available'] == 1 || b['available'] == true;
                        return _DeliveryBoyCard(
                          boy: b,
                          onToggle: () => _toggle(id, name, avail),
                          onEdit: () => _openForm(boy: Map<String, dynamic>.from(b)),
                        );
                      }),
                    ],
                  ),
                ),
              ),
            ),
    );
  }
}

// ── Delivery boy card ──────────────────────────────────────
class _DeliveryBoyCard extends StatelessWidget {
  final Map<String, dynamic> boy;
  final VoidCallback onToggle, onEdit;
  const _DeliveryBoyCard({required this.boy, required this.onToggle, required this.onEdit});

  @override
  Widget build(BuildContext context) {
    final available = boy['available'] == 1 || boy['available'] == true;
    final photo     = boy['photo_url']?.toString() ?? '';
    final rating    = safeDouble(boy['rating'], fallback: 4.5);

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
        boxShadow: [BoxShadow(
            color: Colors.black.withOpacity(0.06), blurRadius: 8, offset: const Offset(0,2))],
      ),
      child: Row(children: [
        // Avatar with status dot
        Stack(children: [
          CircleAvatar(
            radius: 28,
            backgroundImage: photo.isNotEmpty ? NetworkImage(photo) : null,
            backgroundColor: Colors.grey[200],
            child: photo.isEmpty ? const Icon(Icons.person, color: Colors.grey) : null,
          ),
          Positioned(
            bottom: 0, right: 0,
            child: Container(
              width: 14, height: 14,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: available ? const Color(0xFF27AE60) : Colors.grey[400],
                border: Border.all(color: Colors.white, width: 2),
              ),
            ),
          ),
        ]),
        const SizedBox(width: 14),

        // Info
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(boy['name']?.toString() ?? '',
                  style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 15)),
              const SizedBox(height: 3),
              Row(children: [
                const Icon(Icons.star, color: Color(0xFFFFC107), size: 14),
                const SizedBox(width: 3),
                Text(rating.toStringAsFixed(1),
                    style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
                const SizedBox(width: 10),
                Text('📞 ${boy['phone']}',
                    style: TextStyle(color: Colors.grey[600], fontSize: 12)),
              ]),
              Text('${boy['deliveries'] ?? 0} deliveries completed',
                  style: TextStyle(color: Colors.grey[500], fontSize: 11)),
            ],
          ),
        ),

        // Action buttons
        Column(
          children: [
            // Edit button
            GestureDetector(
              onTap: onEdit,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: const Color(0xFFE3F2FD),
                  borderRadius: BorderRadius.circular(50),
                ),
                child: const Text('✏ Edit',
                    style: TextStyle(
                        color: Color(0xFF1565C0), fontSize: 12, fontWeight: FontWeight.w600)),
              ),
            ),
            const SizedBox(height: 6),
            // Toggle button
            GestureDetector(
              onTap: onToggle,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: available ? const Color(0xFFE8F5E9) : const Color(0xFFF5F5F5),
                  borderRadius: BorderRadius.circular(50),
                  border: Border.all(
                      color: available ? const Color(0xFF27AE60) : Colors.grey[300]!),
                ),
                child: Text(available ? 'Set Offline' : 'Set Online',
                    style: TextStyle(
                        color: available ? const Color(0xFF2E7D32) : Colors.grey[600],
                        fontSize: 12, fontWeight: FontWeight.w600)),
              ),
            ),
          ],
        ),
      ]),
    );
  }
}

// ── Delivery boy form ──────────────────────────────────────
class _DeliveryBoyForm extends StatefulWidget {
  final Map<String, dynamic>? boy;
  final Function(Map<String, dynamic>) onSaved;
  const _DeliveryBoyForm({this.boy, required this.onSaved});
  @override
  State<_DeliveryBoyForm> createState() => _DeliveryBoyFormState();
}

class _DeliveryBoyFormState extends State<_DeliveryBoyForm> {
  final _nameCtrl      = TextEditingController();
  final _phoneCtrl     = TextEditingController();
  final _photoCtrl     = TextEditingController();
  final _ratingCtrl    = TextEditingController();
  final _deliveriesCtrl = TextEditingController();
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    if (widget.boy != null) {
      final b = widget.boy!;
      _nameCtrl.text       = b['name']?.toString() ?? '';
      _phoneCtrl.text      = b['phone']?.toString() ?? '';
      _photoCtrl.text      = b['photo_url']?.toString() ?? '';
      _ratingCtrl.text     = '${b['rating'] ?? '4.5'}';
      _deliveriesCtrl.text = '${b['deliveries'] ?? '0'}';
    } else {
      _ratingCtrl.text     = '4.5';
      _deliveriesCtrl.text = '0';
    }
  }

  @override
  void dispose() {
    _nameCtrl.dispose(); _phoneCtrl.dispose(); _photoCtrl.dispose();
    _ratingCtrl.dispose(); _deliveriesCtrl.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (_nameCtrl.text.trim().isEmpty || _phoneCtrl.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Name and phone are required'),
          backgroundColor: AppColors.error));
      return;
    }
    setState(() => _saving = true);
    await widget.onSaved({
      'name':        _nameCtrl.text.trim(),
      'phone':       _phoneCtrl.text.trim(),
      'photo_url':   _photoCtrl.text.trim(),
      'rating':      double.tryParse(_ratingCtrl.text.trim()) ?? 4.5,
      'deliveries':  int.tryParse(_deliveriesCtrl.text.trim()) ?? 0,
    });
    if (mounted) Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.fromLTRB(20, 20, 20, MediaQuery.of(context).viewInsets.bottom + 20),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Center(child: Container(width: 40, height: 4,
              decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(2)))),
          const SizedBox(height: 14),
          Text(widget.boy == null ? 'Add Delivery Boy' : 'Edit: ${widget.boy!['name']}',
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
          const Divider(color: AppColors.terracotta, thickness: 2, height: 20),

          TextField(controller: _nameCtrl,
              decoration: const InputDecoration(labelText: 'Full Name *')),
          const SizedBox(height: 10),

          TextField(controller: _phoneCtrl,
              keyboardType: TextInputType.phone,
              decoration: const InputDecoration(labelText: 'Phone Number *')),
          const SizedBox(height: 10),

          Row(children: [
            Expanded(child: TextField(controller: _ratingCtrl,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: const InputDecoration(
                    labelText: 'Rating (0-5)',
                    prefixIcon: Icon(Icons.star, color: Color(0xFFFFC107), size: 18)))),
            const SizedBox(width: 10),
            Expanded(child: TextField(controller: _deliveriesCtrl,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                    labelText: 'Total Deliveries',
                    prefixIcon: Icon(Icons.delivery_dining_outlined, size: 18)))),
          ]),
          const SizedBox(height: 10),

          TextField(controller: _photoCtrl,
              decoration: const InputDecoration(
                  labelText: 'Photo URL (optional)',
                  hintText: 'https://...')),
          const SizedBox(height: 20),

          Row(children: [
            Expanded(child: OutlinedButton(
              onPressed: () => Navigator.pop(context),
              style: OutlinedButton.styleFrom(
                  foregroundColor: Colors.grey, side: BorderSide(color: Colors.grey[300]!)),
              child: const Text('CANCEL'))),
            const SizedBox(width: 10),
            Expanded(child: ElevatedButton(
              onPressed: _saving ? null : _save,
              style: ElevatedButton.styleFrom(backgroundColor: AppColors.forest),
              child: _saving
                  ? const SizedBox(width: 18, height: 18,
                      child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                  : const Text('SAVE', style: TextStyle(letterSpacing: 1.5)),
            )),
          ]),
        ],
      ),
    );
  }
}
