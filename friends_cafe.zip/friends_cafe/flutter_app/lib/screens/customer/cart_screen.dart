// lib/screens/customer/cart_screen.dart
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../../utils/theme.dart';
import '../../services/app_provider.dart';

class CartScreen extends StatelessWidget {
  const CartScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.creamLight,
      appBar: AppBar(
        title: const Text('Your Cart',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.w600)),
        backgroundColor: AppColors.charcoal,
        foregroundColor: AppColors.cream,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () =>
              context.canPop() ? context.pop() : context.go('/'),
        ),
      ),
      body: Consumer<AppProvider>(
        builder: (_, prov, __) {
          if (prov.cart.isEmpty) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.shopping_bag_outlined,
                      size: 64, color: Colors.grey[400]),
                  const SizedBox(height: 16),
                  Text('Your cart is empty',
                      style: TextStyle(
                          fontSize: 20,
                          color: Colors.grey[600],
                          fontWeight: FontWeight.w600)),
                  const SizedBox(height: 8),
                  Text('Add something delicious!',
                      style: TextStyle(color: Colors.grey)),
                  const SizedBox(height: 24),
                  ElevatedButton(
                    onPressed: () => context.push('/menu'),
                    child: const Text('BROWSE MENU'),
                  ),
                ],
              ),
            );
          }

          return Column(
            children: [
              Expanded(
                child: ListView(
                  padding: const EdgeInsets.all(16),
                  children: [
                    ...prov.cart.map((item) =>
                        _CartItemTile(item: item)),
                    const SizedBox(height: 12),
                    _OrderSummaryCard(prov: prov),
                  ],
                ),
              ),
              _CheckoutBar(prov: prov),
            ],
          );
        },
      ),
    );
  }
}

class _CartItemTile extends StatelessWidget {
  final CartItem item;
  const _CartItemTile({required this.item});

  @override
  Widget build(BuildContext context) {
    final prov = context.read<AppProvider>();
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withOpacity(0.06),
              blurRadius: 8,
              offset: const Offset(0, 2))
        ],
      ),
      child: Row(
        children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(6),
            child: Image.network(
              item.img,
              width: 64,
              height: 64,
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => Container(
                  width: 64,
                  height: 64,
                  color: Colors.grey[200],
                  child: const Icon(Icons.fastfood)),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(item.name,
                    style: const TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w600)),
                Text('₹${item.price} each',
                    style: const TextStyle(
                        color: Colors.grey, fontSize: 12)),
              ],
            ),
          ),
          Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              _QtyBtn(
                  icon: Icons.remove,
                  onTap: () => prov.removeFromCart(item.id)),
              Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 12),
                child: Text('${item.qty}',
                    style: const TextStyle(
                        fontWeight: FontWeight.w700,
                        fontSize: 16)),
              ),
              _QtyBtn(
                  icon: Icons.add,
                  onTap: () => prov.addToCart({
                        'id': item.id,
                        'name': item.name,
                        'price': item.price,
                        'img_url': item.img,
                      })),
            ],
          ),
          const SizedBox(width: 10),
          Text('₹${item.price * item.qty}',
              style: TextStyle(
                  fontWeight: FontWeight.w700,
                  color: AppColors.terracotta,
                  fontSize: 15)),
        ],
      ),
    );
  }
}

class _QtyBtn extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  const _QtyBtn({required this.icon, required this.onTap});
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 30,
        height: 30,
        decoration: BoxDecoration(
            color: AppColors.terracotta.withOpacity(0.12),
            borderRadius: BorderRadius.circular(4)),
        child: Icon(icon, size: 16, color: AppColors.terracotta),
      ),
    );
  }
}

class _OrderSummaryCard extends StatelessWidget {
  final AppProvider prov;
  const _OrderSummaryCard({required this.prov});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withOpacity(0.06),
              blurRadius: 8,
              offset: const Offset(0, 2))
        ],
      ),
      child: Column(
        children: [
          const Text('Order Summary',
              style: TextStyle(
                  fontSize: 16, fontWeight: FontWeight.w600)),
          const Divider(height: 20),
          _SummaryRow('Subtotal', '₹${prov.cartSubtotal}'),
          const SizedBox(height: 6),
          _SummaryRow('Delivery Fee', '₹${prov.deliveryFee}'),
          const Divider(height: 16),
          _SummaryRow('Total', '₹${prov.cartTotal}', bold: true),
        ],
      ),
    );
  }
}

class _SummaryRow extends StatelessWidget {
  final String label, value;
  final bool bold;
  const _SummaryRow(this.label, this.value, {this.bold = false});

  @override
  Widget build(BuildContext context) {
    final style = bold
        ? const TextStyle(
            fontWeight: FontWeight.w700,
            fontSize: 16,
            color: AppColors.charcoal)
        : TextStyle(color: Colors.grey[600], fontSize: 14);
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label, style: style),
        Text(value,
            style: style.copyWith(
                color: bold
                    ? AppColors.terracotta
                    : Colors.grey[600])),
      ],
    );
  }
}

class _CheckoutBar extends StatelessWidget {
  final AppProvider prov;
  const _CheckoutBar({required this.prov});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [
          BoxShadow(
              color: Colors.black.withOpacity(0.1),
              blurRadius: 16,
              offset: const Offset(0, -4))
        ],
      ),
      child: SafeArea(
        top: false,
        child: Row(
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text('${prov.cartCount} item${prov.cartCount == 1 ? '' : 's'}',
                    style: TextStyle(
                        color: Colors.grey[600], fontSize: 12)),
                Text('₹${prov.cartTotal}',
                    style: TextStyle(
                        fontWeight: FontWeight.w700,
                        fontSize: 18,
                        color: AppColors.terracotta)),
              ],
            ),
            const Spacer(),
            ElevatedButton(
              onPressed: () {
                if (!prov.isLoggedIn) {
                  context.push('/login');
                  return;
                }
                context.push('/checkout');
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.terracotta,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(
                    horizontal: 32, vertical: 14),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(2)),
              ),
              child: const Text('CHECKOUT',
                  style: TextStyle(
                      letterSpacing: 1.5,
                      fontWeight: FontWeight.w600)),
            ),
          ],
        ),
      ),
    );
  }
}
