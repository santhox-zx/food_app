// lib/screens/customer/order_confirm_screen.dart
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../utils/theme.dart';
import '../../utils/safe_parse.dart';

class OrderConfirmScreen extends StatelessWidget {
  final Map<String, dynamic> order;
  const OrderConfirmScreen({super.key, required this.order});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.creamLight,
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 520),
              child: Column(children: [
                // Success icon
                Container(
                  width: 80,
                  height: 80,
                  decoration: BoxDecoration(
                      color: AppColors.forest.withOpacity(0.12),
                      shape: BoxShape.circle),
                  child: const Icon(Icons.check_circle_outline,
                      color: AppColors.forest, size: 48),
                ),
                const SizedBox(height: 16),
                const Text('Order Confirmed!',
                    style: TextStyle(
                        fontSize: 28,
                        fontWeight: FontWeight.w700,
                        color: AppColors.charcoal)),
                const SizedBox(height: 8),
                Text('Your order has been placed successfully.',
                    style: TextStyle(
                        color: Colors.grey[600], fontSize: 14)),
                const SizedBox(height: 10),
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 18, vertical: 8),
                  decoration: BoxDecoration(
                      color: AppColors.terracotta.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(50)),
                  child: Text(
                      'Order ID: ${order['id'] ?? 'N/A'}',
                      style: TextStyle(
                          color: AppColors.terracotta,
                          fontWeight: FontWeight.w700,
                          fontSize: 14,
                          letterSpacing: 1)),
                ),
                const SizedBox(height: 24),

                // Delivery boy card
                if (_hasDeliveryBoy()) ...[
                  _DeliveryBoyCard(order: order),
                  const SizedBox(height: 16),
                ],

                // Order items
                _OrderItemsCard(order: order),
                const SizedBox(height: 24),

                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () => context.go('/my-orders'),
                    child: const Text('VIEW MY ORDERS',
                        style: TextStyle(letterSpacing: 1.5)),
                  ),
                ),
                const SizedBox(height: 12),
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton(
                    onPressed: () => context.go('/menu'),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: AppColors.charcoal,
                      side:
                          BorderSide(color: Colors.grey[300]!),
                      padding: const EdgeInsets.symmetric(
                          vertical: 14),
                      shape: RoundedRectangleBorder(
                          borderRadius:
                              BorderRadius.circular(2)),
                    ),
                    child: const Text('ORDER MORE',
                        style: TextStyle(
                            letterSpacing: 1.5,
                            fontWeight: FontWeight.w600)),
                  ),
                ),
              ]),
            ),
          ),
        ),
      ),
    );
  }

  bool _hasDeliveryBoy() =>
      order['db_name'] != null &&
      order['db_name'].toString().isNotEmpty;
}

// ── Delivery boy card ─────────────────────────────────────
class _DeliveryBoyCard extends StatelessWidget {
  final Map<String, dynamic> order;
  const _DeliveryBoyCard({required this.order});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        border: const Border(
            left: BorderSide(color: AppColors.terracotta, width: 3)),
        borderRadius: BorderRadius.circular(8),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withOpacity(0.05),
              blurRadius: 8,
              offset: const Offset(0, 2))
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('YOUR DELIVERY PARTNER',
              style: TextStyle(
                  fontSize: 10,
                  letterSpacing: 2,
                  color: AppColors.terracotta,
                  fontWeight: FontWeight.w600)),
          const SizedBox(height: 12),
          Row(children: [
            CircleAvatar(
              radius: 28,
              backgroundImage: (order['db_photo'] != null &&
                      order['db_photo'].toString().isNotEmpty)
                  ? NetworkImage(order['db_photo'].toString())
                  : null,
              backgroundColor: Colors.grey[200],
              child: (order['db_photo'] == null ||
                      order['db_photo'].toString().isEmpty)
                  ? const Icon(Icons.person,
                      color: Colors.grey)
                  : null,
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(order['db_name']?.toString() ?? '',
                      style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w600)),
                  Text(
                      '⭐ ${order['db_rating']?.toString() ?? ''}',
                      style: TextStyle(
                          color: AppColors.terracotta,
                          fontWeight: FontWeight.w600,
                          fontSize: 13)),
                  Text(
                      '📞 ${order['db_phone']?.toString() ?? ''}',
                      style: const TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w500)),
                ],
              ),
            ),
          ]),
        ],
      ),
    );
  }
}

// ── Order items card ──────────────────────────────────────
class _OrderItemsCard extends StatelessWidget {
  final Map<String, dynamic> order;
  const _OrderItemsCard({required this.order});

  @override
  Widget build(BuildContext context) {
    // items can be a List<dynamic> parsed from JSON
    final rawItems = order['items'];
    final items = rawItems is List ? rawItems : <dynamic>[];

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withOpacity(0.05),
              blurRadius: 8,
              offset: const Offset(0, 2))
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('ORDER SUMMARY',
              style: TextStyle(
                  fontSize: 10,
                  letterSpacing: 2,
                  fontWeight: FontWeight.w600,
                  color: Colors.grey)),
          const Divider(height: 16),
          ...items.map((item) {
            final map  = item as Map;
            final price = safeInt(map['price']);
            final qty   = safeInt(map['qty'], fallback: 1);
            return Padding(
              padding: const EdgeInsets.symmetric(vertical: 4),
              child: Row(children: [
                Text('${qty}×',
                    style: TextStyle(
                        color: AppColors.terracotta,
                        fontWeight: FontWeight.w700)),
                const SizedBox(width: 8),
                Expanded(
                    child: Text(
                        map['name']?.toString() ?? '',
                        style: const TextStyle(fontSize: 14))),
                Text('₹${price * qty}',
                    style: const TextStyle(
                        fontWeight: FontWeight.w600)),
              ]),
            );
          }),
          const Divider(height: 16),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text('Total',
                  style: TextStyle(
                      fontWeight: FontWeight.w700,
                      fontSize: 16)),
              Text('₹${order['total']}',
                  style: TextStyle(
                      fontWeight: FontWeight.w700,
                      fontSize: 16,
                      color: AppColors.terracotta)),
            ],
          ),
          const SizedBox(height: 10),
          Row(children: [
            _StatusBadge('Received'),
            const SizedBox(width: 8),
            Text(order['payment_method']?.toString() ?? '',
                style: const TextStyle(
                    color: Colors.grey, fontSize: 12)),
          ]),
        ],
      ),
    );
  }
}

class _StatusBadge extends StatelessWidget {
  final String status;
  const _StatusBadge(this.status);
  @override
  Widget build(BuildContext context) {
    return Container(
      padding:
          const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
          color: const Color(0xFFFFF3E0),
          borderRadius: BorderRadius.circular(50)),
      child: Text(status,
          style: const TextStyle(
              color: Color(0xFFE67E22),
              fontSize: 11,
              fontWeight: FontWeight.w600,
              letterSpacing: 0.5)),
    );
  }
}
