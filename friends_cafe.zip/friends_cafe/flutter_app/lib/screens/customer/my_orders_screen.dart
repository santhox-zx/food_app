// lib/screens/customer/my_orders_screen.dart
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../../utils/theme.dart';
import '../../utils/safe_parse.dart';
import '../../services/app_provider.dart';
import '../../services/api_service.dart';

class MyOrdersScreen extends StatefulWidget {
  const MyOrdersScreen({super.key});
  @override
  State<MyOrdersScreen> createState() => _MyOrdersScreenState();
}

class _MyOrdersScreenState extends State<MyOrdersScreen> {
  List<dynamic> _orders  = [];
  bool          _loading = true;
  String?       _error;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    setState(() { _loading = true; _error = null; });
    try {
      final orders = await ApiService.getMyOrders();
      if (mounted) setState(() { _orders = orders; _loading = false; });
    } catch (e) {
      if (mounted) setState(() { _error = '$e'; _loading = false; });
    }
  }

  // ── Cancel order (only Received) ─────────────────────────
  Future<void> _cancelOrder(String orderId) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => _CancelDialog(orderId: orderId),
    );
    if (confirmed != true || !mounted) return;

    final result = await ApiService.cancelMyOrder(orderId);
    if (!mounted) return;

    if (result['success'] == true) {
      _showSnack('Order cancelled successfully', AppColors.forest);
      _load();
    } else {
      _showSnack(result['error']?.toString() ?? 'Could not cancel', AppColors.error);
    }
  }

  // ── Confirm delivery (only OutForDelivery) ────────────────
  Future<void> _confirmDelivery(String orderId) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => _ConfirmDeliveryDialog(orderId: orderId),
    );
    if (confirmed != true || !mounted) return;

    final result = await ApiService.confirmDelivery(orderId);
    if (!mounted) return;

    if (result['success'] == true) {
      _showSnack('✅ Order marked as delivered!', AppColors.forest);
      _load();
    } else {
      _showSnack(result['error']?.toString() ?? 'Error', AppColors.error);
    }
  }

  void _showSnack(String msg, Color color) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg),
      backgroundColor: color,
      behavior: SnackBarBehavior.floating,
      duration: const Duration(seconds: 3),
    ));
  }

  @override
  Widget build(BuildContext context) {
    final isLoggedIn = context.watch<AppProvider>().isLoggedIn;
    return Scaffold(
      backgroundColor: AppColors.creamLight,
      appBar: AppBar(
        backgroundColor: AppColors.charcoal,
        foregroundColor: AppColors.cream,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => context.canPop() ? context.pop() : context.go('/'),
        ),
        title: const Text('My Orders',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.w600)),
        actions: [
          IconButton(
              icon: const Icon(Icons.refresh),
              onPressed: isLoggedIn ? _load : null),
        ],
      ),
      body: !isLoggedIn
          ? const _NotLoggedIn()
          : _loading
              ? const Center(child: CircularProgressIndicator(color: AppColors.terracotta))
              : _error != null
                  ? _ErrorView(error: _error!, onRetry: _load)
                  : _orders.isEmpty
                      ? const _EmptyView()
                      : RefreshIndicator(
                          onRefresh: _load,
                          color: AppColors.terracotta,
                          child: ListView.builder(
                            padding: const EdgeInsets.all(16),
                            itemCount: _orders.length,
                            itemBuilder: (_, i) => _OrderCard(
                              order: Map<String, dynamic>.from(_orders[i] as Map),
                              onCancel:          () => _cancelOrder(_orders[i]['id'].toString()),
                              onConfirmDelivery: () => _confirmDelivery(_orders[i]['id'].toString()),
                            ),
                          ),
                        ),
    );
  }
}

// ─────────────────────────────────────────────────────────
// STATUS CONFIG  (static final — NOT const, contains IconData)
// ─────────────────────────────────────────────────────────
class _S {
  static final Map<String, Map<String, dynamic>> _cfg = {
    'Received':       {'bg': const Color(0xFFFFF3E0), 'fg': const Color(0xFFE67E22), 'icon': Icons.receipt_outlined,        'label': 'Received'},
    'Preparing':      {'bg': const Color(0xFFFFF8E1), 'fg': const Color(0xFFF39C12), 'icon': Icons.restaurant_outlined,      'label': 'Preparing'},
    'OutForDelivery': {'bg': const Color(0xFFE8F5E9), 'fg': const Color(0xFF27AE60), 'icon': Icons.delivery_dining_outlined, 'label': 'Out For Delivery'},
    'Delivered':      {'bg': const Color(0xFFE8F5FD), 'fg': const Color(0xFF1565C0), 'icon': Icons.check_circle_outline,     'label': 'Delivered'},
    'Cancelled':      {'bg': const Color(0xFFFCE4EC), 'fg': const Color(0xFFC0392B), 'icon': Icons.cancel_outlined,          'label': 'Cancelled'},
  };
  static Color    bg(String s)   => _cfg[s]?['bg']    as Color?    ?? const Color(0xFFF5F5F5);
  static Color    fg(String s)   => _cfg[s]?['fg']    as Color?    ?? Colors.grey;
  static IconData icon(String s) => _cfg[s]?['icon']  as IconData? ?? Icons.info_outline;
  static String   label(String s)=> _cfg[s]?['label'] as String?   ?? s;
}

const List<String> _kSteps = ['Received', 'Preparing', 'OutForDelivery', 'Delivered'];

// ─────────────────────────────────────────────────────────
// ORDER CARD
// ─────────────────────────────────────────────────────────
class _OrderCard extends StatefulWidget {
  final Map<String, dynamic> order;
  final VoidCallback onCancel;
  final VoidCallback onConfirmDelivery;
  const _OrderCard({
    required this.order,
    required this.onCancel,
    required this.onConfirmDelivery,
  });
  @override
  State<_OrderCard> createState() => _OrderCardState();
}

class _OrderCardState extends State<_OrderCard> {
  bool _expanded = false;

  @override
  Widget build(BuildContext context) {
    final o            = widget.order;
    final status       = o['status']?.toString() ?? 'Received';
    final rawItems     = o['items'];
    final items        = rawItems is List ? rawItems : <dynamic>[];
    final dt           = DateTime.tryParse(o['created_at']?.toString() ?? '') ?? DateTime.now();
    final dateStr      = '${dt.day}/${dt.month}/${dt.year}  ${dt.hour}:${dt.minute.toString().padLeft(2,'0')}';
    final hasDelivery  = o['db_name'] != null && o['db_name'].toString().isNotEmpty;

    // ── Button visibility rules ──────────────────────────
    final canCancel          = status == 'Received';          // Cancel button
    final canConfirmDelivery = status == 'OutForDelivery';    // Mark Delivered button
    final isCancelled        = status == 'Cancelled';
    final isDelivered        = status == 'Delivered';

    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(10),
        border: isCancelled
            ? Border.all(color: const Color(0xFFFCE4EC), width: 1.5)
            : isDelivered
                ? Border.all(color: const Color(0xFFBBDEFB), width: 1.5)
                : null,
        boxShadow: [BoxShadow(
            color: Colors.black.withOpacity(0.07),
            blurRadius: 10, offset: const Offset(0, 3))],
      ),
      child: Column(children: [

        // ── Header ───────────────────────────────────────
        InkWell(
          onTap: () => setState(() => _expanded = !_expanded),
          borderRadius: const BorderRadius.vertical(top: Radius.circular(10)),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(14, 12, 14, 12),
            child: Row(children: [
              Container(
                width: 40, height: 40,
                decoration: BoxDecoration(
                    color: _S.bg(status), shape: BoxShape.circle),
                child: Icon(_S.icon(status), color: _S.fg(status), size: 20),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(o['id']?.toString() ?? '',
                      style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
                  Text(dateStr,
                      style: const TextStyle(fontSize: 11, color: Colors.grey)),
                ]),
              ),
              _StatusBadge(status: status, isDelivered: isDelivered),
              const SizedBox(width: 6),
              Icon(_expanded ? Icons.keyboard_arrow_up : Icons.keyboard_arrow_down,
                  color: Colors.grey, size: 18),
            ]),
          ),
        ),

        // ── Progress bar (not for cancelled) ─────────────
        if (!isCancelled)
          Padding(
            padding: const EdgeInsets.fromLTRB(14, 2, 14, 10),
            child: _ProgressBar(status: status),
          ),

        // ── Cancelled banner ──────────────────────────────
        if (isCancelled)
          _Banner(
            color: const Color(0xFFFCE4EC),
            borderColor: const Color(0xFFEF9A9A),
            icon: Icons.cancel_outlined,
            iconColor: const Color(0xFFC0392B),
            text: o['cancel_reason'] != null && o['cancel_reason'].toString().isNotEmpty
                ? 'Order Cancelled — Reason: ${o['cancel_reason']}'
                : 'Order Cancelled',
            textColor: const Color(0xFFC0392B),
          ),

        // ── Delivered banner ──────────────────────────────
        if (isDelivered)
          const _Banner(
            color: Color(0xFFE8F5E9),
            borderColor: Color(0xFFA5D6A7),
            icon: Icons.check_circle,
            iconColor: Color(0xFF27AE60),
            text: 'Your order has been delivered. Enjoy your meal! 🍽️',
            textColor: Color(0xFF2E7D32),
          ),

        // ── Out for delivery hint ─────────────────────────
        if (canConfirmDelivery)
          const _Banner(
            color: Color(0xFFE3F2FD),
            borderColor: Color(0xFF90CAF9),
            icon: Icons.delivery_dining_outlined,
            iconColor: Color(0xFF1565C0),
            text: 'Your order is on the way! Tap "Food Received" once delivered.',
            textColor: Color(0xFF1565C0),
          ),

        const Divider(height: 1),

        // ── Items list ────────────────────────────────────
        Padding(
          padding: const EdgeInsets.fromLTRB(14, 10, 14, 0),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            ...items.take(_expanded ? items.length : 3).map((item) {
              final m     = item as Map;
              final qty   = safeInt(m['qty'], fallback: 1);
              final price = safeInt(m['price']);
              return Padding(
                padding: const EdgeInsets.symmetric(vertical: 3),
                child: Row(children: [
                  Text('${qty}×',
                      style: const TextStyle(
                          color: AppColors.terracotta,
                          fontWeight: FontWeight.w700, fontSize: 13)),
                  const SizedBox(width: 8),
                  Expanded(child: Text(m['name']?.toString() ?? '',
                      style: const TextStyle(fontSize: 13))),
                  Text('₹${price * qty}',
                      style: const TextStyle(fontSize: 13, color: Colors.grey)),
                ]),
              );
            }),
            if (!_expanded && items.length > 3)
              GestureDetector(
                onTap: () => setState(() => _expanded = true),
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 4),
                  child: Text('+${items.length - 3} more items — tap to see all',
                      style: TextStyle(
                          color: AppColors.terracotta,
                          fontSize: 12, fontWeight: FontWeight.w500)),
                ),
              ),
          ]),
        ),

        // ── Footer ───────────────────────────────────────
        Padding(
          padding: const EdgeInsets.fromLTRB(14, 10, 14, 14),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            // Delivery boy + total row
            Row(children: [
              if (hasDelivery) ...[
                CircleAvatar(
                  radius: 16,
                  backgroundImage: (o['db_photo'] != null && o['db_photo'].toString().isNotEmpty)
                      ? NetworkImage(o['db_photo'].toString()) : null,
                  backgroundColor: Colors.grey[200],
                  child: (o['db_photo'] == null || o['db_photo'].toString().isEmpty)
                      ? const Icon(Icons.person, size: 16, color: Colors.grey) : null,
                ),
                const SizedBox(width: 8),
                Expanded(child: Text(o['db_name'].toString(),
                    style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500))),
              ] else
                Expanded(child: Text(o['payment_method']?.toString() ?? '',
                    style: const TextStyle(color: Colors.grey, fontSize: 12))),

              Text('₹${o['total']}',
                  style: TextStyle(
                      fontWeight: FontWeight.w700, fontSize: 16,
                      color: isCancelled ? Colors.grey : AppColors.terracotta)),
            ]),

            // ── Action buttons ────────────────────────────
            if (canCancel || canConfirmDelivery) ...[
              const SizedBox(height: 10),
              Row(children: [

                // CANCEL button — only for Received
                if (canCancel)
                  Expanded(
                    child: _ActionButton(
                      label: 'Cancel Order',
                      icon: Icons.cancel_outlined,
                      bg: AppColors.error.withOpacity(0.08),
                      fg: AppColors.error,
                      border: AppColors.error.withOpacity(0.4),
                      onTap: widget.onCancel,
                    ),
                  ),

                if (canCancel && canConfirmDelivery)
                  const SizedBox(width: 10),

                // MARK DELIVERED button — only for OutForDelivery
                if (canConfirmDelivery)
                  Expanded(
                    child: _ActionButton(
                      label: 'Food Received ✓',
                      icon: Icons.check_circle_outline,
                      bg: const Color(0xFF27AE60).withOpacity(0.1),
                      fg: const Color(0xFF27AE60),
                      border: const Color(0xFF27AE60).withOpacity(0.4),
                      onTap: widget.onConfirmDelivery,
                    ),
                  ),
              ]),
            ],
          ]),
        ),

      ]),
    );
  }
}

// ─────────────────────────────────────────────────────────
// ACTION BUTTON
// ─────────────────────────────────────────────────────────
class _ActionButton extends StatelessWidget {
  final String label;
  final IconData icon;
  final Color bg, fg, border;
  final VoidCallback onTap;
  const _ActionButton({
    required this.label,
    required this.icon,
    required this.bg,
    required this.fg,
    required this.border,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(
          color: bg,
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: border),
        ),
        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          Icon(icon, size: 16, color: fg),
          const SizedBox(width: 6),
          Text(label,
              style: TextStyle(
                  color: fg, fontSize: 13, fontWeight: FontWeight.w600)),
        ]),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────
// STATUS BADGE
// ─────────────────────────────────────────────────────────
class _StatusBadge extends StatelessWidget {
  final String status;
  final bool isDelivered;
  const _StatusBadge({required this.status, required this.isDelivered});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
          color: _S.bg(status), borderRadius: BorderRadius.circular(50)),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        if (isDelivered) ...[
          const Icon(Icons.check_circle, color: Color(0xFF1565C0), size: 13),
          const SizedBox(width: 4),
        ],
        Text(_S.label(status),
            style: TextStyle(
                color: _S.fg(status), fontSize: 11,
                fontWeight: FontWeight.w700, letterSpacing: 0.3)),
      ]),
    );
  }
}

// ─────────────────────────────────────────────────────────
// PROGRESS BAR
// ─────────────────────────────────────────────────────────
class _ProgressBar extends StatelessWidget {
  final String status;
  const _ProgressBar({required this.status});

  @override
  Widget build(BuildContext context) {
    final step = _kSteps.indexOf(status);

    return Row(
      children: List.generate(_kSteps.length * 2 - 1, (i) {
        if (i.isOdd) {
          return Expanded(child: Container(
              height: 2,
              color: step > i ~/ 2 ? AppColors.terracotta : Colors.grey[200]));
        }
        final idx    = i ~/ 2;
        final done   = step >= idx;
        final active = step == idx;
        final dotColor = done && status == 'Delivered'
            ? const Color(0xFF1565C0)
            : done ? AppColors.terracotta : Colors.grey.shade300;

        return Column(children: [
          Container(
            width: 20, height: 20,
            decoration: BoxDecoration(
              color: done ? dotColor : Colors.white,
              shape: BoxShape.circle,
              border: Border.all(
                  color: done ? dotColor : Colors.grey.shade300,
                  width: active ? 2.5 : 1.5),
              boxShadow: active ? [BoxShadow(
                  color: dotColor.withOpacity(0.4),
                  blurRadius: 6, spreadRadius: 1)] : null,
            ),
            child: done
                ? const Icon(Icons.check, size: 11, color: Colors.white)
                : null,
          ),
          const SizedBox(height: 3),
          Text(_stepLabel(idx),
              style: TextStyle(
                  fontSize: 9,
                  color: done ? dotColor : Colors.grey,
                  fontWeight: active ? FontWeight.w700 : FontWeight.normal)),
        ]);
      }),
    );
  }

  String _stepLabel(int i) =>
      const ['Received', 'Preparing', 'Delivery', 'Delivered'][i];
}

// ─────────────────────────────────────────────────────────
// INFO BANNER
// ─────────────────────────────────────────────────────────
class _Banner extends StatelessWidget {
  final Color color, borderColor, iconColor, textColor;
  final IconData icon;
  final String text;
  const _Banner({
    required this.color,
    required this.borderColor,
    required this.icon,
    required this.iconColor,
    required this.text,
    required this.textColor,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(14, 0, 14, 8),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(
            color: color,
            borderRadius: BorderRadius.circular(6),
            border: Border.all(color: borderColor)),
        child: Row(children: [
          Icon(icon, size: 15, color: iconColor),
          const SizedBox(width: 8),
          Expanded(child: Text(text,
              style: TextStyle(color: textColor, fontSize: 12,
                  fontWeight: FontWeight.w500))),
        ]),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────
// DIALOGS
// ─────────────────────────────────────────────────────────
class _CancelDialog extends StatefulWidget {
  final String orderId;
  const _CancelDialog({required this.orderId});
  @override
  State<_CancelDialog> createState() => _CancelDialogState();
}

class _CancelDialogState extends State<_CancelDialog> {
  final _ctrl = TextEditingController();
  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      title: Row(children: [
        Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
              color: AppColors.error.withOpacity(0.1), shape: BoxShape.circle),
          child: const Icon(Icons.cancel_outlined, color: AppColors.error, size: 20),
        ),
        const SizedBox(width: 12),
        const Text('Cancel Order?',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
      ]),
      content: Column(mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('Order ${widget.orderId} will be cancelled.\nThis cannot be undone.',
            style: TextStyle(color: Colors.grey[600], fontSize: 14)),
        const SizedBox(height: 16),
        TextField(
          controller: _ctrl,
          decoration: const InputDecoration(
              labelText: 'Reason (optional)',
              hintText: 'e.g. Changed my mind'),
          maxLines: 2,
        ),
      ]),
      actions: [
        TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Keep Order', style: TextStyle(fontWeight: FontWeight.w600))),
        ElevatedButton(
          onPressed: () => Navigator.pop(context, true),
          style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.error, foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4))),
          child: const Text('Yes, Cancel', style: TextStyle(fontWeight: FontWeight.w600)),
        ),
      ],
    );
  }
}

class _ConfirmDeliveryDialog extends StatelessWidget {
  final String orderId;
  const _ConfirmDeliveryDialog({required this.orderId});

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      title: Row(children: [
        Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
              color: const Color(0xFF27AE60).withOpacity(0.1),
              shape: BoxShape.circle),
          child: const Icon(Icons.check_circle_outline,
              color: Color(0xFF27AE60), size: 20),
        ),
        const SizedBox(width: 12),
        const Text('Food Received?',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
      ]),
      content: Column(mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('Confirm that you received order ${orderId}.',
            style: TextStyle(color: Colors.grey[600], fontSize: 14)),
        const SizedBox(height: 8),
        Text('This will mark your order as Delivered.',
            style: TextStyle(color: Colors.grey[500], fontSize: 13)),
      ]),
      actions: [
        TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Not Yet', style: TextStyle(fontWeight: FontWeight.w600))),
        ElevatedButton(
          onPressed: () => Navigator.pop(context, true),
          style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF27AE60),
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4))),
          child: const Text('Yes, Received!', style: TextStyle(fontWeight: FontWeight.w600)),
        ),
      ],
    );
  }
}

// ─────────────────────────────────────────────────────────
// SUPPORTING SCREENS
// ─────────────────────────────────────────────────────────
class _NotLoggedIn extends StatelessWidget {
  const _NotLoggedIn();
  @override
  Widget build(BuildContext context) {
    return Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      Icon(Icons.lock_outline, size: 56, color: Colors.grey[400]),
      const SizedBox(height: 16),
      Text('Please login to view orders',
          style: TextStyle(color: Colors.grey[600], fontSize: 16)),
      const SizedBox(height: 20),
      ElevatedButton(
          onPressed: () => context.push('/login'), child: const Text('LOGIN')),
    ]));
  }
}

class _ErrorView extends StatelessWidget {
  final String error;
  final VoidCallback onRetry;
  const _ErrorView({required this.error, required this.onRetry});
  @override
  Widget build(BuildContext context) {
    return Center(child: Padding(
      padding: const EdgeInsets.all(32),
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Icon(Icons.cloud_off, size: 48, color: Colors.grey[400]),
        const SizedBox(height: 12),
        Text('Could not load orders', style: TextStyle(color: Colors.grey[600])),
        const SizedBox(height: 4),
        Text(error,
            style: const TextStyle(color: Colors.grey, fontSize: 12),
            textAlign: TextAlign.center),
        const SizedBox(height: 20),
        ElevatedButton(onPressed: onRetry, child: const Text('RETRY')),
      ]),
    ));
  }
}

class _EmptyView extends StatelessWidget {
  const _EmptyView();
  @override
  Widget build(BuildContext context) {
    return Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      Icon(Icons.receipt_long_outlined, size: 64, color: Colors.grey[400]),
      const SizedBox(height: 12),
      Text('No orders yet',
          style: TextStyle(fontSize: 20, color: Colors.grey[600], fontWeight: FontWeight.w600)),
      const SizedBox(height: 8),
      const Text('Your order history will appear here'),
      const SizedBox(height: 20),
      ElevatedButton(
          onPressed: () => context.push('/menu'), child: const Text('ORDER NOW')),
    ]));
  }
}
