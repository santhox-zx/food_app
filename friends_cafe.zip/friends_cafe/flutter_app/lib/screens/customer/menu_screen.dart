// lib/screens/customer/menu_screen.dart
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../../utils/theme.dart';
import '../../services/app_provider.dart';
import '../../utils/safe_parse.dart';

class MenuScreen extends StatefulWidget {
  const MenuScreen({super.key});
  @override
  State<MenuScreen> createState() => _MenuScreenState();
}

class _MenuScreenState extends State<MenuScreen> {
  String _selectedCat = 'all';

  static const _cats = [
    {'id': 'all',     'label': 'All'},
    {'id': 'seafood', 'label': '🦞 Seafood'},
    {'id': 'chinese', 'label': '🍜 Chinese'},
    {'id': 'biryani', 'label': '🍚 Biryani'},
    {'id': 'curries', 'label': '🍛 Curries'},
    {'id': 'veg',     'label': '🥗 Veg'},
  ];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<AppProvider>().loadMenu();
    });
  }

  void _selectCat(String cat) {
    setState(() => _selectedCat = cat);
    context.read<AppProvider>().loadMenu(
        category: cat == 'all' ? null : cat);
  }

  void _showDetail(BuildContext context, Map<String, dynamic> item) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => _DishDetailSheet(item: item),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.charcoal,
      appBar: AppBar(
        backgroundColor: AppColors.charcoal,
        foregroundColor: AppColors.cream,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => context.canPop() ? context.pop() : context.go('/'),
        ),
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Our Menu',
                style: TextStyle(fontSize: 20, color: AppColors.cream, fontWeight: FontWeight.w600)),
            Text("Tenkasi's favourite dishes",
                style: TextStyle(fontSize: 11, color: AppColors.muted)),
          ],
        ),
        actions: [_CartButton(), const SizedBox(width: 8)],
      ),
      body: Column(
        children: [
          // ── Category pills ──────────────────────────
          Container(
            color: AppColors.charcoal,
            padding: const EdgeInsets.fromLTRB(12, 0, 12, 12),
            child: SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: _cats.map((c) {
                  final active = _selectedCat == c['id'];
                  return Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: ChoiceChip(
                      label: Text(c['label']!),
                      selected: active,
                      onSelected: (_) => _selectCat(c['id']!),
                      showCheckmark: false,
                      selectedColor: AppColors.terracotta,
                      backgroundColor: Colors.transparent,
                      labelStyle: TextStyle(
                        color: active ? Colors.white : AppColors.muted,
                        fontSize: 13, fontWeight: FontWeight.w500),
                      side: BorderSide(
                          color: active
                              ? AppColors.terracotta
                              : AppColors.cream.withOpacity(0.2)),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(50)),
                    ),
                  );
                }).toList(),
              ),
            ),
          ),

          // ── Menu grid ───────────────────────────────
          Expanded(
            child: Consumer<AppProvider>(
              builder: (_, prov, __) {
                if (prov.menuLoading) {
                  return const Center(
                      child: CircularProgressIndicator(color: AppColors.terracotta));
                }
                final items = prov.menuItems
                    .where((i) => i['available'] == 1 || i['available'] == true)
                    .toList();
                if (items.isEmpty) {
                  return Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.restaurant_menu, color: AppColors.muted, size: 48),
                        const SizedBox(height: 12),
                        Text('No items available',
                            style: TextStyle(color: AppColors.muted)),
                      ],
                    ),
                  );
                }
                return LayoutBuilder(builder: (ctx, c) {
                  final cols = c.maxWidth > 900 ? 4 : c.maxWidth > 600 ? 3 : 2;
                  return GridView.builder(
                    padding: const EdgeInsets.all(12),
                    gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: cols,
                      crossAxisSpacing: 10,
                      mainAxisSpacing: 10,
                      childAspectRatio: 0.68,
                    ),
                    itemCount: items.length,
                    itemBuilder: (_, i) => _DishCard(
                      item: items[i],
                      onTap: () => _showDetail(context, items[i]),
                    ),
                  );
                });
              },
            ),
          ),
        ],
      ),
    );
  }
}

// ── Cart button ────────────────────────────────────────────
class _CartButton extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final count = context.watch<AppProvider>().cartCount;
    return GestureDetector(
      onTap: () => context.push('/cart'),
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          Padding(
            padding: const EdgeInsets.all(8),
            child: Icon(Icons.shopping_bag_outlined, color: AppColors.cream),
          ),
          if (count > 0)
            Positioned(
              top: 4, right: 4,
              child: Container(
                width: 16, height: 16,
                decoration: BoxDecoration(
                    color: AppColors.terracotta, shape: BoxShape.circle),
                child: Center(
                  child: Text('$count',
                      style: const TextStyle(
                          color: Colors.white, fontSize: 9, fontWeight: FontWeight.bold)),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

// ── Dish Card ──────────────────────────────────────────────
class _DishCard extends StatelessWidget {
  final Map<String, dynamic> item;
  final VoidCallback onTap;
  const _DishCard({required this.item, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final prov   = context.watch<AppProvider>();
    final id     = safeInt(item['id']);
    final qty    = prov.cartQty(id);
    final rating = safeDouble(item['rating'], fallback: 4.5);
    final stock  = safeInt(item['stock_qty'], fallback: 99);
    final lowStock = stock > 0 && stock <= 10;

    return GestureDetector(
      onTap: onTap, // tap card → detail sheet
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.05),
          border: Border.all(color: Colors.white.withOpacity(0.08)),
          borderRadius: BorderRadius.circular(6),
        ),
        clipBehavior: Clip.antiAlias,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // ── Image ────────────────────────────────
            Stack(
              children: [
                AspectRatio(
                  aspectRatio: 4 / 3,
                  child: Image.network(
                    item['img_url']?.toString() ?? '',
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => Container(
                        color: Colors.grey[800],
                        child: const Icon(Icons.fastfood, color: Colors.grey)),
                    loadingBuilder: (_, child, progress) {
                      if (progress == null) return child;
                      return Container(color: Colors.grey[800],
                          child: const Center(child: SizedBox(width: 20, height: 20,
                              child: CircularProgressIndicator(strokeWidth: 2, color: AppColors.terracotta))));
                    },
                  ),
                ),
                // Rating badge on image
                Positioned(
                  top: 6, left: 6,
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.7),
                      borderRadius: BorderRadius.circular(50),
                    ),
                    child: Row(mainAxisSize: MainAxisSize.min, children: [
                      const Icon(Icons.star, color: Color(0xFFFFC107), size: 11),
                      const SizedBox(width: 3),
                      Text(rating.toStringAsFixed(1),
                          style: const TextStyle(
                              color: Colors.white, fontSize: 10, fontWeight: FontWeight.w600)),
                    ]),
                  ),
                ),
                // Low stock badge
                if (lowStock)
                  Positioned(
                    top: 6, right: 6,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
                      decoration: BoxDecoration(
                        color: AppColors.error.withOpacity(0.9),
                        borderRadius: BorderRadius.circular(50),
                      ),
                      child: Text('Only $stock left',
                          style: const TextStyle(color: Colors.white, fontSize: 9, fontWeight: FontWeight.w600)),
                    ),
                  ),
              ],
            ),

            // ── Info ─────────────────────────────────
            Expanded(
              child: Padding(
                padding: const EdgeInsets.fromLTRB(8, 8, 8, 6),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      item['name']?.toString() ?? '',
                      style: const TextStyle(
                          color: AppColors.cream, fontSize: 13, fontWeight: FontWeight.w600),
                      maxLines: 1, overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 3),
                    // Description preview
                    if ((item['description']?.toString() ?? '').isNotEmpty)
                      Text(
                        item['description'].toString(),
                        style: TextStyle(color: AppColors.muted.withOpacity(0.7), fontSize: 10, height: 1.3),
                        maxLines: 2, overflow: TextOverflow.ellipsis,
                      ),
                    const Spacer(),
                    // Price + ADD/qty
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('₹${item['price']}',
                            style: const TextStyle(
                                color: AppColors.cream, fontWeight: FontWeight.w700, fontSize: 14)),
                        qty == 0
                            ? _AddBtn(onTap: () {
                                if (!prov.isLoggedIn) { context.push('/login'); return; }
                                prov.addToCart(item);
                              })
                            : _QtyCtrl(
                                qty: qty,
                                onAdd: () => prov.addToCart(item),
                                onRemove: () => prov.removeFromCart(id),
                              ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ── Dish detail bottom sheet ───────────────────────────────
class _DishDetailSheet extends StatelessWidget {
  final Map<String, dynamic> item;
  const _DishDetailSheet({required this.item});

  @override
  Widget build(BuildContext context) {
    final prov   = context.watch<AppProvider>();
    final id     = safeInt(item['id']);
    final qty    = prov.cartQty(id);
    final rating = safeDouble(item['rating'], fallback: 4.5);
    final stock  = safeInt(item['stock_qty'], fallback: 99);

    return Container(
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Handle bar
          Center(
            child: Container(
              margin: const EdgeInsets.only(top: 12),
              width: 40, height: 4,
              decoration: BoxDecoration(color: Colors.grey[300], borderRadius: BorderRadius.circular(2)),
            ),
          ),

          // Image
          AspectRatio(
            aspectRatio: 16 / 9,
            child: ClipRRect(
              borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
              child: Image.network(
                item['img_url']?.toString() ?? '',
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) => Container(
                    color: Colors.grey[200],
                    child: const Icon(Icons.fastfood, size: 48, color: Colors.grey)),
              ),
            ),
          ),

          Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Name + Price row
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Expanded(
                      child: Text(item['name']?.toString() ?? '',
                          style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w700,
                              color: AppColors.charcoal)),
                    ),
                    Text('₹${item['price']}',
                        style: TextStyle(fontSize: 22, fontWeight: FontWeight.w700,
                            color: AppColors.terracotta)),
                  ],
                ),
                const SizedBox(height: 8),

                // Rating + stock row
                Row(children: [
                  // Star rating
                  ...List.generate(5, (i) {
                    final full = i < rating.floor();
                    final half = !full && i < rating;
                    return Icon(
                      full ? Icons.star : half ? Icons.star_half : Icons.star_border,
                      color: const Color(0xFFFFC107), size: 18);
                  }),
                  const SizedBox(width: 6),
                  Text(rating.toStringAsFixed(1),
                      style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
                  const SizedBox(width: 16),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: stock > 10
                          ? const Color(0xFFE8F5E9)
                          : stock > 0
                              ? const Color(0xFFFFF3E0)
                              : const Color(0xFFFCE4EC),
                      borderRadius: BorderRadius.circular(50),
                    ),
                    child: Text(
                      stock > 10 ? 'In Stock' : stock > 0 ? 'Only $stock left' : 'Out of Stock',
                      style: TextStyle(
                        fontSize: 11, fontWeight: FontWeight.w600,
                        color: stock > 10
                            ? const Color(0xFF2E7D32)
                            : stock > 0
                                ? const Color(0xFFE67E22)
                                : AppColors.error,
                      ),
                    ),
                  ),
                  const Spacer(),
                  // Category pill
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: AppColors.terracotta.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(50),
                    ),
                    child: Text(
                      (item['category']?.toString() ?? '').toUpperCase(),
                      style: TextStyle(
                          fontSize: 10, fontWeight: FontWeight.w700,
                          color: AppColors.terracotta, letterSpacing: 1),
                    ),
                  ),
                ]),
                const SizedBox(height: 14),

                // Description
                if ((item['description']?.toString() ?? '').isNotEmpty) ...[
                  const Text('About this dish',
                      style: TextStyle(fontSize: 13, fontWeight: FontWeight.w600, color: Colors.grey)),
                  const SizedBox(height: 6),
                  Text(item['description'].toString(),
                      style: const TextStyle(fontSize: 14, color: Color(0xFF444444), height: 1.6)),
                  const SizedBox(height: 20),
                ],

                // Add to cart button
                SizedBox(
                  width: double.infinity,
                  child: qty == 0
                      ? ElevatedButton(
                          onPressed: stock == 0 ? null : () {
                            if (!prov.isLoggedIn) {
                              Navigator.pop(context);
                              context.push('/login');
                              return;
                            }
                            prov.addToCart(item);
                            Navigator.pop(context);
                          },
                          style: ElevatedButton.styleFrom(
                              padding: const EdgeInsets.symmetric(vertical: 14),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(4))),
                          child: Text(stock == 0 ? 'OUT OF STOCK' : 'ADD TO CART',
                              style: const TextStyle(letterSpacing: 1.5, fontWeight: FontWeight.w600)),
                        )
                      : Container(
                          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                          decoration: BoxDecoration(
                            color: AppColors.terracotta.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(4),
                            border: Border.all(color: AppColors.terracotta.withOpacity(0.3)),
                          ),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text('In cart: $qty × ₹${item['price']} = ₹${qty * safeInt(item['price'])}',
                                  style: TextStyle(color: AppColors.terracotta, fontWeight: FontWeight.w600)),
                              Row(children: [
                                _QtyBtn(icon: Icons.remove, onTap: () => prov.removeFromCart(id)),
                                Padding(
                                  padding: const EdgeInsets.symmetric(horizontal: 12),
                                  child: Text('$qty',
                                      style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 16))),
                                _QtyBtn(icon: Icons.add, onTap: () => prov.addToCart(item)),
                              ]),
                            ],
                          ),
                        ),
                ),
                SizedBox(height: MediaQuery.of(context).viewInsets.bottom + 8),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ── Small widgets ──────────────────────────────────────────
class _AddBtn extends StatelessWidget {
  final VoidCallback onTap;
  const _AddBtn({required this.onTap});
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
        decoration: BoxDecoration(color: AppColors.terracotta, borderRadius: BorderRadius.circular(2)),
        child: const Text('ADD', style: TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.w600, letterSpacing: 1)),
      ),
    );
  }
}

class _QtyCtrl extends StatelessWidget {
  final int qty;
  final VoidCallback onAdd, onRemove;
  const _QtyCtrl({required this.qty, required this.onAdd, required this.onRemove});
  @override
  Widget build(BuildContext context) {
    return Row(mainAxisSize: MainAxisSize.min, children: [
      _QtyBtn(icon: Icons.remove, onTap: onRemove),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 8),
        child: Text('$qty', style: const TextStyle(color: AppColors.cream, fontWeight: FontWeight.w700, fontSize: 14))),
      _QtyBtn(icon: Icons.add, onTap: onAdd),
    ]);
  }
}

class _QtyBtn extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  const _QtyBtn({required this.icon, required this.onTap});
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 24, height: 24,
        decoration: BoxDecoration(color: AppColors.terracotta, borderRadius: BorderRadius.circular(2)),
        child: Icon(icon, size: 14, color: Colors.white),
      ),
    );
  }
}
