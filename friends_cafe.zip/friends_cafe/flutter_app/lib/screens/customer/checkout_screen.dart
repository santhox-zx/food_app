// lib/screens/customer/checkout_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../../utils/theme.dart';
import '../../services/app_provider.dart';
import '../../services/api_service.dart';

class CheckoutScreen extends StatefulWidget {
  const CheckoutScreen({super.key});
  @override
  State<CheckoutScreen> createState() => _CheckoutScreenState();
}

class _CheckoutScreenState extends State<CheckoutScreen> {
  int    _step      = 0; // 0=details 1=payment 2=review
  String _payMethod = 'Cash on Delivery';
  bool   _loading   = false;

  // Step 0 - delivery details
  final _addressCtrl = TextEditingController();
  final _notesCtrl   = TextEditingController();
  final _formKey     = GlobalKey<FormState>();

  // Step 1 - UPI
  final _upiCtrl     = TextEditingController();
  // Step 1 - Card
  final _cardNumCtrl  = TextEditingController();
  final _cardNameCtrl = TextEditingController();
  final _cardExpCtrl  = TextEditingController();
  final _cardCvvCtrl  = TextEditingController();
  // Step 1 - Net Banking
  String _selectedBank = 'State Bank of India';

  @override
  void dispose() {
    _addressCtrl.dispose(); _notesCtrl.dispose();
    _upiCtrl.dispose(); _cardNumCtrl.dispose();
    _cardNameCtrl.dispose(); _cardExpCtrl.dispose();
    _cardCvvCtrl.dispose();
    super.dispose();
  }

  Future<void> _placeOrder() async {
    final prov = context.read<AppProvider>();
    setState(() => _loading = true);

    final result = await ApiService.placeOrder({
      'address':        _addressCtrl.text.trim(),
      'payment_method': _payMethod,
      'items':          prov.cart.map((i) => i.toJson()).toList(),
      'subtotal':       prov.cartSubtotal,
      'delivery_fee':   prov.deliveryFee,
      'total':          prov.cartTotal,
      'notes':          _notesCtrl.text.trim(),
    });

    if (!mounted) return;
    setState(() => _loading = false);

    if (result['success'] == true) {
      prov.clearCart();
      context.pushReplacement('/order-confirmed',
          extra: Map<String, dynamic>.from(result['data'] as Map));
    } else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text(result['error']?.toString() ?? 'Order failed'),
          backgroundColor: AppColors.error));
    }
  }

  void _next() {
    if (_step == 0) {
      if (_addressCtrl.text.trim().isEmpty) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
            content: Text('Please enter your delivery address')));
        return;
      }
    }
    if (_step == 1) {
      final err = _validatePayment();
      if (err != null) {
        ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(err), backgroundColor: AppColors.error));
        return;
      }
    }
    if (_step < 2) {
      setState(() => _step++);
    } else {
      _placeOrder();
    }
  }

  /// Validate payment fields for the chosen method
  String? _validatePayment() {
    switch (_payMethod) {
      case 'UPI':
        final upi = _upiCtrl.text.trim();
        if (upi.isEmpty) return 'Please enter your UPI ID';
        if (!RegExp(r'^[\w.\-+]+@[\w]+$').hasMatch(upi))
          return 'Invalid UPI ID format (e.g. name@upi)';
        return null;

      case 'Credit / Debit Card':
        if (_cardNumCtrl.text.replaceAll(' ', '').length < 16)
          return 'Enter a valid 16-digit card number';
        if (_cardNameCtrl.text.trim().isEmpty)
          return 'Enter cardholder name';
        if (!RegExp(r'^(0[1-9]|1[0-2])\/\d{2}$').hasMatch(_cardExpCtrl.text.trim()))
          return 'Enter expiry as MM/YY';
        if (_cardCvvCtrl.text.trim().length < 3)
          return 'Enter a valid CVV';
        return null;

      default:
        return null; // COD and Net Banking need no extra validation
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.creamLight,
      appBar: AppBar(
        backgroundColor: AppColors.charcoal,
        foregroundColor: AppColors.cream,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => context.canPop() ? context.pop() : context.go('/cart'),
        ),
        title: const Text('Checkout',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.w600)),
      ),
      body: Column(children: [
        _StepIndicator(step: _step),
        Expanded(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: Form(
              key: _formKey,
              child: _step == 0
                  ? _DetailsStep(
                      addressCtrl: _addressCtrl,
                      notesCtrl: _notesCtrl)
                  : _step == 1
                      ? _PaymentStep(
                          selected:       _payMethod,
                          onSelect:       (v) => setState(() => _payMethod = v),
                          upiCtrl:        _upiCtrl,
                          cardNumCtrl:    _cardNumCtrl,
                          cardNameCtrl:   _cardNameCtrl,
                          cardExpCtrl:    _cardExpCtrl,
                          cardCvvCtrl:    _cardCvvCtrl,
                          selectedBank:   _selectedBank,
                          onBankChanged:  (v) => setState(() => _selectedBank = v),
                        )
                      : _ReviewStep(payMethod: _payMethod),
            ),
          ),
        ),
        _NavButtons(
          step: _step,
          loading: _loading,
          onBack: _step > 0 ? () => setState(() => _step--) : null,
          onNext: _next,
        ),
      ]),
    );
  }
}

// ── Step indicator ─────────────────────────────────────────
class _StepIndicator extends StatelessWidget {
  final int step;
  const _StepIndicator({required this.step});
  static const _labels = ['Details', 'Payment', 'Review'];

  @override
  Widget build(BuildContext context) {
    return Container(
      color: AppColors.charcoal,
      padding: const EdgeInsets.symmetric(vertical: 16),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: List.generate(_labels.length * 2 - 1, (i) {
          if (i.isOdd) {
            return Container(
                width: 40, height: 1,
                color: i ~/ 2 < step
                    ? AppColors.terracotta
                    : Colors.white24);
          }
          final idx    = i ~/ 2;
          final active = idx == step;
          final done   = idx < step;
          return Column(mainAxisSize: MainAxisSize.min, children: [
            Container(
              width: 28, height: 28,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: done
                    ? AppColors.terracotta
                    : active
                        ? Colors.white
                        : Colors.white24,
              ),
              child: Center(
                child: done
                    ? const Icon(Icons.check, size: 16, color: Colors.white)
                    : Text('${idx + 1}',
                        style: TextStyle(
                            fontSize: 13,
                            fontWeight: FontWeight.w700,
                            color: active
                                ? AppColors.charcoal
                                : Colors.white54)),
              ),
            ),
            const SizedBox(height: 4),
            Text(_labels[idx],
                style: TextStyle(
                    fontSize: 10,
                    color: active ? Colors.white : Colors.white54,
                    fontWeight: active ? FontWeight.w600 : FontWeight.normal,
                    letterSpacing: 0.5)),
          ]);
        }),
      ),
    );
  }
}

// ── Step 0: Delivery Details ───────────────────────────────
class _DetailsStep extends StatelessWidget {
  final TextEditingController addressCtrl, notesCtrl;
  const _DetailsStep({required this.addressCtrl, required this.notesCtrl});

  @override
  Widget build(BuildContext context) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('Delivery Details',
          style: TextStyle(fontSize: 22, fontWeight: FontWeight.w600)),
      const SizedBox(height: 20),
      TextFormField(
        controller: addressCtrl,
        maxLines: 3,
        decoration: const InputDecoration(
          labelText: 'Delivery Address *',
          hintText: 'House no, Street, Area, City',
          prefixIcon: Icon(Icons.location_on_outlined),
        ),
        validator: (v) =>
            (v == null || v.trim().isEmpty) ? 'Address is required' : null,
      ),
      const SizedBox(height: 16),
      TextFormField(
        controller: notesCtrl,
        maxLines: 2,
        decoration: const InputDecoration(
          labelText: 'Order Notes (optional)',
          hintText: 'e.g. Extra spicy, No onions',
          prefixIcon: Icon(Icons.note_outlined),
        ),
      ),
    ]);
  }
}

// ── Step 1: Payment ────────────────────────────────────────
class _PaymentStep extends StatelessWidget {
  final String selected;
  final ValueChanged<String> onSelect;
  final TextEditingController upiCtrl, cardNumCtrl, cardNameCtrl,
      cardExpCtrl, cardCvvCtrl;
  final String selectedBank;
  final ValueChanged<String> onBankChanged;

  const _PaymentStep({
    required this.selected,
    required this.onSelect,
    required this.upiCtrl,
    required this.cardNumCtrl,
    required this.cardNameCtrl,
    required this.cardExpCtrl,
    required this.cardCvvCtrl,
    required this.selectedBank,
    required this.onBankChanged,
  });

  static const _methods = [
    {'id': 'Cash on Delivery',    'icon': Icons.money_outlined,         'label': 'Cash on Delivery',   'sub': 'Pay when your order arrives'},
    {'id': 'UPI',                 'icon': Icons.phone_android_outlined,  'label': 'UPI',                'sub': 'GPay, PhonePe, Paytm, BHIM'},
    {'id': 'Credit / Debit Card', 'icon': Icons.credit_card_outlined,   'label': 'Credit / Debit Card','sub': 'Visa, Mastercard, RuPay'},
    {'id': 'Net Banking',         'icon': Icons.account_balance_outlined,'label': 'Net Banking',        'sub': 'All major banks supported'},
  ];

  static const _banks = [
    'State Bank of India',
    'HDFC Bank',
    'ICICI Bank',
    'Axis Bank',
    'Kotak Mahindra Bank',
    'Bank of Baroda',
    'Punjab National Bank',
    'Canara Bank',
    'Union Bank of India',
    'Indian Bank',
  ];

  @override
  Widget build(BuildContext context) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('Payment Method',
          style: TextStyle(fontSize: 22, fontWeight: FontWeight.w600)),
      const SizedBox(height: 4),
      Text('Select how you want to pay',
          style: TextStyle(color: Colors.grey[600], fontSize: 13)),
      const SizedBox(height: 20),

      // ── Payment method tiles ──────────────────────────
      ..._methods.map((m) {
        final id         = m['id'] as String;
        final icon       = m['icon'] as IconData;
        final label      = m['label'] as String;
        final sub        = m['sub'] as String;
        final isSelected = selected == id;

        return Column(children: [
          GestureDetector(
            onTap: () => onSelect(id),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              margin: const EdgeInsets.only(bottom: 4),
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(
                    color: isSelected
                        ? AppColors.terracotta
                        : Colors.grey[200]!,
                    width: isSelected ? 2 : 1),
                boxShadow: isSelected
                    ? [BoxShadow(
                        color: AppColors.terracotta.withOpacity(0.15),
                        blurRadius: 8, offset: const Offset(0, 2))]
                    : null,
              ),
              child: Row(children: [
                Container(
                  width: 44, height: 44,
                  decoration: BoxDecoration(
                    color: isSelected
                        ? AppColors.terracotta.withOpacity(0.1)
                        : Colors.grey[50],
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(icon,
                      color: isSelected ? AppColors.terracotta : Colors.grey[600],
                      size: 22),
                ),
                const SizedBox(width: 14),
                Expanded(child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(label,
                        style: TextStyle(
                            fontSize: 15, fontWeight: FontWeight.w600,
                            color: isSelected ? AppColors.terracotta : AppColors.charcoal)),
                    Text(sub,
                        style: TextStyle(fontSize: 12, color: Colors.grey[500])),
                  ],
                )),
                if (isSelected)
                  Container(
                    width: 22, height: 22,
                    decoration: const BoxDecoration(
                        color: AppColors.terracotta, shape: BoxShape.circle),
                    child: const Icon(Icons.check, size: 14, color: Colors.white),
                  )
                else
                  Container(
                    width: 22, height: 22,
                    decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(color: Colors.grey[300]!)),
                  ),
              ]),
            ),
          ),

          // ── Inline detail form per method ─────────────
          if (isSelected) ...[
            if (id == 'UPI')       _UpiForm(ctrl: upiCtrl),
            if (id == 'Credit / Debit Card')
              _CardForm(
                numCtrl: cardNumCtrl, nameCtrl: cardNameCtrl,
                expCtrl: cardExpCtrl, cvvCtrl: cardCvvCtrl),
            if (id == 'Net Banking')
              _NetBankingForm(
                  selected: selectedBank, onChange: onBankChanged, banks: _banks),
            if (id == 'Cash on Delivery') _CodInfo(),
            const SizedBox(height: 8),
          ],
        ]);
      }),
    ]);
  }
}

// ── UPI form ───────────────────────────────────────────────
class _UpiForm extends StatelessWidget {
  final TextEditingController ctrl;
  const _UpiForm({required this.ctrl});

  @override
  Widget build(BuildContext context) {
    final total = context.watch<AppProvider>().cartTotal;
    return Container(
      margin: const EdgeInsets.fromLTRB(0, 0, 0, 4),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
          color: const Color(0xFFF3F8FF),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: const Color(0xFFBBDEFB))),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        // UPI apps row
        Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
          _UpiApp('GPay',    '🅶',  const Color(0xFF4285F4)),
          _UpiApp('PhonePe', '𝙋',  const Color(0xFF5F259F)),
          _UpiApp('Paytm',   '𝙋𝙩', const Color(0xFF00BAF2)),
          _UpiApp('BHIM',    '𝘉',  const Color(0xFF0E6B3C)),
        ]),
        const SizedBox(height: 14),
        const Divider(),
        const SizedBox(height: 10),
        Text('Amount to Pay: ₹$total',
            style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15, color: AppColors.terracotta)),
        const SizedBox(height: 12),
        TextFormField(
          controller: ctrl,
          keyboardType: TextInputType.emailAddress,
          decoration: InputDecoration(
            labelText: 'Your UPI ID *',
            hintText: 'mobilenumber@upi or name@oksbi',
            prefixIcon: const Icon(Icons.alternate_email),
            suffixIcon: ctrl.text.isNotEmpty
                ? const Icon(Icons.check_circle, color: Color(0xFF27AE60))
                : null,
            helperText: 'e.g. 9876543210@paytm  |  name@okicici',
          ),
          onChanged: (_) {},
        ),
        const SizedBox(height: 8),
        Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
              color: const Color(0xFFE8F5E9),
              borderRadius: BorderRadius.circular(6)),
          child: const Row(children: [
            Icon(Icons.info_outline, size: 14, color: Color(0xFF2E7D32)),
            SizedBox(width: 8),
            Expanded(child: Text(
              'You will receive a payment request on your UPI app. '
              'Complete the payment within 5 minutes.',
              style: TextStyle(fontSize: 11, color: Color(0xFF2E7D32)),
            )),
          ]),
        ),
      ]),
    );
  }
}

class _UpiApp extends StatelessWidget {
  final String name, symbol;
  final Color color;
  const _UpiApp(this.name, this.symbol, this.color);
  @override
  Widget build(BuildContext context) {
    return Column(children: [
      Container(
        width: 48, height: 48,
        decoration: BoxDecoration(
            color: color, borderRadius: BorderRadius.circular(12)),
        child: Center(child: Text(symbol,
            style: const TextStyle(fontSize: 20, color: Colors.white,
                fontWeight: FontWeight.w900))),
      ),
      const SizedBox(height: 4),
      Text(name, style: TextStyle(fontSize: 11, color: Colors.grey[600])),
    ]);
  }
}

// ── Card form ──────────────────────────────────────────────
class _CardForm extends StatelessWidget {
  final TextEditingController numCtrl, nameCtrl, expCtrl, cvvCtrl;
  const _CardForm({
    required this.numCtrl, required this.nameCtrl,
    required this.expCtrl, required this.cvvCtrl,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.fromLTRB(0, 0, 0, 4),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
          color: const Color(0xFFF8F4FF),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: const Color(0xFFCE93D8))),
      child: Column(children: [
        // Card preview
        Container(
          width: double.infinity, height: 90,
          margin: const EdgeInsets.only(bottom: 16),
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
                colors: [Color(0xFF1A1A18), Color(0xFF3a3a38)]),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Row(children: [
            Expanded(child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('FRIENDS CAFE',
                    style: TextStyle(color: Colors.white54, fontSize: 10, letterSpacing: 2)),
                ValueListenableBuilder(
                  valueListenable: numCtrl,
                  builder: (_, __, ___) => Text(
                    _formatCardDisplay(numCtrl.text),
                    style: const TextStyle(color: Colors.white, fontSize: 14,
                        fontWeight: FontWeight.w600, letterSpacing: 3),
                  ),
                ),
                ValueListenableBuilder(
                  valueListenable: nameCtrl,
                  builder: (_, __, ___) => Text(
                    nameCtrl.text.isEmpty ? 'CARDHOLDER NAME' : nameCtrl.text.toUpperCase(),
                    style: const TextStyle(color: Colors.white70, fontSize: 11, letterSpacing: 1),
                  ),
                ),
              ],
            )),
            ValueListenableBuilder(
              valueListenable: expCtrl,
              builder: (_, __, ___) => Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  const Text('VALID THRU', style: TextStyle(color: Colors.white38, fontSize: 8)),
                  Text(expCtrl.text.isEmpty ? 'MM/YY' : expCtrl.text,
                      style: const TextStyle(color: Colors.white, fontSize: 12,
                          fontWeight: FontWeight.w600)),
                ],
              ),
            ),
          ]),
        ),

        // Card number
        TextFormField(
          controller: numCtrl,
          keyboardType: TextInputType.number,
          maxLength: 19,
          inputFormatters: [
            FilteringTextInputFormatter.digitsOnly,
            _CardNumberFormatter(),
          ],
          decoration: const InputDecoration(
            labelText: 'Card Number *',
            hintText: '0000 0000 0000 0000',
            prefixIcon: Icon(Icons.credit_card),
            counterText: '',
          ),
        ),
        const SizedBox(height: 10),

        // Cardholder name
        TextFormField(
          controller: nameCtrl,
          textCapitalization: TextCapitalization.characters,
          decoration: const InputDecoration(
            labelText: 'Cardholder Name *',
            hintText: 'Name as on card',
            prefixIcon: Icon(Icons.person_outline),
          ),
        ),
        const SizedBox(height: 10),

        // Expiry + CVV row
        Row(children: [
          Expanded(child: TextFormField(
            controller: expCtrl,
            keyboardType: TextInputType.number,
            maxLength: 5,
            inputFormatters: [_ExpiryFormatter()],
            decoration: const InputDecoration(
              labelText: 'Expiry *',
              hintText: 'MM/YY',
              prefixIcon: Icon(Icons.calendar_today_outlined),
              counterText: '',
            ),
          )),
          const SizedBox(width: 12),
          Expanded(child: TextFormField(
            controller: cvvCtrl,
            keyboardType: TextInputType.number,
            maxLength: 4,
            obscureText: true,
            inputFormatters: [FilteringTextInputFormatter.digitsOnly],
            decoration: const InputDecoration(
              labelText: 'CVV *',
              hintText: '•••',
              prefixIcon: Icon(Icons.lock_outline),
              counterText: '',
            ),
          )),
        ]),
        const SizedBox(height: 10),
        Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
              color: const Color(0xFFEDE7F6),
              borderRadius: BorderRadius.circular(6)),
          child: const Row(children: [
            Icon(Icons.security_outlined, size: 14, color: Color(0xFF7B1FA2)),
            SizedBox(width: 8),
            Expanded(child: Text(
              '256-bit SSL secured. Your card details are encrypted and never stored.',
              style: TextStyle(fontSize: 11, color: Color(0xFF7B1FA2)),
            )),
          ]),
        ),
      ]),
    );
  }

  String _formatCardDisplay(String raw) {
    final digits = raw.replaceAll(' ', '');
    if (digits.isEmpty) return '•••• •••• •••• ••••';
    final padded = digits.padRight(16, '•');
    return '${padded.substring(0,4)} ${padded.substring(4,8)} ${padded.substring(8,12)} ${padded.substring(12,16)}';
  }
}

// ── Net Banking form ───────────────────────────────────────
class _NetBankingForm extends StatelessWidget {
  final String selected;
  final ValueChanged<String> onChange;
  final List<String> banks;
  const _NetBankingForm({required this.selected, required this.onChange, required this.banks});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.fromLTRB(0, 0, 0, 4),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
          color: const Color(0xFFF1F8E9),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: const Color(0xFFA5D6A7))),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Select Your Bank',
            style: TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
        const SizedBox(height: 12),
        DropdownButtonFormField<String>(
          value: selected,
          isExpanded: true,
          decoration: const InputDecoration(
            prefixIcon: Icon(Icons.account_balance_outlined),
            labelText: 'Bank',
          ),
          items: banks.map((b) => DropdownMenuItem(
              value: b,
              child: Text(b, style: const TextStyle(fontSize: 14)))).toList(),
          onChanged: (v) => v != null ? onChange(v) : null,
        ),
        const SizedBox(height: 12),
        Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
              color: const Color(0xFFE8F5E9),
              borderRadius: BorderRadius.circular(6)),
          child: const Row(children: [
            Icon(Icons.info_outline, size: 14, color: Color(0xFF2E7D32)),
            SizedBox(width: 8),
            Expanded(child: Text(
              'You will be redirected to your bank\'s secure portal to complete the payment.',
              style: TextStyle(fontSize: 11, color: Color(0xFF2E7D32)),
            )),
          ]),
        ),
      ]),
    );
  }
}

// ── COD info ───────────────────────────────────────────────
class _CodInfo extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.fromLTRB(0, 0, 0, 4),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
          color: const Color(0xFFFFF8E1),
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: const Color(0xFFFFE082))),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Row(children: [
          Text('💵', style: TextStyle(fontSize: 22)),
          SizedBox(width: 10),
          Expanded(child: Text('Pay when your order arrives',
              style: TextStyle(fontWeight: FontWeight.w600, fontSize: 14))),
        ]),
        const SizedBox(height: 8),
        const Divider(color: Color(0xFFFFE082)),
        const SizedBox(height: 8),
        _CodRow(Icons.check_circle_outline, 'No advance payment required',    const Color(0xFF2E7D32)),
        _CodRow(Icons.check_circle_outline, 'Pay cash to delivery agent',     const Color(0xFF2E7D32)),
        _CodRow(Icons.check_circle_outline, 'Exact change appreciated',       const Color(0xFF2E7D32)),
        _CodRow(Icons.warning_amber_rounded,'Additional ₹5 COD handling fee', const Color(0xFFE67E22)),
      ]),
    );
  }
}

class _CodRow extends StatelessWidget {
  final IconData icon;
  final String text;
  final Color color;
  const _CodRow(this.icon, this.text, this.color);
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(children: [
        Icon(icon, size: 15, color: color),
        const SizedBox(width: 8),
        Text(text, style: TextStyle(fontSize: 12, color: color)),
      ]),
    );
  }
}

// ── Step 2: Review ─────────────────────────────────────────
class _ReviewStep extends StatelessWidget {
  final String payMethod;
  const _ReviewStep({required this.payMethod});

  @override
  Widget build(BuildContext context) {
    final prov = context.watch<AppProvider>();
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('Review Your Order',
          style: TextStyle(fontSize: 22, fontWeight: FontWeight.w600)),
      const SizedBox(height: 20),

      // Items list
      Container(
        decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(8),
            boxShadow: [BoxShadow(
                color: Colors.black.withOpacity(0.06),
                blurRadius: 8, offset: const Offset(0, 2))]),
        child: Column(children: [
          ...prov.cart.map((item) => ListTile(
                title: Text(item.name,
                    style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w500)),
                subtitle: Text('${item.qty} × ₹${item.price}',
                    style: const TextStyle(fontSize: 12, color: Colors.grey)),
                trailing: Text('₹${item.price * item.qty}',
                    style: TextStyle(
                        fontWeight: FontWeight.w600, color: AppColors.terracotta)),
              )),
          const Divider(height: 1),
          Padding(
            padding: const EdgeInsets.all(16),
            child: Column(children: [
              _ReviewRow('Subtotal',     '₹${prov.cartSubtotal}'),
              const SizedBox(height: 4),
              _ReviewRow('Delivery Fee', '₹${prov.deliveryFee}'),
              const Divider(height: 14),
              _ReviewRow('Total',        '₹${prov.cartTotal}', bold: true),
            ]),
          ),
        ]),
      ),
      const SizedBox(height: 16),

      // Payment method summary
      Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(8),
            border: Border.all(color: Colors.grey[200]!)),
        child: Row(children: [
          const Icon(Icons.payment_outlined, color: AppColors.terracotta),
          const SizedBox(width: 12),
          Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Payment Method',
                style: TextStyle(fontSize: 11, color: Colors.grey)),
            Text(payMethod,
                style: const TextStyle(
                    fontWeight: FontWeight.w600, fontSize: 14)),
          ]),
        ]),
      ),
    ]);
  }
}

class _ReviewRow extends StatelessWidget {
  final String label, value;
  final bool bold;
  const _ReviewRow(this.label, this.value, {this.bold = false});
  @override
  Widget build(BuildContext context) {
    final style = bold
        ? const TextStyle(fontWeight: FontWeight.w700, fontSize: 16)
        : TextStyle(color: Colors.grey[600], fontSize: 14);
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label, style: style),
        Text(value, style: style.copyWith(
            color: bold ? AppColors.terracotta : Colors.grey[600])),
      ],
    );
  }
}

// ── Nav buttons ────────────────────────────────────────────
class _NavButtons extends StatelessWidget {
  final int step;
  final bool loading;
  final VoidCallback? onBack;
  final VoidCallback onNext;
  const _NavButtons({
    required this.step, required this.loading,
    required this.onBack, required this.onNext,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
          color: Colors.white,
          boxShadow: [BoxShadow(
              color: Colors.black.withOpacity(0.08),
              blurRadius: 12, offset: const Offset(0, -4))]),
      child: SafeArea(
        top: false,
        child: Row(children: [
          if (onBack != null) ...[
            OutlinedButton(
              onPressed: onBack,
              style: OutlinedButton.styleFrom(
                  foregroundColor: AppColors.charcoal,
                  side: BorderSide(color: Colors.grey[300]!),
                  padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(2))),
              child: const Text('BACK',
                  style: TextStyle(letterSpacing: 1, fontWeight: FontWeight.w600)),
            ),
            const SizedBox(width: 12),
          ],
          Expanded(child: ElevatedButton(
            onPressed: loading ? null : onNext,
            child: loading
                ? const SizedBox(width: 20, height: 20,
                    child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                : Text(
                    step == 2 ? 'PLACE ORDER' : 'CONTINUE',
                    style: const TextStyle(
                        letterSpacing: 1.5, fontWeight: FontWeight.w600)),
          )),
        ]),
      ),
    );
  }
}

// ── Input Formatters ───────────────────────────────────────
class _CardNumberFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(
      TextEditingValue old, TextEditingValue value) {
    final digits = value.text.replaceAll(' ', '');
    final buffer = StringBuffer();
    for (int i = 0; i < digits.length; i++) {
      if (i > 0 && i % 4 == 0) buffer.write(' ');
      buffer.write(digits[i]);
    }
    final str = buffer.toString();
    return value.copyWith(
      text: str,
      selection: TextSelection.collapsed(offset: str.length),
    );
  }
}

class _ExpiryFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(
      TextEditingValue old, TextEditingValue value) {
    final digits = value.text.replaceAll('/', '');
    if (digits.length > 4) return old;
    final buffer = StringBuffer();
    for (int i = 0; i < digits.length; i++) {
      if (i == 2) buffer.write('/');
      buffer.write(digits[i]);
    }
    final str = buffer.toString();
    return value.copyWith(
      text: str,
      selection: TextSelection.collapsed(offset: str.length),
    );
  }
}
