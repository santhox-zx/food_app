// lib/screens/customer/login_screen.dart
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../../utils/theme.dart';
import '../../services/app_provider.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  bool _isLogin = true;
  bool _loading  = false;
  bool _obscure  = true;

  final _nameCtrl  = TextEditingController();
  final _phoneCtrl = TextEditingController();
  final _passCtrl  = TextEditingController();
  final _formKey   = GlobalKey<FormState>();

  @override
  void dispose() {
    _nameCtrl.dispose();
    _phoneCtrl.dispose();
    _passCtrl.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _loading = true);

    final prov = context.read<AppProvider>();
    final Map<String, dynamic> result;
    if (_isLogin) {
      result = await prov.login(
          _phoneCtrl.text.trim(), _passCtrl.text.trim());
    } else {
      result = await prov.register(_nameCtrl.text.trim(),
          _phoneCtrl.text.trim(), _passCtrl.text.trim());
    }

    if (!mounted) return;
    setState(() => _loading = false);

    if (result['success'] == true) {
      // Admin and customer use same login panel; route to admin dashboard for admin.
      if (context.read<AppProvider>().isAdmin) {
        context.go('/admin');
      } else {
        if (context.canPop()) {
          context.pop();
        } else {
          context.go('/');
        }
      }
    } else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text(
              result['error']?.toString() ?? 'Login failed'),
          backgroundColor: AppColors.error));
    }
  }

  void _toggle() {
    setState(() {
      _isLogin = !_isLogin;
      _nameCtrl.clear();
      _phoneCtrl.clear();
      _passCtrl.clear();
      _formKey.currentState?.reset();
    });
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<AppProvider>();
    if (provider.isLoggedIn) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (provider.isAdmin) {
          context.go('/admin');
        } else {
          context.go('/');
        }
      });
      return const Scaffold(body: SizedBox());
    }

    return Scaffold(
      backgroundColor: AppColors.charcoal,
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 420),
            child: Container(
              padding: const EdgeInsets.all(32),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
                boxShadow: [
                  BoxShadow(
                      color: Colors.black.withOpacity(0.3),
                      blurRadius: 40,
                      offset: const Offset(0, 20))
                ],
              ),
              child: Form(
                key: _formKey,
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Text('Friends Cafe',
                        style: TextStyle(
                            fontSize: 26,
                            fontWeight: FontWeight.w700,
                            color: AppColors.charcoal)),
                    const SizedBox(height: 4),
                    Text(
                        _isLogin
                            ? 'WELCOME BACK'
                            : 'CREATE ACCOUNT',
                        style: const TextStyle(
                            fontSize: 10,
                            letterSpacing: 3,
                            color: Colors.grey)),
                    const SizedBox(height: 28),

                    // Name (register only)
                    if (!_isLogin) ...[
                      TextFormField(
                        controller: _nameCtrl,
                        textInputAction: TextInputAction.next,
                        decoration: const InputDecoration(
                            labelText: 'Full Name'),
                        validator: (v) =>
                            (v == null || v.trim().isEmpty)
                                ? 'Name required'
                                : null,
                      ),
                      const SizedBox(height: 12),
                    ],

                    TextFormField(
                      controller: _phoneCtrl,
                      keyboardType:
                          TextInputType.phone,
                      textInputAction: TextInputAction.next,
                      decoration: const InputDecoration(
                          labelText: 'Phone Number'),
                      validator: (v) {
                        if (v == null || v.trim().length < 10) {
                          return 'Enter a valid 10-digit phone';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 12),

                    TextFormField(
                      controller: _passCtrl,
                      obscureText: _obscure,
                      textInputAction: TextInputAction.done,
                      onFieldSubmitted: (_) => _submit(),
                      decoration: InputDecoration(
                        labelText: 'Password',
                        suffixIcon: IconButton(
                          icon: Icon(
                              _obscure
                                  ? Icons.visibility_off_outlined
                                  : Icons.visibility_outlined,
                              size: 20),
                          onPressed: () => setState(
                              () => _obscure = !_obscure),
                        ),
                      ),
                      validator: (v) =>
                          (v == null || v.length < 4)
                              ? 'Min 4 characters'
                              : null,
                    ),
                    const SizedBox(height: 20),

                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton(
                        onPressed:
                            _loading ? null : _submit,
                        child: _loading
                            ? const SizedBox(
                                width: 20,
                                height: 20,
                                child:
                                    CircularProgressIndicator(
                                        strokeWidth: 2,
                                        color: Colors.white))
                            : Text(
                                _isLogin
                                    ? 'LOGIN'
                                    : 'REGISTER',
                                style: const TextStyle(
                                    letterSpacing: 1.5,
                                    fontWeight:
                                        FontWeight.w600)),
                      ),
                    ),
                    const SizedBox(height: 16),

                    GestureDetector(
                      onTap: _loading ? null : _toggle,
                      child: RichText(
                        text: TextSpan(
                          style: const TextStyle(
                              fontSize: 13,
                              color: Colors.grey),
                          children: [
                            TextSpan(
                                text: _isLogin
                                    ? "Don't have an account? "
                                    : 'Already have an account? '),
                            TextSpan(
                                text: _isLogin
                                    ? 'Register'
                                    : 'Login',
                                style: TextStyle(
                                    color:
                                        AppColors.terracotta,
                                    fontWeight:
                                        FontWeight.w600)),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
