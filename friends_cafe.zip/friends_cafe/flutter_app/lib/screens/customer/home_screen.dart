// lib/screens/customer/home_screen.dart
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../../utils/theme.dart';
import '../../services/app_provider.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _scrollController = ScrollController();
  final _aboutKey = GlobalKey();

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  void _scrollToAbout() {
    final ctx = _aboutKey.currentContext;
    if (ctx != null) {
      Scrollable.ensureVisible(ctx,
          duration: const Duration(milliseconds: 600), curve: Curves.easeInOut);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: CustomScrollView(
        controller: _scrollController,
        slivers: [
          SliverAppBar(
            expandedHeight: 0,
            floating: true,
            pinned: true,
            backgroundColor: AppColors.charcoal,
            automaticallyImplyLeading: false,
            title: _NavTitle(),
            actions: [_NavActions()],
          ),
          SliverToBoxAdapter(
              child: _HeroSection(onScrollToAbout: _scrollToAbout)),
          SliverToBoxAdapter(
              child: _AboutSection(key: _aboutKey)),
          SliverToBoxAdapter(child: _WhySection()),
          SliverToBoxAdapter(child: _FooterSection()),
        ],
      ),
    );
  }
}

// ── NAV ───────────────────────────────────────────────────
class _NavTitle extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => context.go('/'),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Text('Friends Cafe',
              style: TextStyle(
                  fontSize: 18,
                  color: AppColors.cream,
                  fontWeight: FontWeight.w600)),
          Text('TENKASI',
              style: TextStyle(
                  fontSize: 9, color: AppColors.muted, letterSpacing: 3)),
        ],
      ),
    );
  }
}

class _NavActions extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final user = context.watch<AppProvider>().user;
    final isWide = MediaQuery.of(context).size.width > 600;
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        if (isWide) ...[
          TextButton(
            onPressed: () => context.push('/menu'),
            child: Text('Menu',
                style: TextStyle(
                    color: AppColors.cream, fontSize: 12, letterSpacing: 1)),
          ),
          TextButton(
            onPressed: () => context.push('/my-orders'),
            child: Text('Orders',
                style: TextStyle(
                    color: AppColors.cream, fontSize: 12, letterSpacing: 1)),
          ),
        ],
        const SizedBox(width: 4),
        GestureDetector(
          onTap: () => user == null
              ? context.push('/login')
              : _showUserMenu(context),
          child: Container(
            padding:
                const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              border: Border.all(
                  color: AppColors.cream.withOpacity(0.3)),
              borderRadius: BorderRadius.circular(50),
            ),
            child: Text(
              user == null
                  ? '👤 Login'
                  : '👤 ${(user['name'] ?? '').toString().split(' ').first}',
              style: TextStyle(color: AppColors.cream, fontSize: 12),
            ),
          ),
        ),
        const SizedBox(width: 6),
        _CartBadge(),
        const SizedBox(width: 8),
      ],
    );
  }

  void _showUserMenu(BuildContext context) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
          borderRadius:
              BorderRadius.vertical(top: Radius.circular(16))),
      builder: (_) => _UserBottomSheet(),
    );
  }
}

class _CartBadge extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final count = context.watch<AppProvider>().cartCount;
    return GestureDetector(
      onTap: () => context.push('/cart'),
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          Padding(
            padding: const EdgeInsets.all(6),
            child: Icon(Icons.shopping_bag_outlined,
                color: AppColors.cream, size: 22),
          ),
          if (count > 0)
            Positioned(
              top: 0,
              right: 0,
              child: Container(
                width: 16,
                height: 16,
                decoration: BoxDecoration(
                    color: AppColors.terracotta,
                    shape: BoxShape.circle),
                child: Center(
                  child: Text('$count',
                      style: const TextStyle(
                          color: Colors.white,
                          fontSize: 9,
                          fontWeight: FontWeight.bold)),
                ),
              ),
            ),
        ],
      ),
    );
  }
}

class _UserBottomSheet extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final user = context.read<AppProvider>().user;
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                    color: Colors.grey[300],
                    borderRadius: BorderRadius.circular(2))),
            const SizedBox(height: 20),
            Text(user?['name']?.toString() ?? '',
                style: const TextStyle(
                    fontSize: 20, fontWeight: FontWeight.w600)),
            Text(user?['phone']?.toString() ?? '',
                style:
                    TextStyle(color: Colors.grey[600], fontSize: 13)),
            const SizedBox(height: 16),
            const Divider(),
            ListTile(
              leading:
                  const Icon(Icons.receipt_long_outlined),
              title: const Text('My Orders'),
              onTap: () {
                Navigator.pop(context);
                context.push('/my-orders');
              },
            ),
            ListTile(
              leading: Icon(Icons.logout,
                  color: AppColors.error),
              title: Text('Logout',
                  style:
                      TextStyle(color: AppColors.error)),
              onTap: () async {
                Navigator.pop(context);
                await context.read<AppProvider>().logout();
              },
            ),
          ],
        ),
      ),
    );
  }
}

// ── HERO ──────────────────────────────────────────────────
class _HeroSection extends StatelessWidget {
  final VoidCallback onScrollToAbout;
  const _HeroSection({required this.onScrollToAbout});

  @override
  Widget build(BuildContext context) {
    final h = MediaQuery.of(context).size.height;
    return Container(
      height: h,
      decoration: BoxDecoration(
        image: DecorationImage(
          image: const NetworkImage(
              'https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=1600&q=80'),
          fit: BoxFit.cover,
          colorFilter: ColorFilter.mode(
              AppColors.charcoal.withOpacity(0.65),
              BlendMode.darken),
        ),
      ),
      child: Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text("TENKASI'S FAVOURITE TABLE",
                  style: TextStyle(
                      fontSize: 11,
                      letterSpacing: 4,
                      color: AppColors.terracotta,
                      fontWeight: FontWeight.w500)),
              const SizedBox(height: 16),
              Text('Where Every Meal\nFeels Like Home',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      fontSize: 36,
                      color: AppColors.cream,
                      fontWeight: FontWeight.w700,
                      height: 1.15)),
              const SizedBox(height: 16),
              Text(
                  'Authentic flavours from Kamaraj Nagar,\ncrafted with love since day one.',
                  textAlign: TextAlign.center,
                  style: TextStyle(
                      color: AppColors.muted,
                      fontSize: 15,
                      height: 1.6,
                      fontWeight: FontWeight.w300)),
              const SizedBox(height: 32),
              Wrap(
                alignment: WrapAlignment.center,
                spacing: 12,
                runSpacing: 12,
                children: [
                  ElevatedButton(
                    onPressed: () => context.push('/menu'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.terracotta,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(
                          horizontal: 28, vertical: 14),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(2)),
                    ),
                    child: const Text('ORDER NOW',
                        style: TextStyle(
                            letterSpacing: 1.5,
                            fontSize: 13,
                            fontWeight: FontWeight.w600)),
                  ),
                  OutlinedButton(
                    onPressed: onScrollToAbout,
                    style: OutlinedButton.styleFrom(
                      foregroundColor: AppColors.cream,
                      side: BorderSide(
                          color: AppColors.cream.withOpacity(0.5)),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 28, vertical: 14),
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(2)),
                    ),
                    child: const Text('OUR STORY',
                        style: TextStyle(
                            letterSpacing: 1.5,
                            fontSize: 13,
                            fontWeight: FontWeight.w600)),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ── ABOUT ─────────────────────────────────────────────────
class _AboutSection extends StatelessWidget {
  const _AboutSection({super.key});

  @override
  Widget build(BuildContext context) {
    final isWide = MediaQuery.of(context).size.width > 800;
    return Container(
      color: AppColors.creamLight,
      padding:
          const EdgeInsets.symmetric(vertical: 64, horizontal: 24),
      child: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 1100),
          child: isWide
              ? Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Expanded(child: _aboutText()),
                    const SizedBox(width: 48),
                    Expanded(child: _aboutImage()),
                  ],
                )
              : Column(children: [
                  _aboutText(),
                  const SizedBox(height: 32),
                  _aboutImage(),
                ]),
        ),
      ),
    );
  }

  Widget _aboutText() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('OUR STORY',
            style: TextStyle(
                fontSize: 11,
                letterSpacing: 3,
                color: AppColors.terracotta,
                fontWeight: FontWeight.w500)),
        const SizedBox(height: 12),
        const Text("More Than a Meal,\nIt's a Memory",
            style: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.w600,
                height: 1.2)),
        const SizedBox(height: 16),
        const Text(
            'Nestled in Kamaraj Nagar, Friends Cafe was born from a simple belief — '
            'that great food, shared with warmth, can turn strangers into friends.',
            style: TextStyle(
                fontSize: 15,
                height: 1.8,
                color: Color(0xFF3a3a38))),
        const SizedBox(height: 24),
        Row(children: [
          _Stat('2500+', 'Happy Customers'),
          const SizedBox(width: 32),
          _Stat('10+', 'Signature Dishes'),
          const SizedBox(width: 32),
          _Stat('4.8★', 'Avg Rating'),
        ]),
      ],
    );
  }

  Widget _aboutImage() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(4),
      child: Image.network(
        'https://images.unsplash.com/photo-1555396273-367ea4eb4db5?w=600&q=80',
        fit: BoxFit.cover,
        height: 400,
        width: double.infinity,
        errorBuilder: (_, __, ___) => Container(
            height: 400,
            color: Colors.grey[200],
            child:
                const Icon(Icons.restaurant, size: 48, color: Colors.grey)),
      ),
    );
  }
}

class _Stat extends StatelessWidget {
  final String val, label;
  const _Stat(this.val, this.label);
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(val,
            style: TextStyle(
                fontSize: 24,
                color: AppColors.terracotta,
                fontWeight: FontWeight.w700)),
        Text(label,
            style: const TextStyle(
                fontSize: 11,
                color: Colors.grey,
                letterSpacing: 0.5)),
      ],
    );
  }
}

// ── WHY US ────────────────────────────────────────────────
class _WhySection extends StatelessWidget {
  static const _items = [
    {
      'icon': '🌿',
      'title': 'Fresh Ingredients',
      'desc': 'Sourced daily from local farms around Tenkasi.'
    },
    {
      'icon': '👨‍🍳',
      'title': 'Expert Chefs',
      'desc': 'Decades of culinary expertise in every dish.'
    },
    {
      'icon': '🚴',
      'title': 'Fast Delivery',
      'desc': 'Hot meals at your doorstep within 30 minutes.'
    },
    {
      'icon': '💰',
      'title': 'Fair Prices',
      'desc': 'Restaurant quality without the restaurant bill.'
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Container(
      color: AppColors.creamLight,
      padding:
          const EdgeInsets.symmetric(vertical: 64, horizontal: 24),
      child: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 1100),
          child: Column(
            children: [
              Text('WHY CHOOSE US',
                  style: TextStyle(
                      fontSize: 11,
                      letterSpacing: 3,
                      color: AppColors.terracotta,
                      fontWeight: FontWeight.w500)),
              const SizedBox(height: 8),
              const Text('The Friends Cafe Difference',
                  style: TextStyle(
                      fontSize: 26, fontWeight: FontWeight.w600)),
              const SizedBox(height: 40),
              LayoutBuilder(builder: (ctx, c) {
                final cols = c.maxWidth > 700 ? 4 : 2;
                return GridView.count(
                  crossAxisCount: cols,
                  shrinkWrap: true,
                  physics:
                      const NeverScrollableScrollPhysics(),
                  crossAxisSpacing: 16,
                  mainAxisSpacing: 16,
                  childAspectRatio: 1.1,
                  children: _items
                      .map((i) => _WhyCard(
                            icon: i['icon']!,
                            title: i['title']!,
                            desc: i['desc']!,
                          ))
                      .toList(),
                );
              }),
            ],
          ),
        ),
      ),
    );
  }
}

class _WhyCard extends StatelessWidget {
  final String icon, title, desc;
  const _WhyCard(
      {required this.icon, required this.title, required this.desc});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
        boxShadow: [
          BoxShadow(
              color: Colors.black.withOpacity(0.06),
              blurRadius: 12,
              offset: const Offset(0, 4))
        ],
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(icon, style: const TextStyle(fontSize: 30)),
          const SizedBox(height: 10),
          Text(title,
              style: const TextStyle(
                  fontSize: 14, fontWeight: FontWeight.w600),
              textAlign: TextAlign.center),
          const SizedBox(height: 6),
          Text(desc,
              style: TextStyle(
                  fontSize: 11,
                  color: Colors.grey[600],
                  height: 1.5),
              textAlign: TextAlign.center),
        ],
      ),
    );
  }
}

// ── FOOTER ────────────────────────────────────────────────
class _FooterSection extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      color: AppColors.charcoal,
      padding: const EdgeInsets.all(32),
      child: Column(
        children: [
          Text('Friends Cafe',
              style: TextStyle(
                  fontSize: 22,
                  color: AppColors.cream,
                  fontWeight: FontWeight.w600)),
          const SizedBox(height: 8),
          Text('Kamaraj Nagar, Tenkasi, Tamil Nadu',
              style:
                  TextStyle(color: AppColors.muted, fontSize: 13)),
          Text('📞 090038 97788',
              style:
                  TextStyle(color: AppColors.muted, fontSize: 13)),
          Text('Daily 9 AM – 11 PM',
              style:
                  TextStyle(color: AppColors.muted, fontSize: 13)),
          const SizedBox(height: 16),
          const Divider(color: Colors.white12),
          const SizedBox(height: 8),
          // Long-press footer → admin panel (same as original web)
          GestureDetector(
            onLongPress: () => context.push('/login'),
            child: Text('© 2025 Friends Cafe',
                style: TextStyle(
                    color: AppColors.muted.withOpacity(0.5),
                    fontSize: 11)),
          ),
        ],
      ),
    );
  }
}
