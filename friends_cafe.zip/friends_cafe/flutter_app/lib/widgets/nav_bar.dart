// lib/widgets/nav_bar.dart
// Placeholder — navigation is handled directly inside each screen's AppBar.
// Kept for future extraction of shared navigation components.
