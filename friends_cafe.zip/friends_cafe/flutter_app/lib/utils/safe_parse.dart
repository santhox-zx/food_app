// lib/utils/safe_parse.dart
// Safe parsers for JSON values that MySQL may return as String, int, or double.

/// Safely parse any JSON value as int.
/// Handles int, double, and String like "220", "4", "99".
int safeInt(dynamic v, {int fallback = 0}) {
  if (v == null) return fallback;
  if (v is int) return v;
  if (v is double) return v.toInt();
  if (v is num) return v.toInt();
  return int.tryParse(v.toString()) ?? fallback;
}

/// Safely parse any JSON value as double.
/// Handles double, int, and String like "4.8", "4", "4.50".
double safeDouble(dynamic v, {double fallback = 0.0}) {
  if (v == null) return fallback;
  if (v is double) return v;
  if (v is int) return v.toDouble();
  if (v is num) return v.toDouble();
  return double.tryParse(v.toString()) ?? fallback;
}
