// lib/utils/theme.dart
import 'package:flutter/material.dart';

class AppColors {
  static const charcoal       = Color(0xFF1A1A18);
  static const terracotta     = Color(0xFFC9773A);
  static const terracottaDk   = Color(0xFFA85F28);
  static const cream          = Color(0xFFE8D5B7);
  static const creamLight     = Color(0xFFF5EFE6);
  static const forest         = Color(0xFF2C5F4A);
  static const muted          = Color(0xB8E8D5B7);
  static const white          = Color(0xFFFFFFFF);
  static const error          = Color(0xFFC0392B);
  static const success        = Color(0xFF27AE60);

  static const statusReceived       = Color(0xFFE67E22);
  static const statusPreparing      = Color(0xFFF39C12);
  static const statusOutForDelivery = Color(0xFF27AE60);
  static const statusDelivered      = Color(0xFF1565C0);
  static const statusCancelled      = Color(0xFFC0392B);
}

class AppTheme {
  static ThemeData get light => ThemeData(
    useMaterial3: true,
    colorScheme: ColorScheme.light(
      primary:     AppColors.terracotta,
      onPrimary:   AppColors.white,
      secondary:   AppColors.forest,
      onSecondary: AppColors.white,
      surface:     AppColors.creamLight,
      onSurface:   AppColors.charcoal,
      error:       AppColors.error,
    ),
    scaffoldBackgroundColor: AppColors.creamLight,
    appBarTheme: const AppBarTheme(
      backgroundColor: AppColors.charcoal,
      foregroundColor: AppColors.cream,
      elevation: 0,
      centerTitle: false,
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: AppColors.terracotta,
        foregroundColor: AppColors.white,
        padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 24),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(2)),
        elevation: 0,
        textStyle: const TextStyle(
          fontSize: 13,
          fontWeight: FontWeight.w600,
          letterSpacing: 1.0,
        ),
      ),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: Colors.white,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(4),
        borderSide: const BorderSide(color: Color(0xFFDDDDDD)),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(4),
        borderSide: const BorderSide(color: Color(0xFFDDDDDD)),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(4),
        borderSide: const BorderSide(color: AppColors.terracotta, width: 1.5),
      ),
      errorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(4),
        borderSide: const BorderSide(color: AppColors.error),
      ),
      focusedErrorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(4),
        borderSide: const BorderSide(color: AppColors.error, width: 1.5),
      ),
      labelStyle: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500),
      contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
    ),
    cardTheme: CardThemeData(
      color: Colors.white,
      elevation: 2,
      shadowColor: Colors.black12,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
    ),
    chipTheme: ChipThemeData(
      backgroundColor: Colors.transparent,
      selectedColor: AppColors.terracotta,
      labelStyle: const TextStyle(fontSize: 13, fontWeight: FontWeight.w500),
      side: const BorderSide(color: Color(0x40E8D5B7)),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(50)),
    ),
  );
}
