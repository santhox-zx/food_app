

## STEP 1 — Set Up the Database (MySQL)

### Option A: MySQL Workbench (GUI)
1. Open MySQL Workbench
2. Connect to your local server
3. Click **File → Open SQL Script**
4. Select `friends_cafe/backend/config/schema.sql`
5. Press **Ctrl+Shift+Enter** (Run All)

### Option B: Command Line
```bash
mysql -u root -p < friends_cafe/backend/config/schema.sql
```

This creates the `friends_cafe` database with all tables and seed data.

---

## STEP 2 — Start the Backend (Node.js API)

```bash
# Go into the backend folder
cd friends_cafe/backend

# Install packages (only needed once)
npm install

# Copy the env file and edit it
cp .env.example .env
```

Now open `.env` in any text editor and set your MySQL password:
```
DB_HOST=localhost
DB_PORT=3306
DB_USER=root
DB_PASS=YOUR_MYSQL_PASSWORD_HERE
DB_NAME=friends_cafe
JWT_SECRET=friends_cafe_secret_key
ADMIN_PHONE=1234567890
ADMIN_PASS=admin123
```

Then start the server:
```bash
npm start
```

You should see:
```
🍴 Friends Cafe API running on http://localhost:3000
   Health: http://localhost:3000/health
```

**Test it works:** Open http://localhost:3000/health in your browser — you should see `{"status":"ok"}`.

---

## STEP 3 — Run the Flutter App

```bash
# Go into the flutter app folder
cd friends_cafe/flutter_app

# Install Flutter packages (only needed once)
flutter pub get
```

### Run on Web Browser (easiest)
```bash
flutter run -d chrome
```

### Run on Android Phone
1. Enable **Developer Options** on your phone
2. Enable **USB Debugging**
3. Connect phone with USB cable
4. Run:
```bash
flutter run -d android
```

### Run on iOS (Mac only)
```bash
flutter run -d ios
```

### Run on Windows Desktop
```bash
flutter run -d windows
```

---

## ⚠️ Important: Set the API URL

Before running on a **real phone** or **different device**, you must update the API address.

Open `friends_cafe/flutter_app/lib/services/api_service.dart` and change line 8:

```dart
// For web browser (same computer):
static const String baseUrl = 'http://localhost:3000/api';

// For Android emulator:
static const String baseUrl = 'http://10.0.2.2:3000/api';

// For real phone on same WiFi (find your computer's IP):
static const String baseUrl = 'http://192.168.1.XXX:3000/api';
```

**How to find your computer's IP:**
- Windows: Open Command Prompt → type `ipconfig` → look for "IPv4 Address"
- Mac/Linux: Open Terminal → type `ifconfig` → look for "inet"

---

## Build for Production

### Flutter Web (deploy to any web host)
```bash
cd friends_cafe/flutter_app
flutter build web --release
# Upload the contents of build/web/ to your server
```

### Android APK (install on phone directly)
```bash
flutter build apk --release
# File is at: build/app/outputs/flutter-apk/app-release.apk
```

### Android App Bundle (for Play Store)
```bash
flutter build appbundle --release
```
